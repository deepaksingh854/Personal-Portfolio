function arlo_tm_intro_tabs() {
    "use strict";
    var t = jQuery(".arlo_tm_intro_content .main_filter ul li a")
      , e = jQuery(".arlo_tm_intro_content .demo_list");
    t.on("click", function() {
        var r = jQuery(this)
          , o = r.attr("data-tab");
        return t.removeClass("current"),
        e.removeClass("current"),
        r.addClass("current"),
        jQuery("#" + o).addClass("current"),
        !1
    })
}
function arlo_tm_cursor() {
    "use strict";
    if (jQuery(".mouse-cursor").length && $("body")) {
        const t = document.querySelector(".cursor-inner")
          , e = document.querySelector(".cursor-outer");
        let r, o = 0, a = !1;
        window.onmousemove = function(n) {
            a || (e.style.transform = "translate(" + n.clientX + "px, " + n.clientY + "px)"),
            t.style.transform = "translate(" + n.clientX + "px, " + n.clientY + "px)",
            r = n.clientY,
            o = n.clientX
        }
        ,
        $("body").on("mouseenter", "a, .cursor-pointer", function() {
            t.classList.add("cursor-hover"),
            e.classList.add("cursor-hover")
        }),
        $("body").on("mouseleave", "a, .cursor-pointer", function() {
            $(this).is("a") && $(this).closest(".cursor-pointer").length || (t.classList.remove("cursor-hover"),
            e.classList.remove("cursor-hover"))
        }),
        t.style.visibility = "visible",
        e.style.visibility = "visible"
    }
}
function arlo_tm_kenburn_slider() {
    "use strict";
    jQuery(function() {
        jQuery(".arlo_tm_hero .overlay_slider").vegas({
            timer: !1,
            animation: ["kenburnsUp", "kenburnsLeft", "kenburnsRight"],
            delay: 7e3,
            slides: [{
                src: "img/slider/1.jpg"
            }, {
                src: "img/slider/2.jpg"
            }, {
                src: "img/slider/3.jpg"
            }]
        })
    })
}
function arlo_tm_modalbox_news() {
    "use strict";
    var t = jQuery(".arlo_tm_modalbox_news")
      , e = jQuery(".arlo_tm_news .news_list ul li")
      , r = t.find(".close");
    e.each(function() {
        var e = jQuery(this)
          , r = e.find(".list_inner").html()
          , o = e.find(".details .title a,.arlo_tm_full_link")
          , a = e.find(".main")
          , n = a.data("img-url")
          , i = (e.find(".title"),
        e.find(".title a").html());
        o.on("click", function() {
            return jQuery("body").addClass("modal"),
            t.addClass("opened"),
            t.find(".description_wrap").html(r),
            (a = t.find(".main")).css({
                backgroundImage: "url(" + n + ")"
            }),
            t.find(".title").html(i),
            !1
        })
    }),
    r.on("click", function() {
        return t.removeClass("opened"),
        t.find(".description_wrap").html(""),
        jQuery("body").removeClass("modal"),
        !1
    })
}
function arlo_tm_nav_bg() {
    "use strict";
    jQuery(window).on("scroll", function() {
        var t = jQuery(".arlo_tm_topbar");
        jQuery(window).scrollTop() >= 100 ? t.addClass("animate") : t.removeClass("animate")
    })
}
function arlo_tm_scrollable() {
    "use strict";
    var t = jQuery(window).height()
      , e = jQuery(".arlo_tm_leftpart .inner .menu.scrollable")
      , r = jQuery(".arlo_tm_leftpart .inner .menu")
      , o = jQuery(".arlo_tm_leftpart .inner .logo").outerHeight()
      , a = jQuery(".arlo_tm_leftpart .inner .bottom").outerHeight() + 100;
    r.css({
        height: t - o - a
    }),
    e.each(function() {
        jQuery(this).css({
            height: t - o - a
        }).niceScroll({
            touchbehavior: !1,
            cursorwidth: 0,
            autohidemode: !0,
            cursorborder: "0px solid #eee"
        })
    })
}
function arlo_tm_animate_text() {
    "use strict";
    jQuery(".arlo_tm_animation_text_word").typed({
        strings: ["Freelancer", "Web Developer", "YouTube Creator", "Blogger"],
        loop: !0,
        startDelay: 1e3,
        backDelay: 2e3
    })
}
function arlo_tm_popup() {
    "use strict";
    jQuery(".gallery_zoom").each(function() {
        jQuery(this).magnificPopup({
            delegate: "a.zoom",
            type: "image",
            gallery: {
                enabled: !0
            },
            removalDelay: 300,
            mainClass: "mfp-fade"
        })
    }),
    jQuery(".popup-youtube").each(function() {
        jQuery(this).magnificPopup({
            disableOn: 700,
            type: "iframe",
            mainClass: "mfp-fade",
            removalDelay: 160,
            preloader: !1,
            fixedContentPos: !1
        })
    })
}
function arlo_tm_mobile_menu() {
    "use strict";
    var t = jQuery(".hamburger")
      , e = jQuery(".arlo_tm_mobile_menu .dropdown");
    t.on("click", function() {
        var t = jQuery(this);
        return t.hasClass("is-active") ? (t.removeClass("is-active"),
        e.slideUp()) : (t.addClass("is-active"),
        e.slideDown()),
        !1
    }),
    jQuery(".arlo_tm_mobile_menu .dropdown .dropdown_inner ul li a").on("click", function() {
        return t.removeClass("is-active"),
        e.slideUp(),
        !1
    })
}
function arlo_tm_down() {
    "use strict";
    var t = jQuery(".arlo_tm_topbar").outerHeight();
    jQuery(".arlo_tm_arrow_wrap a").on("click", function() {
        return $(".arlo_tm_topbar").length ? "#" !== $.attr(this, "href") && $("html, body").animate({
            scrollTop: $($.attr(this, "href")).offset().top - t + 3
        }, 800) : "#" !== $.attr(this, "href") && $("html, body").animate({
            scrollTop: $($.attr(this, "href")).offset().top
        }, 800),
        !1
    }),
    jQuery(".arlo_tm_services .lets_work a").on("click", function() {
        return $(".arlo_tm_topbar").length ? "#" !== $.attr(this, "href") && $("html, body").animate({
            scrollTop: $($.attr(this, "href")).offset().top - t + 3
        }, 800) : "#" !== $.attr(this, "href") && $("html, body").animate({
            scrollTop: $($.attr(this, "href")).offset().top
        }, 800),
        !1
    })
}
function arlo_tm_imgtosvg() {
    "use strict";
    jQuery("img.svg").each(function() {
        var t = jQuery(this)
          , e = t.attr("class")
          , r = t.attr("src");
        jQuery.get(r, function(r) {
            var o = jQuery(r).find("svg");
            void 0 !== e && (o = o.attr("class", e + " replaced-svg")),
            o = o.removeAttr("xmlns:a"),
            t.replaceWith(o)
        }, "xml")
    })
}
function arlo_tm_data_images() {
    "use strict";
    jQuery("*[data-img-url]").each(function() {
        var t = jQuery(this)
          , e = t.data("img-url");
        t.css({
            backgroundImage: "url(" + e + ")"
        })
    })
}
function arlo_tm_jarallax() {
    "use strict";
    jQuery(".jarallax").each(function() {
        var t = jQuery(this)
          , e = t.data("speed");
        e = "undefined" !== e && "" !== e ? e : .5,
        t.jarallax({
            speed: e,
            automaticResize: !0
        })
    })
}
function arlo_tm_portfolio() {
    "use strict";
    if (jQuery().isotope) {
        var t = jQuery(".arlo_tm_portfolio .portfolio_list ul")
          , e = jQuery(".arlo_tm_portfolio .portfolio_filter ul");
        e.length && (e.find("a").on("click", function() {
            var e = jQuery(this).attr("data-filter");
            return t.isotope({
                filter: e,
                animationOptions: {
                    duration: 750,
                    easing: "linear",
                    queue: !1
                }
            }),
            !1
        }),
        e.find("a").on("click", function() {
            return e.find("a").removeClass("current"),
            jQuery(this).addClass("current"),
            !1
        }))
    }
}
function arlo_tm_projects() {
    "use strict";
    jQuery(".arlo_tm_portfolio_animation_wrap").each(function() {
        jQuery(this).on("mouseenter", function() {
            jQuery(this).data("title") && (jQuery(".arlo_tm_portfolio_titles").html(jQuery(this).data("title") + '<span class="work__cat">' + jQuery(this).data("category") + "</span>"),
            jQuery(".arlo_tm_portfolio_titles").addClass("visible")),
            jQuery(document).on("mousemove", function(t) {
                jQuery(".arlo_tm_portfolio_titles").css({
                    left: t.clientX - 10,
                    top: t.clientY + 25
                })
            })
        }).on("mouseleave", function() {
            jQuery(".arlo_tm_portfolio_titles").removeClass("visible")
        })
    })
}
function arlo_tm_isotope() {
    "use strict";
    jQuery(".masonry").isotope({
        itemSelector: ".masonry_item",
        masonry: {}
    })
}
function arlo_tm_contact_form() {
    "use strict";
    jQuery(".contact_form #send_message").on("click", function() {
        var t = jQuery(".contact_form #name").val()
          , e = jQuery(".contact_form #email").val()
          , r = jQuery(".contact_form #message").val()
          , o = jQuery(".contact_form #subject").val()
          , a = jQuery(".contact_form .returnmessage").data("success");
        return jQuery(".contact_form .returnmessage").empty(),
        "" === t || "" === e || "" === r ? jQuery("div.empty_notice").slideDown(500).delay(2e3).slideUp(500) : jQuery.post("modal/contact.php", {
            ajax_name: t,
            ajax_email: e,
            ajax_message: r,
            ajax_subject: o
        }, function(t) {
            jQuery(".contact_form .returnmessage").append(t),
            jQuery(".contact_form .returnmessage span.contact_error").length ? jQuery(".contact_form .returnmessage").slideDown(500).delay(2e3).slideUp(500) : (jQuery(".contact_form .returnmessage").append("<span class='contact_success'>" + a + "</span>"),
            jQuery(".contact_form .returnmessage").slideDown(500).delay(4e3).slideUp(500)),
            "" === t && jQuery("#contact_form")[0].reset()
        }),
        !1
    })
}
function arlo_tm_location() {
    jQuery(".href_location").on("click", function() {
        var t = jQuery(this).text();
        t = t.replace(/\ /g, "+");
        return window.open("https://maps.google.com?q=" + t),
        !1
    })
}
function arlo_tm_ripple() {
    "use strict";
    jQuery("#ripple").ripples({
        resolution: 500,
        dropRadius: 20,
        perturbance: .04
    })
}
function arlo_tm_videoplayer() {
    "use strict";
    $(".youtube-bg").mb_YTPlayer()
}
function arlo_tm_about_animation() {
    "use strict";
    if ($(".parallax").length > 0) {
        var t = $(".parallax").get(0);
        new Parallax(t,{
            relativeInput: !0,
            onReady: function() {
                console.log("ready!")
            }
        })
    }
}
jQuery(document).ready(function() {
    "use strict";
    arlo_tm_cursor(),
    arlo_tm_intro_tabs(),
    arlo_tm_kenburn_slider(),
    arlo_tm_modalbox_news(),
    arlo_tm_scrollable(),
    arlo_tm_nav_bg(),
    arlo_tm_popup(),
    arlo_tm_mobile_menu(),
    arlo_tm_down(),
    arlo_tm_imgtosvg(),
    arlo_tm_data_images(),
    arlo_tm_jarallax(),
    arlo_tm_portfolio(),
    arlo_tm_projects(),
    arlo_tm_isotope(),
    arlo_tm_contact_form(),
    arlo_tm_location(),
    arlo_tm_ripple(),
    arlo_tm_videoplayer(),
    arlo_tm_about_animation(),
    arlo_tm_animate_text(),
    jQuery(window).on("resize", function() {
        arlo_tm_isotope(),
        arlo_tm_modalbox_news()
    }),
    window.addEventListener("load", function() {
        setTimeout(function() {
            jQuery(".arlo_tm_preloader").addClass("loaded")
        }, 1e3),
        arlo_tm_isotope()
    })
}),
jQuery(".arlo_tm_counter").each(function() {
    "use strict";
    var t = jQuery(this);
    t.waypoint({
        handler: function() {
            t.hasClass("stop") || t.addClass("stop").countTo({
                refreshInterval: 50,
                formatter: function(t, e) {
                    return t.toFixed(e.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ",")
                }
            })
        },
        offset: "95%"
    })
}),
(new WOW).init(),
jQuery(".anchor_nav").onePageNav(),
$(".glitch").mgGlitch({
    destroy: !1,
    glitch: !0,
    scale: !0,
    blend: !0,
    blendModeType: "hue",
    glitch1TimeMin: 200,
    glitch1TimeMax: 400,
    glitch2TimeMin: 10,
    glitch2TimeMax: 100
});
