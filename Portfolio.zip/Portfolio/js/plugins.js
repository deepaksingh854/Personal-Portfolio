function initMap() {
    var t = new google.maps.Map(document.getElementById("ieatmaps"),{
        center: {
            lat: 34.0937458,
            lng: -118.3614978
        },
        zoom: 12,
        styles: [{
            featureType: "all",
            elementType: "labels.text.fill",
            stylers: [{
                saturation: 36
            }, {
                color: "#000000"
            }, {
                lightness: 40
            }]
        }, {
            featureType: "all",
            elementType: "labels.text.stroke",
            stylers: [{
                visibility: "on"
            }, {
                color: "#000000"
            }, {
                lightness: 16
            }]
        }, {
            featureType: "all",
            elementType: "labels.icon",
            stylers: [{
                visibility: "off"
            }]
        }, {
            featureType: "administrative",
            elementType: "geometry.fill",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 20
            }]
        }, {
            featureType: "administrative",
            elementType: "geometry.stroke",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }, {
                weight: 1.2
            }]
        }, {
            featureType: "landscape",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 20
            }]
        }, {
            featureType: "poi",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 21
            }]
        }, {
            featureType: "road.highway",
            elementType: "geometry.fill",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }]
        }, {
            featureType: "road.highway",
            elementType: "geometry.stroke",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 29
            }, {
                weight: .2
            }]
        }, {
            featureType: "road.arterial",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 18
            }]
        }, {
            featureType: "road.local",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 16
            }]
        }, {
            featureType: "transit",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 19
            }]
        }, {
            featureType: "water",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }]
        }]
    });
    new google.maps.Marker({
        position: new google.maps.LatLng(34.0937458,-118.3614978),
        title: "ASL",
        map: t
    })
}
!function(t) {
    t.fn.countTo = function(e) {
        return e = e || {},
        t(this).each(function() {
            function i(t) {
                var e = o.formatter.call(s, t, o);
                a.text(e)
            }
            var o = t.extend({}, t.fn.countTo.defaults, {
                from: t(this).data("from"),
                to: t(this).data("to"),
                speed: t(this).data("speed"),
                refreshInterval: t(this).data("refresh-interval"),
                decimals: t(this).data("decimals")
            }, e)
              , r = Math.ceil(o.speed / o.refreshInterval)
              , n = (o.to - o.from) / r
              , s = this
              , a = t(this)
              , l = 0
              , c = o.from
              , u = a.data("countTo") || {};
            a.data("countTo", u),
            u.interval && clearInterval(u.interval),
            u.interval = setInterval(function() {
                l++,
                i(c += n),
                "function" == typeof o.onUpdate && o.onUpdate.call(s, c),
                l >= r && (a.removeData("countTo"),
                clearInterval(u.interval),
                c = o.to,
                "function" == typeof o.onComplete && o.onComplete.call(s, c))
            }, o.refreshInterval),
            i(c)
        })
    }
    ,
    t.fn.countTo.defaults = {
        from: 0,
        to: 0,
        speed: 1e3,
        refreshInterval: 100,
        decimals: 0,
        formatter: function(t, e) {
            return t.toFixed(e.decimals)
        },
        onUpdate: null,
        onComplete: null
    }
}(jQuery),
function(t, e, i, o) {
    var r = function(o, r) {
        this.elem = o,
        this.$elem = t(o),
        this.options = r,
        this.metadata = this.$elem.data("plugin-options"),
        this.$win = t(e),
        this.sections = {},
        this.didScroll = !1,
        this.$doc = t(i),
        this.docHeight = this.$doc.height()
    };
    r.defaults = (r.prototype = {
        defaults: {
            navItems: "a",
            currentClass: "current",
            changeHash: !1,
            easing: "swing",
            filter: "",
            scrollSpeed: 700,
            scrollThreshold: .1,
            begin: !1,
            end: !1,
            scrollChange: !1
        },
        init: function() {
            return this.config = t.extend({}, this.defaults, this.options, this.metadata),
            this.$nav = this.$elem.find(this.config.navItems),
            "" !== this.config.filter && (this.$nav = this.$nav.filter(this.config.filter)),
            this.$nav.on("click.onePageNav", t.proxy(this.handleClick, this)),
            this.getPositions(),
            this.bindInterval(),
            this.$win.on("resize.onePageNav", t.proxy(this.getPositions, this)),
            this
        },
        adjustNav: function(t, e) {
            t.$elem.find("." + t.config.currentClass).removeClass(t.config.currentClass),
            e.addClass(t.config.currentClass)
        },
        bindInterval: function() {
            var t, e = this;
            e.$win.on("scroll.onePageNav", function() {
                e.didScroll = !0
            }),
            e.t = setInterval(function() {
                t = e.$doc.height(),
                e.didScroll && (e.didScroll = !1,
                e.scrollChange()),
                t !== e.docHeight && (e.docHeight = t,
                e.getPositions())
            }, 250)
        },
        getHash: function(t) {
            return t.attr("href").split("#")[1]
        },
        getPositions: function() {
            var e, i, o, r = this;
            r.$nav.each(function() {
                e = r.getHash(t(this)),
                (o = t("#" + e)).length && (i = o.offset().top,
                r.sections[e] = Math.round(i))
            })
        },
        getSection: function(t) {
            var e = null
              , i = Math.round(this.$win.height() * this.config.scrollThreshold);
            for (var o in this.sections)
                this.sections[o] - i < t && (e = o);
            return e
        },
        handleClick: function(i) {
            var o = this
              , r = t(i.currentTarget)
              , n = r.parent()
              , s = "#" + o.getHash(r);
            n.hasClass(o.config.currentClass) || (o.config.begin && o.config.begin(),
            o.adjustNav(o, n),
            o.unbindInterval(),
            o.scrollTo(s, function() {
                o.config.changeHash && (e.location.hash = s),
                o.bindInterval(),
                o.config.end && o.config.end()
            })),
            i.preventDefault()
        },
        scrollChange: function() {
            var t, e = this.$win.scrollTop(), i = this.getSection(e);
            null !== i && ((t = this.$elem.find('a[href$="#' + i + '"]').parent()).hasClass(this.config.currentClass) || (this.adjustNav(this, t),
            this.config.scrollChange && this.config.scrollChange(t)))
        },
        scrollTo: function(e, i) {
            var o = t(e).offset().top
              , r = jQuery(".arlo_tm_topbar").outerHeight();
            jQuery(".arlo_tm_topbar").length ? t("html, body").animate({
                scrollTop: o - r + 2
            }, this.config.scrollSpeed, this.config.easing, i) : t("html, body").animate({
                scrollTop: o
            }, this.config.scrollSpeed, this.config.easing, i)
        },
        unbindInterval: function() {
            clearInterval(this.t),
            this.$win.unbind("scroll.onePageNav")
        }
    }).defaults,
    t.fn.onePageNav = function(t) {
        return this.each(function() {
            new r(this,t).init()
        })
    }
}(jQuery, window, document),
function(t, e) {
    "function" == typeof define && define.amd ? define("ev-emitter/ev-emitter", e) : "object" == typeof module && module.exports ? module.exports = e() : t.EvEmitter = e()
}("undefined" != typeof window ? window : this, function() {
    function t() {}
    var e = t.prototype;
    return e.on = function(t, e) {
        if (t && e) {
            var i = this._events = this._events || {}
              , o = i[t] = i[t] || [];
            return -1 == o.indexOf(e) && o.push(e),
            this
        }
    }
    ,
    e.once = function(t, e) {
        if (t && e) {
            this.on(t, e);
            var i = this._onceEvents = this._onceEvents || {};
            return (i[t] = i[t] || {})[e] = !0,
            this
        }
    }
    ,
    e.off = function(t, e) {
        var i = this._events && this._events[t];
        if (i && i.length) {
            var o = i.indexOf(e);
            return -1 != o && i.splice(o, 1),
            this
        }
    }
    ,
    e.emitEvent = function(t, e) {
        var i = this._events && this._events[t];
        if (i && i.length) {
            i = i.slice(0),
            e = e || [];
            for (var o = this._onceEvents && this._onceEvents[t], r = 0; r < i.length; r++) {
                var n = i[r];
                o && o[n] && (this.off(t, n),
                delete o[n]),
                n.apply(this, e)
            }
            return this
        }
    }
    ,
    e.allOff = function() {
        delete this._events,
        delete this._onceEvents
    }
    ,
    t
}),
function(t, e) {
    "use strict";
    "function" == typeof define && define.amd ? define(["ev-emitter/ev-emitter"], function(i) {
        return e(t, i)
    }) : "object" == typeof module && module.exports ? module.exports = e(t, require("ev-emitter")) : t.imagesLoaded = e(t, t.EvEmitter)
}("undefined" != typeof window ? window : this, function(t, e) {
    function i(t, e) {
        for (var i in e)
            t[i] = e[i];
        return t
    }
    function o(t, e, r) {
        if (!(this instanceof o))
            return new o(t,e,r);
        var n = t;
        return "string" == typeof t && (n = document.querySelectorAll(t)),
        n ? (this.elements = function(t) {
            return Array.isArray(t) ? t : "object" == typeof t && "number" == typeof t.length ? l.call(t) : [t]
        }(n),
        this.options = i({}, this.options),
        "function" == typeof e ? r = e : i(this.options, e),
        r && this.on("always", r),
        this.getImages(),
        s && (this.jqDeferred = new s.Deferred),
        void setTimeout(this.check.bind(this))) : void a.error("Bad element for imagesLoaded " + (n || t))
    }
    function r(t) {
        this.img = t
    }
    function n(t, e) {
        this.url = t,
        this.element = e,
        this.img = new Image
    }
    var s = t.jQuery
      , a = t.console
      , l = Array.prototype.slice;
    o.prototype = Object.create(e.prototype),
    o.prototype.options = {},
    o.prototype.getImages = function() {
        this.images = [],
        this.elements.forEach(this.addElementImages, this)
    }
    ,
    o.prototype.addElementImages = function(t) {
        "IMG" == t.nodeName && this.addImage(t),
        !0 === this.options.background && this.addElementBackgroundImages(t);
        var e = t.nodeType;
        if (e && c[e]) {
            for (var i = t.querySelectorAll("img"), o = 0; o < i.length; o++) {
                var r = i[o];
                this.addImage(r)
            }
            if ("string" == typeof this.options.background) {
                var n = t.querySelectorAll(this.options.background);
                for (o = 0; o < n.length; o++) {
                    var s = n[o];
                    this.addElementBackgroundImages(s)
                }
            }
        }
    }
    ;
    var c = {
        1: !0,
        9: !0,
        11: !0
    };
    return o.prototype.addElementBackgroundImages = function(t) {
        var e = getComputedStyle(t);
        if (e)
            for (var i = /url\((['"])?(.*?)\1\)/gi, o = i.exec(e.backgroundImage); null !== o; ) {
                var r = o && o[2];
                r && this.addBackground(r, t),
                o = i.exec(e.backgroundImage)
            }
    }
    ,
    o.prototype.addImage = function(t) {
        var e = new r(t);
        this.images.push(e)
    }
    ,
    o.prototype.addBackground = function(t, e) {
        var i = new n(t,e);
        this.images.push(i)
    }
    ,
    o.prototype.check = function() {
        function t(t, i, o) {
            setTimeout(function() {
                e.progress(t, i, o)
            })
        }
        var e = this;
        return this.progressedCount = 0,
        this.hasAnyBroken = !1,
        this.images.length ? void this.images.forEach(function(e) {
            e.once("progress", t),
            e.check()
        }) : void this.complete()
    }
    ,
    o.prototype.progress = function(t, e, i) {
        this.progressedCount++,
        this.hasAnyBroken = this.hasAnyBroken || !t.isLoaded,
        this.emitEvent("progress", [this, t, e]),
        this.jqDeferred && this.jqDeferred.notify && this.jqDeferred.notify(this, t),
        this.progressedCount == this.images.length && this.complete(),
        this.options.debug && a && a.log("progress: " + i, t, e)
    }
    ,
    o.prototype.complete = function() {
        var t = this.hasAnyBroken ? "fail" : "done";
        if (this.isComplete = !0,
        this.emitEvent(t, [this]),
        this.emitEvent("always", [this]),
        this.jqDeferred) {
            var e = this.hasAnyBroken ? "reject" : "resolve";
            this.jqDeferred[e](this)
        }
    }
    ,
    r.prototype = Object.create(e.prototype),
    r.prototype.check = function() {
        return this.getIsImageComplete() ? void this.confirm(0 !== this.img.naturalWidth, "naturalWidth") : (this.proxyImage = new Image,
        this.proxyImage.addEventListener("load", this),
        this.proxyImage.addEventListener("error", this),
        this.img.addEventListener("load", this),
        this.img.addEventListener("error", this),
        void (this.proxyImage.src = this.img.src))
    }
    ,
    r.prototype.getIsImageComplete = function() {
        return this.img.complete && this.img.naturalWidth
    }
    ,
    r.prototype.confirm = function(t, e) {
        this.isLoaded = t,
        this.emitEvent("progress", [this, this.img, e])
    }
    ,
    r.prototype.handleEvent = function(t) {
        var e = "on" + t.type;
        this[e] && this[e](t)
    }
    ,
    r.prototype.onload = function() {
        this.confirm(!0, "onload"),
        this.unbindEvents()
    }
    ,
    r.prototype.onerror = function() {
        this.confirm(!1, "onerror"),
        this.unbindEvents()
    }
    ,
    r.prototype.unbindEvents = function() {
        this.proxyImage.removeEventListener("load", this),
        this.proxyImage.removeEventListener("error", this),
        this.img.removeEventListener("load", this),
        this.img.removeEventListener("error", this)
    }
    ,
    n.prototype = Object.create(r.prototype),
    n.prototype.check = function() {
        this.img.addEventListener("load", this),
        this.img.addEventListener("error", this),
        this.img.src = this.url,
        this.getIsImageComplete() && (this.confirm(0 !== this.img.naturalWidth, "naturalWidth"),
        this.unbindEvents())
    }
    ,
    n.prototype.unbindEvents = function() {
        this.img.removeEventListener("load", this),
        this.img.removeEventListener("error", this)
    }
    ,
    n.prototype.confirm = function(t, e) {
        this.isLoaded = t,
        this.emitEvent("progress", [this, this.element, e])
    }
    ,
    o.makeJQueryPlugin = function(e) {
        (e = e || t.jQuery) && ((s = e).fn.imagesLoaded = function(t, e) {
            return new o(this,t,e).jqDeferred.promise(s(this))
        }
        )
    }
    ,
    o.makeJQueryPlugin(),
    o
}),
function(t) {
    "use strict";
    var e = function(e, i) {
        this.el = t(e),
        this.options = t.extend({}, t.fn.typed.defaults, i),
        this.isInput = this.el.is("input"),
        this.attr = this.options.attr,
        this.showCursor = !this.isInput && this.options.showCursor,
        this.elContent = this.attr ? this.el.attr(this.attr) : this.el.text(),
        this.contentType = this.options.contentType,
        this.typeSpeed = this.options.typeSpeed,
        this.startDelay = this.options.startDelay,
        this.backSpeed = this.options.backSpeed,
        this.backDelay = this.options.backDelay,
        this.stringsElement = this.options.stringsElement,
        this.strings = this.options.strings,
        this.strPos = 0,
        this.arrayPos = 0,
        this.stopNum = 0,
        this.loop = this.options.loop,
        this.loopCount = this.options.loopCount,
        this.curLoop = 0,
        this.stop = !1,
        this.cursorChar = this.options.cursorChar,
        this.shuffle = this.options.shuffle,
        this.sequence = [],
        this.build()
    };
    e.prototype = {
        constructor: e,
        init: function() {
            var t = this;
            t.timeout = setTimeout(function() {
                for (var e = 0; e < t.strings.length; ++e)
                    t.sequence[e] = e;
                t.shuffle && (t.sequence = t.shuffleArray(t.sequence)),
                t.typewrite(t.strings[t.sequence[t.arrayPos]], t.strPos)
            }, t.startDelay)
        },
        build: function() {
            var e = this;
            if (!0 === this.showCursor && (this.cursor = t('<span class="typed-cursor">' + this.cursorChar + "</span>"),
            this.el.after(this.cursor)),
            this.stringsElement) {
                this.strings = [],
                this.stringsElement.hide(),
                console.log(this.stringsElement.children());
                var i = this.stringsElement.children();
                t.each(i, function(i, o) {
                    e.strings.push(t(o).html())
                })
            }
            this.init()
        },
        typewrite: function(t, e) {
            if (!0 !== this.stop) {
                var i = Math.round(70 * Math.random()) + this.typeSpeed
                  , o = this;
                o.timeout = setTimeout(function() {
                    var i = 0
                      , r = t.substr(e);
                    if ("^" === r.charAt(0)) {
                        var n = 1;
                        /^\^\d+/.test(r) && (n += (r = /\d+/.exec(r)[0]).length,
                        i = parseInt(r)),
                        t = t.substring(0, e) + t.substring(e + n)
                    }
                    if ("html" === o.contentType) {
                        var s = t.substr(e).charAt(0);
                        if ("<" === s || "&" === s) {
                            var a = "";
                            for (a = "<" === s ? ">" : ";"; t.substr(e + 1).charAt(0) !== a && (t.substr(e).charAt(0),
                            !(++e + 1 > t.length)); )
                                ;
                            e++,
                            a
                        }
                    }
                    o.timeout = setTimeout(function() {
                        if (e === t.length) {
                            if (o.options.onStringTyped(o.arrayPos),
                            o.arrayPos === o.strings.length - 1 && (o.options.callback(),
                            o.curLoop++,
                            !1 === o.loop || o.curLoop === o.loopCount))
                                return;
                            o.timeout = setTimeout(function() {
                                o.backspace(t, e)
                            }, o.backDelay)
                        } else {
                            0 === e && o.options.preStringTyped(o.arrayPos);
                            var i = t.substr(0, e + 1);
                            o.attr ? o.el.attr(o.attr, i) : o.isInput ? o.el.val(i) : "html" === o.contentType ? o.el.html(i) : o.el.text(i),
                            e++,
                            o.typewrite(t, e)
                        }
                    }, i)
                }, i)
            }
        },
        backspace: function(t, e) {
            if (!0 !== this.stop) {
                var i = Math.round(70 * Math.random()) + this.backSpeed
                  , o = this;
                o.timeout = setTimeout(function() {
                    if ("html" === o.contentType && ">" === t.substr(e).charAt(0)) {
                        for (; "<" !== t.substr(e - 1).charAt(0) && (t.substr(e).charAt(0),
                        !(--e < 0)); )
                            ;
                        e--,
                        "<"
                    }
                    var i = t.substr(0, e);
                    o.attr ? o.el.attr(o.attr, i) : o.isInput ? o.el.val(i) : "html" === o.contentType ? o.el.html(i) : o.el.text(i),
                    e > o.stopNum ? (e--,
                    o.backspace(t, e)) : e <= o.stopNum && (o.arrayPos++,
                    o.arrayPos === o.strings.length ? (o.arrayPos = 0,
                    o.shuffle && (o.sequence = o.shuffleArray(o.sequence)),
                    o.init()) : o.typewrite(o.strings[o.sequence[o.arrayPos]], e))
                }, i)
            }
        },
        shuffleArray: function(t) {
            var e, i, o = t.length;
            if (o)
                for (; --o; )
                    e = t[i = Math.floor(Math.random() * (o + 1))],
                    t[i] = t[o],
                    t[o] = e;
            return t
        },
        reset: function() {
            clearInterval(this.timeout);
            this.el.attr("id");
            this.el.empty(),
            void 0 !== this.cursor && this.cursor.remove(),
            this.strPos = 0,
            this.arrayPos = 0,
            this.curLoop = 0,
            this.options.resetCallback()
        }
    },
    t.fn.typed = function(i) {
        return this.each(function() {
            var o = t(this)
              , r = o.data("typed")
              , n = "object" == typeof i && i;
            r && r.reset(),
            o.data("typed", r = new e(this,n)),
            "string" == typeof i && r[i]()
        })
    }
    ,
    t.fn.typed.defaults = {
        strings: ["These are the default values...", "You know what you should do?", "Use your own!", "Have a great day!"],
        stringsElement: null,
        typeSpeed: 0,
        startDelay: 0,
        backSpeed: 0,
        shuffle: !1,
        backDelay: 500,
        loop: !1,
        loopCount: !1,
        showCursor: !0,
        cursorChar: "",
        attr: null,
        contentType: "html",
        callback: function() {},
        preStringTyped: function() {},
        onStringTyped: function() {},
        resetCallback: function() {}
    }
}(window.jQuery),
function(t, e, i, o) {
    function r(e, i) {
        this.settings = null,
        this.options = t.extend({}, r.Defaults, i),
        this.$element = t(e),
        this._handlers = {},
        this._plugins = {},
        this._supress = {},
        this._current = null,
        this._speed = null,
        this._coordinates = [],
        this._breakpoint = null,
        this._width = null,
        this._items = [],
        this._clones = [],
        this._mergers = [],
        this._widths = [],
        this._invalidated = {},
        this._pipe = [],
        this._drag = {
            time: null,
            target: null,
            pointer: null,
            stage: {
                start: null,
                current: null
            },
            direction: null
        },
        this._states = {
            current: {},
            tags: {
                initializing: ["busy"],
                animating: ["busy"],
                dragging: ["interacting"]
            }
        },
        t.each(["onResize", "onThrottledResize"], t.proxy(function(e, i) {
            this._handlers[i] = t.proxy(this[i], this)
        }, this)),
        t.each(r.Plugins, t.proxy(function(t, e) {
            this._plugins[t.charAt(0).toLowerCase() + t.slice(1)] = new e(this)
        }, this)),
        t.each(r.Workers, t.proxy(function(e, i) {
            this._pipe.push({
                filter: i.filter,
                run: t.proxy(i.run, this)
            })
        }, this)),
        this.setup(),
        this.initialize()
    }
    r.Defaults = {
        items: 3,
        loop: !1,
        center: !1,
        rewind: !1,
        mouseDrag: !0,
        touchDrag: !0,
        pullDrag: !0,
        freeDrag: !1,
        margin: 0,
        stagePadding: 0,
        merge: !1,
        mergeFit: !0,
        autoWidth: !1,
        startPosition: 0,
        rtl: !1,
        smartSpeed: 250,
        fluidSpeed: !1,
        dragEndSpeed: !1,
        responsive: {},
        responsiveRefreshRate: 200,
        responsiveBaseElement: e,
        fallbackEasing: "swing",
        info: !1,
        nestedItemSelector: !1,
        itemElement: "div",
        stageElement: "div",
        refreshClass: "owl-refresh",
        loadedClass: "owl-loaded",
        loadingClass: "owl-loading",
        rtlClass: "owl-rtl",
        responsiveClass: "owl-responsive",
        dragClass: "owl-drag",
        itemClass: "owl-item",
        stageClass: "owl-stage",
        stageOuterClass: "owl-stage-outer",
        grabClass: "owl-grab"
    },
    r.Width = {
        Default: "default",
        Inner: "inner",
        Outer: "outer"
    },
    r.Type = {
        Event: "event",
        State: "state"
    },
    r.Plugins = {},
    r.Workers = [{
        filter: ["width", "settings"],
        run: function() {
            this._width = this.$element.width()
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function(t) {
            t.current = this._items && this._items[this.relative(this._current)]
        }
    }, {
        filter: ["items", "settings"],
        run: function() {
            this.$stage.children(".cloned").remove()
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function(t) {
            var e = this.settings.margin || ""
              , i = !this.settings.autoWidth
              , o = this.settings.rtl
              , r = {
                width: "auto",
                "margin-left": o ? e : "",
                "margin-right": o ? "" : e
            };
            !i && this.$stage.children().css(r),
            t.css = r
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function(t) {
            var e = (this.width() / this.settings.items).toFixed(3) - this.settings.margin
              , i = null
              , o = this._items.length
              , r = !this.settings.autoWidth
              , n = [];
            for (t.items = {
                merge: !1,
                width: e
            }; o--; )
                i = this._mergers[o],
                i = this.settings.mergeFit && Math.min(i, this.settings.items) || i,
                t.items.merge = i > 1 || t.items.merge,
                n[o] = r ? e * i : this._items[o].width();
            this._widths = n
        }
    }, {
        filter: ["items", "settings"],
        run: function() {
            var e = []
              , i = this._items
              , o = this.settings
              , r = Math.max(2 * o.items, 4)
              , n = 2 * Math.ceil(i.length / 2)
              , s = o.loop && i.length ? o.rewind ? r : Math.max(r, n) : 0
              , a = ""
              , l = "";
            for (s /= 2; s--; )
                e.push(this.normalize(e.length / 2, !0)),
                a += i[e[e.length - 1]][0].outerHTML,
                e.push(this.normalize(i.length - 1 - (e.length - 1) / 2, !0)),
                l = i[e[e.length - 1]][0].outerHTML + l;
            this._clones = e,
            t(a).addClass("cloned").appendTo(this.$stage),
            t(l).addClass("cloned").prependTo(this.$stage)
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function() {
            for (var t = this.settings.rtl ? 1 : -1, e = this._clones.length + this._items.length, i = -1, o = 0, r = 0, n = []; ++i < e; )
                o = n[i - 1] || 0,
                r = this._widths[this.relative(i)] + this.settings.margin,
                n.push(o + r * t);
            this._coordinates = n
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function() {
            var t = this.settings.stagePadding
              , e = this._coordinates
              , i = {
                width: Math.ceil(Math.abs(e[e.length - 1])) + 2 * t,
                "padding-left": t || "",
                "padding-right": t || ""
            };
            this.$stage.css(i)
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function(t) {
            var e = this._coordinates.length
              , i = !this.settings.autoWidth
              , o = this.$stage.children();
            if (i && t.items.merge)
                for (; e--; )
                    t.css.width = this._widths[this.relative(e)],
                    o.eq(e).css(t.css);
            else
                i && (t.css.width = t.items.width,
                o.css(t.css))
        }
    }, {
        filter: ["items"],
        run: function() {
            this._coordinates.length < 1 && this.$stage.removeAttr("style")
        }
    }, {
        filter: ["width", "items", "settings"],
        run: function(t) {
            t.current = t.current ? this.$stage.children().index(t.current) : 0,
            t.current = Math.max(this.minimum(), Math.min(this.maximum(), t.current)),
            this.reset(t.current)
        }
    }, {
        filter: ["position"],
        run: function() {
            this.animate(this.coordinates(this._current))
        }
    }, {
        filter: ["width", "position", "items", "settings"],
        run: function() {
            var t, e, i, o, r = this.settings.rtl ? 1 : -1, n = 2 * this.settings.stagePadding, s = this.coordinates(this.current()) + n, a = s + this.width() * r, l = [];
            for (i = 0,
            o = this._coordinates.length; i < o; i++)
                t = this._coordinates[i - 1] || 0,
                e = Math.abs(this._coordinates[i]) + n * r,
                (this.op(t, "<=", s) && this.op(t, ">", a) || this.op(e, "<", s) && this.op(e, ">", a)) && l.push(i);
            this.$stage.children(".active").removeClass("active"),
            this.$stage.children(":eq(" + l.join("), :eq(") + ")").addClass("active"),
            this.settings.center && (this.$stage.children(".center").removeClass("center"),
            this.$stage.children().eq(this.current()).addClass("center"))
        }
    }],
    r.prototype.initialize = function() {
        var e, i, r;
        (this.enter("initializing"),
        this.trigger("initialize"),
        this.$element.toggleClass(this.settings.rtlClass, this.settings.rtl),
        this.settings.autoWidth && !this.is("pre-loading")) && (e = this.$element.find("img"),
        i = this.settings.nestedItemSelector ? "." + this.settings.nestedItemSelector : o,
        r = this.$element.children(i).width(),
        e.length && r <= 0 && this.preloadAutoWidthImages(e));
        this.$element.addClass(this.options.loadingClass),
        this.$stage = t("<" + this.settings.stageElement + ' class="' + this.settings.stageClass + '"/>').wrap('<div class="' + this.settings.stageOuterClass + '"/>'),
        this.$element.append(this.$stage.parent()),
        this.replace(this.$element.children().not(this.$stage.parent())),
        this.$element.is(":visible") ? this.refresh() : this.invalidate("width"),
        this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass),
        this.registerEventHandlers(),
        this.leave("initializing"),
        this.trigger("initialized")
    }
    ,
    r.prototype.setup = function() {
        var e = this.viewport()
          , i = this.options.responsive
          , o = -1
          , r = null;
        i ? (t.each(i, function(t) {
            t <= e && t > o && (o = Number(t))
        }),
        "function" == typeof (r = t.extend({}, this.options, i[o])).stagePadding && (r.stagePadding = r.stagePadding()),
        delete r.responsive,
        r.responsiveClass && this.$element.attr("class", this.$element.attr("class").replace(new RegExp("(" + this.options.responsiveClass + "-)\\S+\\s","g"), "$1" + o))) : r = t.extend({}, this.options),
        this.trigger("change", {
            property: {
                name: "settings",
                value: r
            }
        }),
        this._breakpoint = o,
        this.settings = r,
        this.invalidate("settings"),
        this.trigger("changed", {
            property: {
                name: "settings",
                value: this.settings
            }
        })
    }
    ,
    r.prototype.optionsLogic = function() {
        this.settings.autoWidth && (this.settings.stagePadding = !1,
        this.settings.merge = !1)
    }
    ,
    r.prototype.prepare = function(e) {
        var i = this.trigger("prepare", {
            content: e
        });
        return i.data || (i.data = t("<" + this.settings.itemElement + "/>").addClass(this.options.itemClass).append(e)),
        this.trigger("prepared", {
            content: i.data
        }),
        i.data
    }
    ,
    r.prototype.update = function() {
        for (var e = 0, i = this._pipe.length, o = t.proxy(function(t) {
            return this[t]
        }, this._invalidated), r = {}; e < i; )
            (this._invalidated.all || t.grep(this._pipe[e].filter, o).length > 0) && this._pipe[e].run(r),
            e++;
        this._invalidated = {},
        !this.is("valid") && this.enter("valid")
    }
    ,
    r.prototype.width = function(t) {
        switch (t = t || r.Width.Default) {
        case r.Width.Inner:
        case r.Width.Outer:
            return this._width;
        default:
            return this._width - 2 * this.settings.stagePadding + this.settings.margin
        }
    }
    ,
    r.prototype.refresh = function() {
        this.enter("refreshing"),
        this.trigger("refresh"),
        this.setup(),
        this.optionsLogic(),
        this.$element.addClass(this.options.refreshClass),
        this.update(),
        this.$element.removeClass(this.options.refreshClass),
        this.leave("refreshing"),
        this.trigger("refreshed")
    }
    ,
    r.prototype.onThrottledResize = function() {
        e.clearTimeout(this.resizeTimer),
        this.resizeTimer = e.setTimeout(this._handlers.onResize, this.settings.responsiveRefreshRate)
    }
    ,
    r.prototype.onResize = function() {
        return !!this._items.length && this._width !== this.$element.width() && !!this.$element.is(":visible") && (this.enter("resizing"),
        this.trigger("resize").isDefaultPrevented() ? (this.leave("resizing"),
        !1) : (this.invalidate("width"),
        this.refresh(),
        this.leave("resizing"),
        void this.trigger("resized")))
    }
    ,
    r.prototype.registerEventHandlers = function() {
        t.support.transition && this.$stage.on(t.support.transition.end + ".owl.core", t.proxy(this.onTransitionEnd, this)),
        !1 !== this.settings.responsive && this.on(e, "resize", this._handlers.onThrottledResize),
        this.settings.mouseDrag && (this.$element.addClass(this.options.dragClass),
        this.$stage.on("mousedown.owl.core", t.proxy(this.onDragStart, this)),
        this.$stage.on("dragstart.owl.core selectstart.owl.core", function() {
            return !1
        })),
        this.settings.touchDrag && (this.$stage.on("touchstart.owl.core", t.proxy(this.onDragStart, this)),
        this.$stage.on("touchcancel.owl.core", t.proxy(this.onDragEnd, this)))
    }
    ,
    r.prototype.onDragStart = function(e) {
        var o = null;
        3 !== e.which && (t.support.transform ? o = {
            x: (o = this.$stage.css("transform").replace(/.*\(|\)| /g, "").split(","))[16 === o.length ? 12 : 4],
            y: o[16 === o.length ? 13 : 5]
        } : (o = this.$stage.position(),
        o = {
            x: this.settings.rtl ? o.left + this.$stage.width() - this.width() + this.settings.margin : o.left,
            y: o.top
        }),
        this.is("animating") && (t.support.transform ? this.animate(o.x) : this.$stage.stop(),
        this.invalidate("position")),
        this.$element.toggleClass(this.options.grabClass, "mousedown" === e.type),
        this.speed(0),
        this._drag.time = (new Date).getTime(),
        this._drag.target = t(e.target),
        this._drag.stage.start = o,
        this._drag.stage.current = o,
        this._drag.pointer = this.pointer(e),
        t(i).on("mouseup.owl.core touchend.owl.core", t.proxy(this.onDragEnd, this)),
        t(i).one("mousemove.owl.core touchmove.owl.core", t.proxy(function(e) {
            var o = this.difference(this._drag.pointer, this.pointer(e));
            t(i).on("mousemove.owl.core touchmove.owl.core", t.proxy(this.onDragMove, this)),
            Math.abs(o.x) < Math.abs(o.y) && this.is("valid") || (e.preventDefault(),
            this.enter("dragging"),
            this.trigger("drag"))
        }, this)))
    }
    ,
    r.prototype.onDragMove = function(t) {
        var e = null
          , i = null
          , o = null
          , r = this.difference(this._drag.pointer, this.pointer(t))
          , n = this.difference(this._drag.stage.start, r);
        this.is("dragging") && (t.preventDefault(),
        this.settings.loop ? (e = this.coordinates(this.minimum()),
        i = this.coordinates(this.maximum() + 1) - e,
        n.x = ((n.x - e) % i + i) % i + e) : (e = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum()),
        i = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum()),
        o = this.settings.pullDrag ? -1 * r.x / 5 : 0,
        n.x = Math.max(Math.min(n.x, e + o), i + o)),
        this._drag.stage.current = n,
        this.animate(n.x))
    }
    ,
    r.prototype.onDragEnd = function(e) {
        var o = this.difference(this._drag.pointer, this.pointer(e))
          , r = this._drag.stage.current
          , n = o.x > 0 ^ this.settings.rtl ? "left" : "right";
        t(i).off(".owl.core"),
        this.$element.removeClass(this.options.grabClass),
        (0 !== o.x && this.is("dragging") || !this.is("valid")) && (this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed),
        this.current(this.closest(r.x, 0 !== o.x ? n : this._drag.direction)),
        this.invalidate("position"),
        this.update(),
        this._drag.direction = n,
        (Math.abs(o.x) > 3 || (new Date).getTime() - this._drag.time > 300) && this._drag.target.one("click.owl.core", function() {
            return !1
        })),
        this.is("dragging") && (this.leave("dragging"),
        this.trigger("dragged"))
    }
    ,
    r.prototype.closest = function(e, i) {
        var o = -1
          , r = this.width()
          , n = this.coordinates();
        return this.settings.freeDrag || t.each(n, t.proxy(function(t, s) {
            return "left" === i && e > s - 30 && e < s + 30 ? o = t : "right" === i && e > s - r - 30 && e < s - r + 30 ? o = t + 1 : this.op(e, "<", s) && this.op(e, ">", n[t + 1] || s - r) && (o = "left" === i ? t + 1 : t),
            -1 === o
        }, this)),
        this.settings.loop || (this.op(e, ">", n[this.minimum()]) ? o = e = this.minimum() : this.op(e, "<", n[this.maximum()]) && (o = e = this.maximum())),
        o
    }
    ,
    r.prototype.animate = function(e) {
        var i = this.speed() > 0;
        this.is("animating") && this.onTransitionEnd(),
        i && (this.enter("animating"),
        this.trigger("translate")),
        t.support.transform3d && t.support.transition ? this.$stage.css({
            transform: "translate3d(" + e + "px,0px,0px)",
            transition: this.speed() / 1e3 + "s"
        }) : i ? this.$stage.animate({
            left: e + "px"
        }, this.speed(), this.settings.fallbackEasing, t.proxy(this.onTransitionEnd, this)) : this.$stage.css({
            left: e + "px"
        })
    }
    ,
    r.prototype.is = function(t) {
        return this._states.current[t] && this._states.current[t] > 0
    }
    ,
    r.prototype.current = function(t) {
        if (t === o)
            return this._current;
        if (0 === this._items.length)
            return o;
        if (t = this.normalize(t),
        this._current !== t) {
            var e = this.trigger("change", {
                property: {
                    name: "position",
                    value: t
                }
            });
            e.data !== o && (t = this.normalize(e.data)),
            this._current = t,
            this.invalidate("position"),
            this.trigger("changed", {
                property: {
                    name: "position",
                    value: this._current
                }
            })
        }
        return this._current
    }
    ,
    r.prototype.invalidate = function(e) {
        return "string" === t.type(e) && (this._invalidated[e] = !0,
        this.is("valid") && this.leave("valid")),
        t.map(this._invalidated, function(t, e) {
            return e
        })
    }
    ,
    r.prototype.reset = function(t) {
        (t = this.normalize(t)) !== o && (this._speed = 0,
        this._current = t,
        this.suppress(["translate", "translated"]),
        this.animate(this.coordinates(t)),
        this.release(["translate", "translated"]))
    }
    ,
    r.prototype.normalize = function(t, e) {
        var i = this._items.length
          , r = e ? 0 : this._clones.length;
        return !this.isNumeric(t) || i < 1 ? t = o : (t < 0 || t >= i + r) && (t = ((t - r / 2) % i + i) % i + r / 2),
        t
    }
    ,
    r.prototype.relative = function(t) {
        return t -= this._clones.length / 2,
        this.normalize(t, !0)
    }
    ,
    r.prototype.maximum = function(t) {
        var e, i, o, r = this.settings, n = this._coordinates.length;
        if (r.loop)
            n = this._clones.length / 2 + this._items.length - 1;
        else if (r.autoWidth || r.merge) {
            for (e = this._items.length,
            i = this._items[--e].width(),
            o = this.$element.width(); e-- && !((i += this._items[e].width() + this.settings.margin) > o); )
                ;
            n = e + 1
        } else
            n = r.center ? this._items.length - 1 : this._items.length - r.items;
        return t && (n -= this._clones.length / 2),
        Math.max(n, 0)
    }
    ,
    r.prototype.minimum = function(t) {
        return t ? 0 : this._clones.length / 2
    }
    ,
    r.prototype.items = function(t) {
        return t === o ? this._items.slice() : (t = this.normalize(t, !0),
        this._items[t])
    }
    ,
    r.prototype.mergers = function(t) {
        return t === o ? this._mergers.slice() : (t = this.normalize(t, !0),
        this._mergers[t])
    }
    ,
    r.prototype.clones = function(e) {
        var i = this._clones.length / 2
          , r = i + this._items.length
          , n = function(t) {
            return t % 2 == 0 ? r + t / 2 : i - (t + 1) / 2
        };
        return e === o ? t.map(this._clones, function(t, e) {
            return n(e)
        }) : t.map(this._clones, function(t, i) {
            return t === e ? n(i) : null
        })
    }
    ,
    r.prototype.speed = function(t) {
        return t !== o && (this._speed = t),
        this._speed
    }
    ,
    r.prototype.coordinates = function(e) {
        var i, r = 1, n = e - 1;
        return e === o ? t.map(this._coordinates, t.proxy(function(t, e) {
            return this.coordinates(e)
        }, this)) : (this.settings.center ? (this.settings.rtl && (r = -1,
        n = e + 1),
        i = this._coordinates[e],
        i += (this.width() - i + (this._coordinates[n] || 0)) / 2 * r) : i = this._coordinates[n] || 0,
        i = Math.ceil(i))
    }
    ,
    r.prototype.duration = function(t, e, i) {
        return 0 === i ? 0 : Math.min(Math.max(Math.abs(e - t), 1), 6) * Math.abs(i || this.settings.smartSpeed)
    }
    ,
    r.prototype.to = function(t, e) {
        var i = this.current()
          , o = null
          , r = t - this.relative(i)
          , n = (r > 0) - (r < 0)
          , s = this._items.length
          , a = this.minimum()
          , l = this.maximum();
        this.settings.loop ? (!this.settings.rewind && Math.abs(r) > s / 2 && (r += -1 * n * s),
        (o = (((t = i + r) - a) % s + s) % s + a) !== t && o - r <= l && o - r > 0 && (i = o - r,
        t = o,
        this.reset(i))) : this.settings.rewind ? t = (t % (l += 1) + l) % l : t = Math.max(a, Math.min(l, t)),
        this.speed(this.duration(i, t, e)),
        this.current(t),
        this.$element.is(":visible") && this.update()
    }
    ,
    r.prototype.next = function(t) {
        t = t || !1,
        this.to(this.relative(this.current()) + 1, t)
    }
    ,
    r.prototype.prev = function(t) {
        t = t || !1,
        this.to(this.relative(this.current()) - 1, t)
    }
    ,
    r.prototype.onTransitionEnd = function(t) {
        if (t !== o && (t.stopPropagation(),
        (t.target || t.srcElement || t.originalTarget) !== this.$stage.get(0)))
            return !1;
        this.leave("animating"),
        this.trigger("translated")
    }
    ,
    r.prototype.viewport = function() {
        var o;
        return this.options.responsiveBaseElement !== e ? o = t(this.options.responsiveBaseElement).width() : e.innerWidth ? o = e.innerWidth : i.documentElement && i.documentElement.clientWidth ? o = i.documentElement.clientWidth : console.warn("Can not detect viewport width."),
        o
    }
    ,
    r.prototype.replace = function(e) {
        this.$stage.empty(),
        this._items = [],
        e && (e = e instanceof jQuery ? e : t(e)),
        this.settings.nestedItemSelector && (e = e.find("." + this.settings.nestedItemSelector)),
        e.filter(function() {
            return 1 === this.nodeType
        }).each(t.proxy(function(t, e) {
            e = this.prepare(e),
            this.$stage.append(e),
            this._items.push(e),
            this._mergers.push(1 * e.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)
        }, this)),
        this.reset(this.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0),
        this.invalidate("items")
    }
    ,
    r.prototype.add = function(e, i) {
        var r = this.relative(this._current);
        i = i === o ? this._items.length : this.normalize(i, !0),
        e = e instanceof jQuery ? e : t(e),
        this.trigger("add", {
            content: e,
            position: i
        }),
        e = this.prepare(e),
        0 === this._items.length || i === this._items.length ? (0 === this._items.length && this.$stage.append(e),
        0 !== this._items.length && this._items[i - 1].after(e),
        this._items.push(e),
        this._mergers.push(1 * e.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)) : (this._items[i].before(e),
        this._items.splice(i, 0, e),
        this._mergers.splice(i, 0, 1 * e.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)),
        this._items[r] && this.reset(this._items[r].index()),
        this.invalidate("items"),
        this.trigger("added", {
            content: e,
            position: i
        })
    }
    ,
    r.prototype.remove = function(t) {
        (t = this.normalize(t, !0)) !== o && (this.trigger("remove", {
            content: this._items[t],
            position: t
        }),
        this._items[t].remove(),
        this._items.splice(t, 1),
        this._mergers.splice(t, 1),
        this.invalidate("items"),
        this.trigger("removed", {
            content: null,
            position: t
        }))
    }
    ,
    r.prototype.preloadAutoWidthImages = function(e) {
        e.each(t.proxy(function(e, i) {
            this.enter("pre-loading"),
            i = t(i),
            t(new Image).one("load", t.proxy(function(t) {
                i.attr("src", t.target.src),
                i.css("opacity", 1),
                this.leave("pre-loading"),
                !this.is("pre-loading") && !this.is("initializing") && this.refresh()
            }, this)).attr("src", i.attr("src") || i.attr("data-src") || i.attr("data-src-retina"))
        }, this))
    }
    ,
    r.prototype.destroy = function() {
        for (var o in this.$element.off(".owl.core"),
        this.$stage.off(".owl.core"),
        t(i).off(".owl.core"),
        !1 !== this.settings.responsive && (e.clearTimeout(this.resizeTimer),
        this.off(e, "resize", this._handlers.onThrottledResize)),
        this._plugins)
            this._plugins[o].destroy();
        this.$stage.children(".cloned").remove(),
        this.$stage.unwrap(),
        this.$stage.children().contents().unwrap(),
        this.$stage.children().unwrap(),
        this.$element.removeClass(this.options.refreshClass).removeClass(this.options.loadingClass).removeClass(this.options.loadedClass).removeClass(this.options.rtlClass).removeClass(this.options.dragClass).removeClass(this.options.grabClass).attr("class", this.$element.attr("class").replace(new RegExp(this.options.responsiveClass + "-\\S+\\s","g"), "")).removeData("owl.carousel")
    }
    ,
    r.prototype.op = function(t, e, i) {
        var o = this.settings.rtl;
        switch (e) {
        case "<":
            return o ? t > i : t < i;
        case ">":
            return o ? t < i : t > i;
        case ">=":
            return o ? t <= i : t >= i;
        case "<=":
            return o ? t >= i : t <= i
        }
    }
    ,
    r.prototype.on = function(t, e, i, o) {
        t.addEventListener ? t.addEventListener(e, i, o) : t.attachEvent && t.attachEvent("on" + e, i)
    }
    ,
    r.prototype.off = function(t, e, i, o) {
        t.removeEventListener ? t.removeEventListener(e, i, o) : t.detachEvent && t.detachEvent("on" + e, i)
    }
    ,
    r.prototype.trigger = function(e, i, o, n, s) {
        var a = {
            item: {
                count: this._items.length,
                index: this.current()
            }
        }
          , l = t.camelCase(t.grep(["on", e, o], function(t) {
            return t
        }).join("-").toLowerCase())
          , c = t.Event([e, "owl", o || "carousel"].join(".").toLowerCase(), t.extend({
            relatedTarget: this
        }, a, i));
        return this._supress[e] || (t.each(this._plugins, function(t, e) {
            e.onTrigger && e.onTrigger(c)
        }),
        this.register({
            type: r.Type.Event,
            name: e
        }),
        this.$element.trigger(c),
        this.settings && "function" == typeof this.settings[l] && this.settings[l].call(this, c)),
        c
    }
    ,
    r.prototype.enter = function(e) {
        t.each([e].concat(this._states.tags[e] || []), t.proxy(function(t, e) {
            this._states.current[e] === o && (this._states.current[e] = 0),
            this._states.current[e]++
        }, this))
    }
    ,
    r.prototype.leave = function(e) {
        t.each([e].concat(this._states.tags[e] || []), t.proxy(function(t, e) {
            this._states.current[e]--
        }, this))
    }
    ,
    r.prototype.register = function(e) {
        if (e.type === r.Type.Event) {
            if (t.event.special[e.name] || (t.event.special[e.name] = {}),
            !t.event.special[e.name].owl) {
                var i = t.event.special[e.name]._default;
                t.event.special[e.name]._default = function(t) {
                    return !i || !i.apply || t.namespace && -1 !== t.namespace.indexOf("owl") ? t.namespace && t.namespace.indexOf("owl") > -1 : i.apply(this, arguments)
                }
                ,
                t.event.special[e.name].owl = !0
            }
        } else
            e.type === r.Type.State && (this._states.tags[e.name] ? this._states.tags[e.name] = this._states.tags[e.name].concat(e.tags) : this._states.tags[e.name] = e.tags,
            this._states.tags[e.name] = t.grep(this._states.tags[e.name], t.proxy(function(i, o) {
                return t.inArray(i, this._states.tags[e.name]) === o
            }, this)))
    }
    ,
    r.prototype.suppress = function(e) {
        t.each(e, t.proxy(function(t, e) {
            this._supress[e] = !0
        }, this))
    }
    ,
    r.prototype.release = function(e) {
        t.each(e, t.proxy(function(t, e) {
            delete this._supress[e]
        }, this))
    }
    ,
    r.prototype.pointer = function(t) {
        var i = {
            x: null,
            y: null
        };
        return (t = (t = t.originalEvent || t || e.event).touches && t.touches.length ? t.touches[0] : t.changedTouches && t.changedTouches.length ? t.changedTouches[0] : t).pageX ? (i.x = t.pageX,
        i.y = t.pageY) : (i.x = t.clientX,
        i.y = t.clientY),
        i
    }
    ,
    r.prototype.isNumeric = function(t) {
        return !isNaN(parseFloat(t))
    }
    ,
    r.prototype.difference = function(t, e) {
        return {
            x: t.x - e.x,
            y: t.y - e.y
        }
    }
    ,
    t.fn.owlCarousel = function(e) {
        var i = Array.prototype.slice.call(arguments, 1);
        return this.each(function() {
            var o = t(this)
              , n = o.data("owl.carousel");
            n || (n = new r(this,"object" == typeof e && e),
            o.data("owl.carousel", n),
            t.each(["next", "prev", "to", "destroy", "refresh", "replace", "add", "remove"], function(e, i) {
                n.register({
                    type: r.Type.Event,
                    name: i
                }),
                n.$element.on(i + ".owl.carousel.core", t.proxy(function(t) {
                    t.namespace && t.relatedTarget !== this && (this.suppress([i]),
                    n[i].apply(this, [].slice.call(arguments, 1)),
                    this.release([i]))
                }, n))
            })),
            "string" == typeof e && "_" !== e.charAt(0) && n[e].apply(n, i)
        })
    }
    ,
    t.fn.owlCarousel.Constructor = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this._core = e,
        this._interval = null,
        this._visible = null,
        this._handlers = {
            "initialized.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.autoRefresh && this.watch()
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this._core.$element.on(this._handlers)
    };
    r.Defaults = {
        autoRefresh: !0,
        autoRefreshInterval: 500
    },
    r.prototype.watch = function() {
        this._interval || (this._visible = this._core.$element.is(":visible"),
        this._interval = e.setInterval(t.proxy(this.refresh, this), this._core.settings.autoRefreshInterval))
    }
    ,
    r.prototype.refresh = function() {
        this._core.$element.is(":visible") !== this._visible && (this._visible = !this._visible,
        this._core.$element.toggleClass("owl-hidden", !this._visible),
        this._visible && this._core.invalidate("width") && this._core.refresh())
    }
    ,
    r.prototype.destroy = function() {
        var t, i;
        for (t in e.clearInterval(this._interval),
        this._handlers)
            this._core.$element.off(t, this._handlers[t]);
        for (i in Object.getOwnPropertyNames(this))
            "function" != typeof this[i] && (this[i] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.AutoRefresh = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this._core = e,
        this._loaded = [],
        this._handlers = {
            "initialized.owl.carousel change.owl.carousel resized.owl.carousel": t.proxy(function(e) {
                if (e.namespace && this._core.settings && this._core.settings.lazyLoad && (e.property && "position" == e.property.name || "initialized" == e.type))
                    for (var i = this._core.settings, o = i.center && Math.ceil(i.items / 2) || i.items, r = i.center && -1 * o || 0, n = (e.property && void 0 !== e.property.value ? e.property.value : this._core.current()) + r, s = this._core.clones().length, a = t.proxy(function(t, e) {
                        this.load(e)
                    }, this); r++ < o; )
                        this.load(s / 2 + this._core.relative(n)),
                        s && t.each(this._core.clones(this._core.relative(n)), a),
                        n++
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this._core.$element.on(this._handlers)
    };
    r.Defaults = {
        lazyLoad: !1
    },
    r.prototype.load = function(i) {
        var o = this._core.$stage.children().eq(i)
          , r = o && o.find(".owl-lazy");
        !r || t.inArray(o.get(0), this._loaded) > -1 || (r.each(t.proxy(function(i, o) {
            var r, n = t(o), s = e.devicePixelRatio > 1 && n.attr("data-src-retina") || n.attr("data-src");
            this._core.trigger("load", {
                element: n,
                url: s
            }, "lazy"),
            n.is("img") ? n.one("load.owl.lazy", t.proxy(function() {
                n.css("opacity", 1),
                this._core.trigger("loaded", {
                    element: n,
                    url: s
                }, "lazy")
            }, this)).attr("src", s) : ((r = new Image).onload = t.proxy(function() {
                n.css({
                    "background-image": 'url("' + s + '")',
                    opacity: "1"
                }),
                this._core.trigger("loaded", {
                    element: n,
                    url: s
                }, "lazy")
            }, this),
            r.src = s)
        }, this)),
        this._loaded.push(o.get(0)))
    }
    ,
    r.prototype.destroy = function() {
        var t, e;
        for (t in this.handlers)
            this._core.$element.off(t, this.handlers[t]);
        for (e in Object.getOwnPropertyNames(this))
            "function" != typeof this[e] && (this[e] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.Lazy = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this._core = e,
        this._handlers = {
            "initialized.owl.carousel refreshed.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.autoHeight && this.update()
            }, this),
            "changed.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.autoHeight && "position" == t.property.name && this.update()
            }, this),
            "loaded.owl.lazy": t.proxy(function(t) {
                t.namespace && this._core.settings.autoHeight && t.element.closest("." + this._core.settings.itemClass).index() === this._core.current() && this.update()
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this._core.$element.on(this._handlers)
    };
    r.Defaults = {
        autoHeight: !1,
        autoHeightClass: "owl-height"
    },
    r.prototype.update = function() {
        var e, i = this._core._current, o = i + this._core.settings.items, r = this._core.$stage.children().toArray().slice(i, o), n = [];
        t.each(r, function(e, i) {
            n.push(t(i).height())
        }),
        e = Math.max.apply(null, n),
        this._core.$stage.parent().height(e).addClass(this._core.settings.autoHeightClass)
    }
    ,
    r.prototype.destroy = function() {
        var t, e;
        for (t in this._handlers)
            this._core.$element.off(t, this._handlers[t]);
        for (e in Object.getOwnPropertyNames(this))
            "function" != typeof this[e] && (this[e] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.AutoHeight = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this._core = e,
        this._videos = {},
        this._playing = null,
        this._handlers = {
            "initialized.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.register({
                    type: "state",
                    name: "playing",
                    tags: ["interacting"]
                })
            }, this),
            "resize.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.video && this.isInFullScreen() && t.preventDefault()
            }, this),
            "refreshed.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.is("resizing") && this._core.$stage.find(".cloned .owl-video-frame").remove()
            }, this),
            "changed.owl.carousel": t.proxy(function(t) {
                t.namespace && "position" === t.property.name && this._playing && this.stop()
            }, this),
            "prepared.owl.carousel": t.proxy(function(e) {
                if (e.namespace) {
                    var i = t(e.content).find(".owl-video");
                    i.length && (i.css("display", "none"),
                    this.fetch(i, t(e.content)))
                }
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this._core.$element.on(this._handlers),
        this._core.$element.on("click.owl.video", ".owl-video-play-icon", t.proxy(function(t) {
            this.play(t)
        }, this))
    };
    r.Defaults = {
        video: !1,
        videoHeight: !1,
        videoWidth: !1
    },
    r.prototype.fetch = function(t, e) {
        var i = t.attr("data-vimeo-id") ? "vimeo" : t.attr("data-vzaar-id") ? "vzaar" : "youtube"
          , o = t.attr("data-vimeo-id") || t.attr("data-youtube-id") || t.attr("data-vzaar-id")
          , r = t.attr("data-width") || this._core.settings.videoWidth
          , n = t.attr("data-height") || this._core.settings.videoHeight
          , s = t.attr("href");
        if (!s)
            throw new Error("Missing video URL.");
        if ((o = s.match(/(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/))[3].indexOf("youtu") > -1)
            i = "youtube";
        else if (o[3].indexOf("vimeo") > -1)
            i = "vimeo";
        else {
            if (!(o[3].indexOf("vzaar") > -1))
                throw new Error("Video URL not supported.");
            i = "vzaar"
        }
        o = o[6],
        this._videos[s] = {
            type: i,
            id: o,
            width: r,
            height: n
        },
        e.attr("data-video", s),
        this.thumbnail(t, this._videos[s])
    }
    ,
    r.prototype.thumbnail = function(e, i) {
        var o, r, n = i.width && i.height ? 'style="width:' + i.width + "px;height:" + i.height + 'px;"' : "", s = e.find("img"), a = "src", l = "", c = this._core.settings, u = function(t) {
            '<div class="owl-video-play-icon"></div>',
            o = c.lazyLoad ? '<div class="owl-video-tn ' + l + '" ' + a + '="' + t + '"></div>' : '<div class="owl-video-tn" style="opacity:1;background-image:url(' + t + ')"></div>',
            e.after(o),
            e.after('<div class="owl-video-play-icon"></div>')
        };
        if (e.wrap('<div class="owl-video-wrapper"' + n + "></div>"),
        this._core.settings.lazyLoad && (a = "data-src",
        l = "owl-lazy"),
        s.length)
            return u(s.attr(a)),
            s.remove(),
            !1;
        "youtube" === i.type ? (r = "//img.youtube.com/vi/" + i.id + "/hqdefault.jpg",
        u(r)) : "vimeo" === i.type ? t.ajax({
            type: "GET",
            url: "//vimeo.com/api/v2/video/" + i.id + ".json",
            jsonp: "callback",
            dataType: "jsonp",
            success: function(t) {
                r = t[0].thumbnail_large,
                u(r)
            }
        }) : "vzaar" === i.type && t.ajax({
            type: "GET",
            url: "//vzaar.com/api/videos/" + i.id + ".json",
            jsonp: "callback",
            dataType: "jsonp",
            success: function(t) {
                r = t.framegrab_url,
                u(r)
            }
        })
    }
    ,
    r.prototype.stop = function() {
        this._core.trigger("stop", null, "video"),
        this._playing.find(".owl-video-frame").remove(),
        this._playing.removeClass("owl-video-playing"),
        this._playing = null,
        this._core.leave("playing"),
        this._core.trigger("stopped", null, "video")
    }
    ,
    r.prototype.play = function(e) {
        var i, o = t(e.target).closest("." + this._core.settings.itemClass), r = this._videos[o.attr("data-video")], n = r.width || "100%", s = r.height || this._core.$stage.height();
        this._playing || (this._core.enter("playing"),
        this._core.trigger("play", null, "video"),
        o = this._core.items(this._core.relative(o.index())),
        this._core.reset(o.index()),
        "youtube" === r.type ? i = '<iframe width="' + n + '" height="' + s + '" src="//www.youtube.com/embed/' + r.id + "?autoplay=1&rel=0&v=" + r.id + '" frameborder="0" allowfullscreen></iframe>' : "vimeo" === r.type ? i = '<iframe src="//player.vimeo.com/video/' + r.id + '?autoplay=1" width="' + n + '" height="' + s + '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>' : "vzaar" === r.type && (i = '<iframe frameborder="0"height="' + s + '"width="' + n + '" allowfullscreen mozallowfullscreen webkitAllowFullScreen src="//view.vzaar.com/' + r.id + '/player?autoplay=true"></iframe>'),
        t('<div class="owl-video-frame">' + i + "</div>").insertAfter(o.find(".owl-video")),
        this._playing = o.addClass("owl-video-playing"))
    }
    ,
    r.prototype.isInFullScreen = function() {
        var e = i.fullscreenElement || i.mozFullScreenElement || i.webkitFullscreenElement;
        return e && t(e).parent().hasClass("owl-video-frame")
    }
    ,
    r.prototype.destroy = function() {
        var t, e;
        for (t in this._core.$element.off("click.owl.video"),
        this._handlers)
            this._core.$element.off(t, this._handlers[t]);
        for (e in Object.getOwnPropertyNames(this))
            "function" != typeof this[e] && (this[e] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.Video = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this.core = e,
        this.core.options = t.extend({}, r.Defaults, this.core.options),
        this.swapping = !0,
        this.previous = o,
        this.next = o,
        this.handlers = {
            "change.owl.carousel": t.proxy(function(t) {
                t.namespace && "position" == t.property.name && (this.previous = this.core.current(),
                this.next = t.property.value)
            }, this),
            "drag.owl.carousel dragged.owl.carousel translated.owl.carousel": t.proxy(function(t) {
                t.namespace && (this.swapping = "translated" == t.type)
            }, this),
            "translate.owl.carousel": t.proxy(function(t) {
                t.namespace && this.swapping && (this.core.options.animateOut || this.core.options.animateIn) && this.swap()
            }, this)
        },
        this.core.$element.on(this.handlers)
    };
    r.Defaults = {
        animateOut: !1,
        animateIn: !1
    },
    r.prototype.swap = function() {
        if (1 === this.core.settings.items && t.support.animation && t.support.transition) {
            this.core.speed(0);
            var e, i = t.proxy(this.clear, this), o = this.core.$stage.children().eq(this.previous), r = this.core.$stage.children().eq(this.next), n = this.core.settings.animateIn, s = this.core.settings.animateOut;
            this.core.current() !== this.previous && (s && (e = this.core.coordinates(this.previous) - this.core.coordinates(this.next),
            o.one(t.support.animation.end, i).css({
                left: e + "px"
            }).addClass("animated owl-animated-out").addClass(s)),
            n && r.one(t.support.animation.end, i).addClass("animated owl-animated-in").addClass(n))
        }
    }
    ,
    r.prototype.clear = function(e) {
        t(e.target).css({
            left: ""
        }).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut),
        this.core.onTransitionEnd()
    }
    ,
    r.prototype.destroy = function() {
        var t, e;
        for (t in this.handlers)
            this.core.$element.off(t, this.handlers[t]);
        for (e in Object.getOwnPropertyNames(this))
            "function" != typeof this[e] && (this[e] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.Animate = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    var r = function(e) {
        this._core = e,
        this._timeout = null,
        this._paused = !1,
        this._handlers = {
            "changed.owl.carousel": t.proxy(function(t) {
                t.namespace && "settings" === t.property.name ? this._core.settings.autoplay ? this.play() : this.stop() : t.namespace && "position" === t.property.name && this._core.settings.autoplay && this._setAutoPlayInterval()
            }, this),
            "initialized.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.autoplay && this.play()
            }, this),
            "play.owl.autoplay": t.proxy(function(t, e, i) {
                t.namespace && this.play(e, i)
            }, this),
            "stop.owl.autoplay": t.proxy(function(t) {
                t.namespace && this.stop()
            }, this),
            "mouseover.owl.autoplay": t.proxy(function() {
                this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause()
            }, this),
            "mouseleave.owl.autoplay": t.proxy(function() {
                this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.play()
            }, this),
            "touchstart.owl.core": t.proxy(function() {
                this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause()
            }, this),
            "touchend.owl.core": t.proxy(function() {
                this._core.settings.autoplayHoverPause && this.play()
            }, this)
        },
        this._core.$element.on(this._handlers),
        this._core.options = t.extend({}, r.Defaults, this._core.options)
    };
    r.Defaults = {
        autoplay: !1,
        autoplayTimeout: 5e3,
        autoplayHoverPause: !1,
        autoplaySpeed: !1
    },
    r.prototype.play = function(t, e) {
        this._paused = !1,
        this._core.is("rotating") || (this._core.enter("rotating"),
        this._setAutoPlayInterval())
    }
    ,
    r.prototype._getNextTimeout = function(o, r) {
        return this._timeout && e.clearTimeout(this._timeout),
        e.setTimeout(t.proxy(function() {
            this._paused || this._core.is("busy") || this._core.is("interacting") || i.hidden || this._core.next(r || this._core.settings.autoplaySpeed)
        }, this), o || this._core.settings.autoplayTimeout)
    }
    ,
    r.prototype._setAutoPlayInterval = function() {
        this._timeout = this._getNextTimeout()
    }
    ,
    r.prototype.stop = function() {
        this._core.is("rotating") && (e.clearTimeout(this._timeout),
        this._core.leave("rotating"))
    }
    ,
    r.prototype.pause = function() {
        this._core.is("rotating") && (this._paused = !0)
    }
    ,
    r.prototype.destroy = function() {
        var t, e;
        for (t in this.stop(),
        this._handlers)
            this._core.$element.off(t, this._handlers[t]);
        for (e in Object.getOwnPropertyNames(this))
            "function" != typeof this[e] && (this[e] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.autoplay = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    "use strict";
    var r = function(e) {
        this._core = e,
        this._initialized = !1,
        this._pages = [],
        this._controls = {},
        this._templates = [],
        this.$element = this._core.$element,
        this._overrides = {
            next: this._core.next,
            prev: this._core.prev,
            to: this._core.to
        },
        this._handlers = {
            "prepared.owl.carousel": t.proxy(function(e) {
                e.namespace && this._core.settings.dotsData && this._templates.push('<div class="' + this._core.settings.dotClass + '">' + t(e.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot") + "</div>")
            }, this),
            "added.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.dotsData && this._templates.splice(t.position, 0, this._templates.pop())
            }, this),
            "remove.owl.carousel": t.proxy(function(t) {
                t.namespace && this._core.settings.dotsData && this._templates.splice(t.position, 1)
            }, this),
            "changed.owl.carousel": t.proxy(function(t) {
                t.namespace && "position" == t.property.name && this.draw()
            }, this),
            "initialized.owl.carousel": t.proxy(function(t) {
                t.namespace && !this._initialized && (this._core.trigger("initialize", null, "navigation"),
                this.initialize(),
                this.update(),
                this.draw(),
                this._initialized = !0,
                this._core.trigger("initialized", null, "navigation"))
            }, this),
            "refreshed.owl.carousel": t.proxy(function(t) {
                t.namespace && this._initialized && (this._core.trigger("refresh", null, "navigation"),
                this.update(),
                this.draw(),
                this._core.trigger("refreshed", null, "navigation"))
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this.$element.on(this._handlers)
    };
    r.Defaults = {
        nav: !1,
        navText: ["prev", "next"],
        navSpeed: !1,
        navElement: "div",
        navContainer: !1,
        navContainerClass: "owl-nav",
        navClass: ["owl-prev", "owl-next"],
        slideBy: 1,
        dotClass: "owl-dot",
        dotsClass: "owl-dots",
        dots: !0,
        dotsEach: !1,
        dotsData: !1,
        dotsSpeed: !1,
        dotsContainer: !1
    },
    r.prototype.initialize = function() {
        var e, i = this._core.settings;
        for (e in this._controls.$relative = (i.navContainer ? t(i.navContainer) : t("<div>").addClass(i.navContainerClass).appendTo(this.$element)).addClass("disabled"),
        this._controls.$previous = t("<" + i.navElement + ">").addClass(i.navClass[0]).html(i.navText[0]).prependTo(this._controls.$relative).on("click", t.proxy(function(t) {
            this.prev(i.navSpeed)
        }, this)),
        this._controls.$next = t("<" + i.navElement + ">").addClass(i.navClass[1]).html(i.navText[1]).appendTo(this._controls.$relative).on("click", t.proxy(function(t) {
            this.next(i.navSpeed)
        }, this)),
        i.dotsData || (this._templates = [t("<div>").addClass(i.dotClass).append(t("<span>")).prop("outerHTML")]),
        this._controls.$absolute = (i.dotsContainer ? t(i.dotsContainer) : t("<div>").addClass(i.dotsClass).appendTo(this.$element)).addClass("disabled"),
        this._controls.$absolute.on("click", "div", t.proxy(function(e) {
            var o = t(e.target).parent().is(this._controls.$absolute) ? t(e.target).index() : t(e.target).parent().index();
            e.preventDefault(),
            this.to(o, i.dotsSpeed)
        }, this)),
        this._overrides)
            this._core[e] = t.proxy(this[e], this)
    }
    ,
    r.prototype.destroy = function() {
        var t, e, i, o;
        for (t in this._handlers)
            this.$element.off(t, this._handlers[t]);
        for (e in this._controls)
            this._controls[e].remove();
        for (o in this.overides)
            this._core[o] = this._overrides[o];
        for (i in Object.getOwnPropertyNames(this))
            "function" != typeof this[i] && (this[i] = null)
    }
    ,
    r.prototype.update = function() {
        var t, e, i = this._core.clones().length / 2, o = i + this._core.items().length, r = this._core.maximum(!0), n = this._core.settings, s = n.center || n.autoWidth || n.dotsData ? 1 : n.dotsEach || n.items;
        if ("page" !== n.slideBy && (n.slideBy = Math.min(n.slideBy, n.items)),
        n.dots || "page" == n.slideBy)
            for (this._pages = [],
            t = i,
            e = 0,
            0; t < o; t++) {
                if (e >= s || 0 === e) {
                    if (this._pages.push({
                        start: Math.min(r, t - i),
                        end: t - i + s - 1
                    }),
                    Math.min(r, t - i) === r)
                        break;
                    e = 0,
                    0
                }
                e += this._core.mergers(this._core.relative(t))
            }
    }
    ,
    r.prototype.draw = function() {
        var e, i = this._core.settings, o = this._core.items().length <= i.items, r = this._core.relative(this._core.current()), n = i.loop || i.rewind;
        this._controls.$relative.toggleClass("disabled", !i.nav || o),
        i.nav && (this._controls.$previous.toggleClass("disabled", !n && r <= this._core.minimum(!0)),
        this._controls.$next.toggleClass("disabled", !n && r >= this._core.maximum(!0))),
        this._controls.$absolute.toggleClass("disabled", !i.dots || o),
        i.dots && (e = this._pages.length - this._controls.$absolute.children().length,
        i.dotsData && 0 !== e ? this._controls.$absolute.html(this._templates.join("")) : e > 0 ? this._controls.$absolute.append(new Array(e + 1).join(this._templates[0])) : e < 0 && this._controls.$absolute.children().slice(e).remove(),
        this._controls.$absolute.find(".active").removeClass("active"),
        this._controls.$absolute.children().eq(t.inArray(this.current(), this._pages)).addClass("active"))
    }
    ,
    r.prototype.onTrigger = function(e) {
        var i = this._core.settings;
        e.page = {
            index: t.inArray(this.current(), this._pages),
            count: this._pages.length,
            size: i && (i.center || i.autoWidth || i.dotsData ? 1 : i.dotsEach || i.items)
        }
    }
    ,
    r.prototype.current = function() {
        var e = this._core.relative(this._core.current());
        return t.grep(this._pages, t.proxy(function(t, i) {
            return t.start <= e && t.end >= e
        }, this)).pop()
    }
    ,
    r.prototype.getPosition = function(e) {
        var i, o, r = this._core.settings;
        return "page" == r.slideBy ? (i = t.inArray(this.current(), this._pages),
        o = this._pages.length,
        e ? ++i : --i,
        i = this._pages[(i % o + o) % o].start) : (i = this._core.relative(this._core.current()),
        o = this._core.items().length,
        e ? i += r.slideBy : i -= r.slideBy),
        i
    }
    ,
    r.prototype.next = function(e) {
        t.proxy(this._overrides.to, this._core)(this.getPosition(!0), e)
    }
    ,
    r.prototype.prev = function(e) {
        t.proxy(this._overrides.to, this._core)(this.getPosition(!1), e)
    }
    ,
    r.prototype.to = function(e, i, o) {
        var r;
        !o && this._pages.length ? (r = this._pages.length,
        t.proxy(this._overrides.to, this._core)(this._pages[(e % r + r) % r].start, i)) : t.proxy(this._overrides.to, this._core)(e, i)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.Navigation = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    "use strict";
    var r = function(i) {
        this._core = i,
        this._hashes = {},
        this.$element = this._core.$element,
        this._handlers = {
            "initialized.owl.carousel": t.proxy(function(i) {
                i.namespace && "URLHash" === this._core.settings.startPosition && t(e).trigger("hashchange.owl.navigation")
            }, this),
            "prepared.owl.carousel": t.proxy(function(e) {
                if (e.namespace) {
                    var i = t(e.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");
                    if (!i)
                        return;
                    this._hashes[i] = e.content
                }
            }, this),
            "changed.owl.carousel": t.proxy(function(i) {
                if (i.namespace && "position" === i.property.name) {
                    var o = this._core.items(this._core.relative(this._core.current()))
                      , r = t.map(this._hashes, function(t, e) {
                        return t === o ? e : null
                    }).join();
                    if (!r || e.location.hash.slice(1) === r)
                        return;
                    e.location.hash = r
                }
            }, this)
        },
        this._core.options = t.extend({}, r.Defaults, this._core.options),
        this.$element.on(this._handlers),
        t(e).on("hashchange.owl.navigation", t.proxy(function(t) {
            var i = e.location.hash.substring(1)
              , o = this._core.$stage.children()
              , r = this._hashes[i] && o.index(this._hashes[i]);
            void 0 !== r && r !== this._core.current() && this._core.to(this._core.relative(r), !1, !0)
        }, this))
    };
    r.Defaults = {
        URLhashListener: !1
    },
    r.prototype.destroy = function() {
        var i, o;
        for (i in t(e).off("hashchange.owl.navigation"),
        this._handlers)
            this._core.$element.off(i, this._handlers[i]);
        for (o in Object.getOwnPropertyNames(this))
            "function" != typeof this[o] && (this[o] = null)
    }
    ,
    t.fn.owlCarousel.Constructor.Plugins.Hash = r
}(window.Zepto || window.jQuery, window, document),
function(t, e, i, o) {
    function r(e, i) {
        var r = !1
          , n = e.charAt(0).toUpperCase() + e.slice(1);
        return t.each((e + " " + a.join(n + " ") + n).split(" "), function(t, e) {
            if (s[e] !== o)
                return r = !i || e,
                !1
        }),
        r
    }
    function n(t) {
        return r(t, !0)
    }
    var s = t("<support>").get(0).style
      , a = "Webkit Moz O ms".split(" ")
      , l = {
        transition: {
            end: {
                WebkitTransition: "webkitTransitionEnd",
                MozTransition: "transitionend",
                OTransition: "oTransitionEnd",
                transition: "transitionend"
            }
        },
        animation: {
            end: {
                WebkitAnimation: "webkitAnimationEnd",
                MozAnimation: "animationend",
                OAnimation: "oAnimationEnd",
                animation: "animationend"
            }
        }
    }
      , c = function() {
        return !!r("transform")
    }
      , u = function() {
        return !!r("perspective")
    }
      , h = function() {
        return !!r("animation")
    };
    (function() {
        return !!r("transition")
    }
    )() && (t.support.transition = new String(n("transition")),
    t.support.transition.end = l.transition.end[t.support.transition]),
    h() && (t.support.animation = new String(n("animation")),
    t.support.animation.end = l.animation.end[t.support.animation]),
    c() && (t.support.transform = new String(n("transform")),
    t.support.transform3d = u())
}(window.Zepto || window.jQuery, window, document),
function(t) {
    "function" == typeof define && define.amd ? define(["jquery"], t) : t("object" == typeof exports ? require("jquery") : window.jQuery || window.Zepto)
}(function(t) {
    var e, i, o, r, n, s, a = "Close", l = "BeforeClose", c = "MarkupParse", u = "Open", h = "Change", d = "mfp", p = "." + d, m = "mfp-ready", f = "mfp-removing", g = "mfp-prevent-close", y = function() {}, v = !!window.jQuery, w = t(window), b = function(t, i) {
        e.ev.on(d + t + p, i)
    }, x = function(e, i, o, r) {
        var n = document.createElement("div");
        return n.className = "mfp-" + e,
        o && (n.innerHTML = o),
        r ? i && i.appendChild(n) : (n = t(n),
        i && n.appendTo(i)),
        n
    }, T = function(i, o) {
        e.ev.triggerHandler(d + i, o),
        e.st.callbacks && (i = i.charAt(0).toLowerCase() + i.slice(1),
        e.st.callbacks[i] && e.st.callbacks[i].apply(e, t.isArray(o) ? o : [o]))
    }, _ = function(i) {
        return i === s && e.currTemplate.closeBtn || (e.currTemplate.closeBtn = t(e.st.closeMarkup.replace("%title%", e.st.tClose)),
        s = i),
        e.currTemplate.closeBtn
    }, P = function() {
        t.magnificPopup.instance || ((e = new y).init(),
        t.magnificPopup.instance = e)
    };
    y.prototype = {
        constructor: y,
        init: function() {
            var i = navigator.appVersion;
            e.isLowIE = e.isIE8 = document.all && !document.addEventListener,
            e.isAndroid = /android/gi.test(i),
            e.isIOS = /iphone|ipad|ipod/gi.test(i),
            e.supportsTransition = function() {
                var t = document.createElement("p").style
                  , e = ["ms", "O", "Moz", "Webkit"];
                if (void 0 !== t.transition)
                    return !0;
                for (; e.length; )
                    if (e.pop() + "Transition"in t)
                        return !0;
                return !1
            }(),
            e.probablyMobile = e.isAndroid || e.isIOS || /(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),
            o = t(document),
            e.popupsCache = {}
        },
        open: function(i) {
            var r;
            if (!1 === i.isObj) {
                e.items = i.items.toArray(),
                e.index = 0;
                var s, a = i.items;
                for (r = 0; r < a.length; r++)
                    if ((s = a[r]).parsed && (s = s.el[0]),
                    s === i.el[0]) {
                        e.index = r;
                        break
                    }
            } else
                e.items = t.isArray(i.items) ? i.items : [i.items],
                e.index = i.index || 0;
            if (!e.isOpen) {
                e.types = [],
                n = "",
                i.mainEl && i.mainEl.length ? e.ev = i.mainEl.eq(0) : e.ev = o,
                i.key ? (e.popupsCache[i.key] || (e.popupsCache[i.key] = {}),
                e.currTemplate = e.popupsCache[i.key]) : e.currTemplate = {},
                e.st = t.extend(!0, {}, t.magnificPopup.defaults, i),
                e.fixedContentPos = "auto" === e.st.fixedContentPos ? !e.probablyMobile : e.st.fixedContentPos,
                e.st.modal && (e.st.closeOnContentClick = !1,
                e.st.closeOnBgClick = !1,
                e.st.showCloseBtn = !1,
                e.st.enableEscapeKey = !1),
                e.bgOverlay || (e.bgOverlay = x("bg").on("click" + p, function() {
                    e.close()
                }),
                e.wrap = x("wrap").attr("tabindex", -1).on("click" + p, function(t) {
                    e._checkIfClose(t.target) && e.close()
                }),
                e.container = x("container", e.wrap)),
                e.contentContainer = x("content"),
                e.st.preloader && (e.preloader = x("preloader", e.container, e.st.tLoading));
                var l = t.magnificPopup.modules;
                for (r = 0; r < l.length; r++) {
                    var h = l[r];
                    h = h.charAt(0).toUpperCase() + h.slice(1),
                    e["init" + h].call(e)
                }
                T("BeforeOpen"),
                e.st.showCloseBtn && (e.st.closeBtnInside ? (b(c, function(t, e, i, o) {
                    i.close_replaceWith = _(o.type)
                }),
                n += " mfp-close-btn-in") : e.wrap.append(_())),
                e.st.alignTop && (n += " mfp-align-top"),
                e.fixedContentPos ? e.wrap.css({
                    overflow: e.st.overflowY,
                    overflowX: "hidden",
                    overflowY: e.st.overflowY
                }) : e.wrap.css({
                    top: w.scrollTop(),
                    position: "absolute"
                }),
                (!1 === e.st.fixedBgPos || "auto" === e.st.fixedBgPos && !e.fixedContentPos) && e.bgOverlay.css({
                    height: o.height(),
                    position: "absolute"
                }),
                e.st.enableEscapeKey && o.on("keyup" + p, function(t) {
                    27 === t.keyCode && e.close()
                }),
                w.on("resize" + p, function() {
                    e.updateSize()
                }),
                e.st.closeOnContentClick || (n += " mfp-auto-cursor"),
                n && e.wrap.addClass(n);
                var d = e.wH = w.height()
                  , f = {};
                if (e.fixedContentPos && e._hasScrollBar(d)) {
                    var g = e._getScrollbarSize();
                    g && (f.marginRight = g)
                }
                e.fixedContentPos && (e.isIE7 ? t("body, html").css("overflow", "hidden") : f.overflow = "hidden");
                var y = e.st.mainClass;
                return e.isIE7 && (y += " mfp-ie7"),
                y && e._addClassToMFP(y),
                e.updateItemHTML(),
                T("BuildControls"),
                t("html").css(f),
                e.bgOverlay.add(e.wrap).prependTo(e.st.prependTo || t(document.body)),
                e._lastFocusedEl = document.activeElement,
                setTimeout(function() {
                    e.content ? (e._addClassToMFP(m),
                    e._setFocus()) : e.bgOverlay.addClass(m),
                    o.on("focusin" + p, e._onFocusIn)
                }, 16),
                e.isOpen = !0,
                e.updateSize(d),
                T(u),
                i
            }
            e.updateItemHTML()
        },
        close: function() {
            e.isOpen && (T(l),
            e.isOpen = !1,
            e.st.removalDelay && !e.isLowIE && e.supportsTransition ? (e._addClassToMFP(f),
            setTimeout(function() {
                e._close()
            }, e.st.removalDelay)) : e._close())
        },
        _close: function() {
            T(a);
            var i = f + " " + m + " ";
            if (e.bgOverlay.detach(),
            e.wrap.detach(),
            e.container.empty(),
            e.st.mainClass && (i += e.st.mainClass + " "),
            e._removeClassFromMFP(i),
            e.fixedContentPos) {
                var r = {
                    marginRight: ""
                };
                e.isIE7 ? t("body, html").css("overflow", "") : r.overflow = "",
                t("html").css(r)
            }
            o.off("keyup.mfp focusin" + p),
            e.ev.off(p),
            e.wrap.attr("class", "mfp-wrap").removeAttr("style"),
            e.bgOverlay.attr("class", "mfp-bg"),
            e.container.attr("class", "mfp-container"),
            !e.st.showCloseBtn || e.st.closeBtnInside && !0 !== e.currTemplate[e.currItem.type] || e.currTemplate.closeBtn && e.currTemplate.closeBtn.detach(),
            e.st.autoFocusLast && e._lastFocusedEl && t(e._lastFocusedEl).focus(),
            e.currItem = null,
            e.content = null,
            e.currTemplate = null,
            e.prevHeight = 0,
            T("AfterClose")
        },
        updateSize: function(t) {
            if (e.isIOS) {
                var i = document.documentElement.clientWidth / window.innerWidth
                  , o = window.innerHeight * i;
                e.wrap.css("height", o),
                e.wH = o
            } else
                e.wH = t || w.height();
            e.fixedContentPos || e.wrap.css("height", e.wH),
            T("Resize")
        },
        updateItemHTML: function() {
            var i = e.items[e.index];
            e.contentContainer.detach(),
            e.content && e.content.detach(),
            i.parsed || (i = e.parseEl(e.index));
            var o = i.type;
            if (T("BeforeChange", [e.currItem ? e.currItem.type : "", o]),
            e.currItem = i,
            !e.currTemplate[o]) {
                var n = !!e.st[o] && e.st[o].markup;
                T("FirstMarkupParse", n),
                e.currTemplate[o] = !n || t(n)
            }
            r && r !== i.type && e.container.removeClass("mfp-" + r + "-holder");
            var s = e["get" + o.charAt(0).toUpperCase() + o.slice(1)](i, e.currTemplate[o]);
            e.appendContent(s, o),
            i.preloaded = !0,
            T(h, i),
            r = i.type,
            e.container.prepend(e.contentContainer),
            T("AfterChange")
        },
        appendContent: function(t, i) {
            e.content = t,
            t ? e.st.showCloseBtn && e.st.closeBtnInside && !0 === e.currTemplate[i] ? e.content.find(".mfp-close").length || e.content.append(_()) : e.content = t : e.content = "",
            T("BeforeAppend"),
            e.container.addClass("mfp-" + i + "-holder"),
            e.contentContainer.append(e.content)
        },
        parseEl: function(i) {
            var o, r = e.items[i];
            if (r.tagName ? r = {
                el: t(r)
            } : (o = r.type,
            r = {
                data: r,
                src: r.src
            }),
            r.el) {
                for (var n = e.types, s = 0; s < n.length; s++)
                    if (r.el.hasClass("mfp-" + n[s])) {
                        o = n[s];
                        break
                    }
                r.src = r.el.attr("data-mfp-src"),
                r.src || (r.src = r.el.attr("href"))
            }
            return r.type = o || e.st.type || "inline",
            r.index = i,
            r.parsed = !0,
            e.items[i] = r,
            T("ElementParse", r),
            e.items[i]
        },
        addGroup: function(t, i) {
            var o = function(o) {
                o.mfpEl = this,
                e._openClick(o, t, i)
            };
            i || (i = {});
            var r = "click.magnificPopup";
            i.mainEl = t,
            i.items ? (i.isObj = !0,
            t.off(r).on(r, o)) : (i.isObj = !1,
            i.delegate ? t.off(r).on(r, i.delegate, o) : (i.items = t,
            t.off(r).on(r, o)))
        },
        _openClick: function(i, o, r) {
            if ((void 0 !== r.midClick ? r.midClick : t.magnificPopup.defaults.midClick) || !(2 === i.which || i.ctrlKey || i.metaKey || i.altKey || i.shiftKey)) {
                var n = void 0 !== r.disableOn ? r.disableOn : t.magnificPopup.defaults.disableOn;
                if (n)
                    if (t.isFunction(n)) {
                        if (!n.call(e))
                            return !0
                    } else if (w.width() < n)
                        return !0;
                i.type && (i.preventDefault(),
                e.isOpen && i.stopPropagation()),
                r.el = t(i.mfpEl),
                r.delegate && (r.items = o.find(r.delegate)),
                e.open(r)
            }
        },
        updateStatus: function(t, o) {
            if (e.preloader) {
                i !== t && e.container.removeClass("mfp-s-" + i),
                o || "loading" !== t || (o = e.st.tLoading);
                var r = {
                    status: t,
                    text: o
                };
                T("UpdateStatus", r),
                t = r.status,
                o = r.text,
                e.preloader.html(o),
                e.preloader.find("a").on("click", function(t) {
                    t.stopImmediatePropagation()
                }),
                e.container.addClass("mfp-s-" + t),
                i = t
            }
        },
        _checkIfClose: function(i) {
            if (!t(i).hasClass(g)) {
                var o = e.st.closeOnContentClick
                  , r = e.st.closeOnBgClick;
                if (o && r)
                    return !0;
                if (!e.content || t(i).hasClass("mfp-close") || e.preloader && i === e.preloader[0])
                    return !0;
                if (i === e.content[0] || t.contains(e.content[0], i)) {
                    if (o)
                        return !0
                } else if (r && t.contains(document, i))
                    return !0;
                return !1
            }
        },
        _addClassToMFP: function(t) {
            e.bgOverlay.addClass(t),
            e.wrap.addClass(t)
        },
        _removeClassFromMFP: function(t) {
            this.bgOverlay.removeClass(t),
            e.wrap.removeClass(t)
        },
        _hasScrollBar: function(t) {
            return (e.isIE7 ? o.height() : document.body.scrollHeight) > (t || w.height())
        },
        _setFocus: function() {
            (e.st.focus ? e.content.find(e.st.focus).eq(0) : e.wrap).focus()
        },
        _onFocusIn: function(i) {
            return i.target === e.wrap[0] || t.contains(e.wrap[0], i.target) ? void 0 : (e._setFocus(),
            !1)
        },
        _parseMarkup: function(e, i, o) {
            var r;
            o.data && (i = t.extend(o.data, i)),
            T(c, [e, i, o]),
            t.each(i, function(i, o) {
                if (void 0 === o || !1 === o)
                    return !0;
                if ((r = i.split("_")).length > 1) {
                    var n = e.find(p + "-" + r[0]);
                    if (n.length > 0) {
                        var s = r[1];
                        "replaceWith" === s ? n[0] !== o[0] && n.replaceWith(o) : "img" === s ? n.is("img") ? n.attr("src", o) : n.replaceWith(t("<img>").attr("src", o).attr("class", n.attr("class"))) : n.attr(r[1], o)
                    }
                } else
                    e.find(p + "-" + i).html(o)
            })
        },
        _getScrollbarSize: function() {
            if (void 0 === e.scrollbarSize) {
                var t = document.createElement("div");
                t.style.cssText = "width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",
                document.body.appendChild(t),
                e.scrollbarSize = t.offsetWidth - t.clientWidth,
                document.body.removeChild(t)
            }
            return e.scrollbarSize
        }
    },
    t.magnificPopup = {
        instance: null,
        proto: y.prototype,
        modules: [],
        open: function(e, i) {
            return P(),
            (e = e ? t.extend(!0, {}, e) : {}).isObj = !0,
            e.index = i || 0,
            this.instance.open(e)
        },
        close: function() {
            return t.magnificPopup.instance && t.magnificPopup.instance.close()
        },
        registerModule: function(e, i) {
            i.options && (t.magnificPopup.defaults[e] = i.options),
            t.extend(this.proto, i.proto),
            this.modules.push(e)
        },
        defaults: {
            disableOn: 0,
            key: null,
            midClick: !1,
            mainClass: "",
            preloader: !0,
            focus: "",
            closeOnContentClick: !1,
            closeOnBgClick: !0,
            closeBtnInside: !0,
            showCloseBtn: !0,
            enableEscapeKey: !0,
            modal: !1,
            alignTop: !1,
            removalDelay: 0,
            prependTo: null,
            fixedContentPos: "auto",
            fixedBgPos: "auto",
            overflowY: "auto",
            closeMarkup: '<button title="%title%" type="button" class="mfp-close">&#215;</button>',
            tClose: "Close (Esc)",
            tLoading: "Loading...",
            autoFocusLast: !0
        }
    },
    t.fn.magnificPopup = function(i) {
        P();
        var o = t(this);
        if ("string" == typeof i)
            if ("open" === i) {
                var r, n = v ? o.data("magnificPopup") : o[0].magnificPopup, s = parseInt(arguments[1], 10) || 0;
                n.items ? r = n.items[s] : (r = o,
                n.delegate && (r = r.find(n.delegate)),
                r = r.eq(s)),
                e._openClick({
                    mfpEl: r
                }, o, n)
            } else
                e.isOpen && e[i].apply(e, Array.prototype.slice.call(arguments, 1));
        else
            i = t.extend(!0, {}, i),
            v ? o.data("magnificPopup", i) : o[0].magnificPopup = i,
            e.addGroup(o, i);
        return o
    }
    ;
    var S, C, k, E = "inline", z = function() {
        k && (C.after(k.addClass(S)).detach(),
        k = null)
    };
    t.magnificPopup.registerModule(E, {
        options: {
            hiddenClass: "hide",
            markup: "",
            tNotFound: "Content not found"
        },
        proto: {
            initInline: function() {
                e.types.push(E),
                b(a + "." + E, function() {
                    z()
                })
            },
            getInline: function(i, o) {
                if (z(),
                i.src) {
                    var r = e.st.inline
                      , n = t(i.src);
                    if (n.length) {
                        var s = n[0].parentNode;
                        s && s.tagName && (C || (S = r.hiddenClass,
                        C = x(S),
                        S = "mfp-" + S),
                        k = n.after(C).detach().removeClass(S)),
                        e.updateStatus("ready")
                    } else
                        e.updateStatus("error", r.tNotFound),
                        n = t("<div>");
                    return i.inlineElement = n,
                    n
                }
                return e.updateStatus("ready"),
                e._parseMarkup(o, {}, i),
                o
            }
        }
    });
    var I, j = "ajax", Y = function() {
        I && t(document.body).removeClass(I)
    }, A = function() {
        Y(),
        e.req && e.req.abort()
    };
    t.magnificPopup.registerModule(j, {
        options: {
            settings: null,
            cursor: "mfp-ajax-cur",
            tError: '<a href="%url%">The content</a> could not be loaded.'
        },
        proto: {
            initAjax: function() {
                e.types.push(j),
                I = e.st.ajax.cursor,
                b(a + "." + j, A),
                b("BeforeChange." + j, A)
            },
            getAjax: function(i) {
                I && t(document.body).addClass(I),
                e.updateStatus("loading");
                var o = t.extend({
                    url: i.src,
                    success: function(o, r, n) {
                        var s = {
                            data: o,
                            xhr: n
                        };
                        T("ParseAjax", s),
                        e.appendContent(t(s.data), j),
                        i.finished = !0,
                        Y(),
                        e._setFocus(),
                        setTimeout(function() {
                            e.wrap.addClass(m)
                        }, 16),
                        e.updateStatus("ready"),
                        T("AjaxContentAdded")
                    },
                    error: function() {
                        Y(),
                        i.finished = i.loadError = !0,
                        e.updateStatus("error", e.st.ajax.tError.replace("%url%", i.src))
                    }
                }, e.st.ajax.settings);
                return e.req = t.ajax(o),
                ""
            }
        }
    });
    var M, R = function(i) {
        if (i.data && void 0 !== i.data.title)
            return i.data.title;
        var o = e.st.image.titleSrc;
        if (o) {
            if (t.isFunction(o))
                return o.call(e, i);
            if (i.el)
                return i.el.attr(o) || ""
        }
        return ""
    };
    t.magnificPopup.registerModule("image", {
        options: {
            markup: '<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',
            cursor: "mfp-zoom-out-cur",
            titleSrc: "title",
            verticalFit: !0,
            tError: '<a href="%url%">The image</a> could not be loaded.'
        },
        proto: {
            initImage: function() {
                var i = e.st.image
                  , o = ".image";
                e.types.push("image"),
                b(u + o, function() {
                    "image" === e.currItem.type && i.cursor && t(document.body).addClass(i.cursor)
                }),
                b(a + o, function() {
                    i.cursor && t(document.body).removeClass(i.cursor),
                    w.off("resize" + p)
                }),
                b("Resize" + o, e.resizeImage),
                e.isLowIE && b("AfterChange", e.resizeImage)
            },
            resizeImage: function() {
                var t = e.currItem;
                if (t && t.img && e.st.image.verticalFit) {
                    var i = 0;
                    e.isLowIE && (i = parseInt(t.img.css("padding-top"), 10) + parseInt(t.img.css("padding-bottom"), 10)),
                    t.img.css("max-height", e.wH - i)
                }
            },
            _onImageHasSize: function(t) {
                t.img && (t.hasSize = !0,
                M && clearInterval(M),
                t.isCheckingImgSize = !1,
                T("ImageHasSize", t),
                t.imgHidden && (e.content && e.content.removeClass("mfp-loading"),
                t.imgHidden = !1))
            },
            findImageSize: function(t) {
                var i = 0
                  , o = t.img[0]
                  , r = function(n) {
                    M && clearInterval(M),
                    M = setInterval(function() {
                        return o.naturalWidth > 0 ? void e._onImageHasSize(t) : (i > 200 && clearInterval(M),
                        void (3 === ++i ? r(10) : 40 === i ? r(50) : 100 === i && r(500)))
                    }, n)
                };
                r(1)
            },
            getImage: function(i, o) {
                var r = 0
                  , n = function() {
                    i && (i.img[0].complete ? (i.img.off(".mfploader"),
                    i === e.currItem && (e._onImageHasSize(i),
                    e.updateStatus("ready")),
                    i.hasSize = !0,
                    i.loaded = !0,
                    T("ImageLoadComplete")) : 200 > ++r ? setTimeout(n, 100) : s())
                }
                  , s = function() {
                    i && (i.img.off(".mfploader"),
                    i === e.currItem && (e._onImageHasSize(i),
                    e.updateStatus("error", a.tError.replace("%url%", i.src))),
                    i.hasSize = !0,
                    i.loaded = !0,
                    i.loadError = !0)
                }
                  , a = e.st.image
                  , l = o.find(".mfp-img");
                if (l.length) {
                    var c = document.createElement("img");
                    c.className = "mfp-img",
                    i.el && i.el.find("img").length && (c.alt = i.el.find("img").attr("alt")),
                    i.img = t(c).on("load.mfploader", n).on("error.mfploader", s),
                    c.src = i.src,
                    l.is("img") && (i.img = i.img.clone()),
                    (c = i.img[0]).naturalWidth > 0 ? i.hasSize = !0 : c.width || (i.hasSize = !1)
                }
                return e._parseMarkup(o, {
                    title: R(i),
                    img_replaceWith: i.img
                }, i),
                e.resizeImage(),
                i.hasSize ? (M && clearInterval(M),
                i.loadError ? (o.addClass("mfp-loading"),
                e.updateStatus("error", a.tError.replace("%url%", i.src))) : (o.removeClass("mfp-loading"),
                e.updateStatus("ready")),
                o) : (e.updateStatus("loading"),
                i.loading = !0,
                i.hasSize || (i.imgHidden = !0,
                o.addClass("mfp-loading"),
                e.findImageSize(i)),
                o)
            }
        }
    });
    var L;
    t.magnificPopup.registerModule("zoom", {
        options: {
            enabled: !1,
            easing: "ease-in-out",
            duration: 300,
            opener: function(t) {
                return t.is("img") ? t : t.find("img")
            }
        },
        proto: {
            initZoom: function() {
                var t, i = e.st.zoom, o = ".zoom";
                if (i.enabled && e.supportsTransition) {
                    var r, n, s = i.duration, c = function(t) {
                        var e = t.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image")
                          , o = "all " + i.duration / 1e3 + "s " + i.easing
                          , r = {
                            position: "fixed",
                            zIndex: 9999,
                            left: 0,
                            top: 0,
                            "-webkit-backface-visibility": "hidden"
                        }
                          , n = "transition";
                        return r["-webkit-" + n] = r["-moz-" + n] = r["-o-" + n] = r[n] = o,
                        e.css(r),
                        e
                    }, u = function() {
                        e.content.css("visibility", "visible")
                    };
                    b("BuildControls" + o, function() {
                        if (e._allowZoom()) {
                            if (clearTimeout(r),
                            e.content.css("visibility", "hidden"),
                            !(t = e._getItemToZoom()))
                                return void u();
                            (n = c(t)).css(e._getOffset()),
                            e.wrap.append(n),
                            r = setTimeout(function() {
                                n.css(e._getOffset(!0)),
                                r = setTimeout(function() {
                                    u(),
                                    setTimeout(function() {
                                        n.remove(),
                                        t = n = null,
                                        T("ZoomAnimationEnded")
                                    }, 16)
                                }, s)
                            }, 16)
                        }
                    }),
                    b(l + o, function() {
                        if (e._allowZoom()) {
                            if (clearTimeout(r),
                            e.st.removalDelay = s,
                            !t) {
                                if (!(t = e._getItemToZoom()))
                                    return;
                                n = c(t)
                            }
                            n.css(e._getOffset(!0)),
                            e.wrap.append(n),
                            e.content.css("visibility", "hidden"),
                            setTimeout(function() {
                                n.css(e._getOffset())
                            }, 16)
                        }
                    }),
                    b(a + o, function() {
                        e._allowZoom() && (u(),
                        n && n.remove(),
                        t = null)
                    })
                }
            },
            _allowZoom: function() {
                return "image" === e.currItem.type
            },
            _getItemToZoom: function() {
                return !!e.currItem.hasSize && e.currItem.img
            },
            _getOffset: function(i) {
                var o, r = (o = i ? e.currItem.img : e.st.zoom.opener(e.currItem.el || e.currItem)).offset(), n = parseInt(o.css("padding-top"), 10), s = parseInt(o.css("padding-bottom"), 10);
                r.top -= t(window).scrollTop() - n;
                var a = {
                    width: o.width(),
                    height: (v ? o.innerHeight() : o[0].offsetHeight) - s - n
                };
                return void 0 === L && (L = void 0 !== document.createElement("p").style.MozTransform),
                L ? a["-moz-transform"] = a.transform = "translate(" + r.left + "px," + r.top + "px)" : (a.left = r.left,
                a.top = r.top),
                a
            }
        }
    });
    var D = "iframe"
      , Q = function(t) {
        if (e.currTemplate[D]) {
            var i = e.currTemplate[D].find("iframe");
            i.length && (t || (i[0].src = "//about:blank"),
            e.isIE8 && i.css("display", t ? "block" : "none"))
        }
    };
    t.magnificPopup.registerModule(D, {
        options: {
            markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',
            srcAction: "iframe_src",
            patterns: {
                youtube: {
                    index: "youtube.com",
                    id: "v=",
                    src: "//www.youtube.com/embed/%id%?autoplay=1"
                },
                vimeo: {
                    index: "vimeo.com/",
                    id: "/",
                    src: "//player.vimeo.com/video/%id%?autoplay=1"
                },
                gmaps: {
                    index: "//maps.google.",
                    src: "%id%&output=embed"
                }
            }
        },
        proto: {
            initIframe: function() {
                e.types.push(D),
                b("BeforeChange", function(t, e, i) {
                    e !== i && (e === D ? Q() : i === D && Q(!0))
                }),
                b(a + "." + D, function() {
                    Q()
                })
            },
            getIframe: function(i, o) {
                var r = i.src
                  , n = e.st.iframe;
                t.each(n.patterns, function() {
                    return r.indexOf(this.index) > -1 ? (this.id && (r = "string" == typeof this.id ? r.substr(r.lastIndexOf(this.id) + this.id.length, r.length) : this.id.call(this, r)),
                    r = this.src.replace("%id%", r),
                    !1) : void 0
                });
                var s = {};
                return n.srcAction && (s[n.srcAction] = r),
                e._parseMarkup(o, s, i),
                e.updateStatus("ready"),
                o
            }
        }
    });
    var O = function(t) {
        var i = e.items.length;
        return t > i - 1 ? t - i : 0 > t ? i + t : t
    }
      , F = function(t, e, i) {
        return t.replace(/%curr%/gi, e + 1).replace(/%total%/gi, i)
    };
    t.magnificPopup.registerModule("gallery", {
        options: {
            enabled: !1,
            arrowMarkup: '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',
            preload: [0, 2],
            navigateByImgClick: !0,
            arrows: !0,
            tPrev: "Previous (Left arrow key)",
            tNext: "Next (Right arrow key)",
            tCounter: "%curr% of %total%"
        },
        proto: {
            initGallery: function() {
                var i = e.st.gallery
                  , r = ".mfp-gallery";
                return e.direction = !0,
                !(!i || !i.enabled) && (n += " mfp-gallery",
                b(u + r, function() {
                    i.navigateByImgClick && e.wrap.on("click" + r, ".mfp-img", function() {
                        return e.items.length > 1 ? (e.next(),
                        !1) : void 0
                    }),
                    o.on("keydown" + r, function(t) {
                        37 === t.keyCode ? e.prev() : 39 === t.keyCode && e.next()
                    })
                }),
                b("UpdateStatus" + r, function(t, i) {
                    i.text && (i.text = F(i.text, e.currItem.index, e.items.length))
                }),
                b(c + r, function(t, o, r, n) {
                    var s = e.items.length;
                    r.counter = s > 1 ? F(i.tCounter, n.index, s) : ""
                }),
                b("BuildControls" + r, function() {
                    if (e.items.length > 1 && i.arrows && !e.arrowLeft) {
                        var o = i.arrowMarkup
                          , r = e.arrowLeft = t(o.replace(/%title%/gi, i.tPrev).replace(/%dir%/gi, "left")).addClass(g)
                          , n = e.arrowRight = t(o.replace(/%title%/gi, i.tNext).replace(/%dir%/gi, "right")).addClass(g);
                        r.click(function() {
                            e.prev()
                        }),
                        n.click(function() {
                            e.next()
                        }),
                        e.container.append(r.add(n))
                    }
                }),
                b(h + r, function() {
                    e._preloadTimeout && clearTimeout(e._preloadTimeout),
                    e._preloadTimeout = setTimeout(function() {
                        e.preloadNearbyImages(),
                        e._preloadTimeout = null
                    }, 16)
                }),
                void b(a + r, function() {
                    o.off(r),
                    e.wrap.off("click" + r),
                    e.arrowRight = e.arrowLeft = null
                }))
            },
            next: function() {
                e.direction = !0,
                e.index = O(e.index + 1),
                e.updateItemHTML()
            },
            prev: function() {
                e.direction = !1,
                e.index = O(e.index - 1),
                e.updateItemHTML()
            },
            goTo: function(t) {
                e.direction = t >= e.index,
                e.index = t,
                e.updateItemHTML()
            },
            preloadNearbyImages: function() {
                var t, i = e.st.gallery.preload, o = Math.min(i[0], e.items.length), r = Math.min(i[1], e.items.length);
                for (t = 1; t <= (e.direction ? r : o); t++)
                    e._preloadItem(e.index + t);
                for (t = 1; t <= (e.direction ? o : r); t++)
                    e._preloadItem(e.index - t)
            },
            _preloadItem: function(i) {
                if (i = O(i),
                !e.items[i].preloaded) {
                    var o = e.items[i];
                    o.parsed || (o = e.parseEl(i)),
                    T("LazyLoad", o),
                    "image" === o.type && (o.img = t('<img class="mfp-img" />').on("load.mfploader", function() {
                        o.hasSize = !0
                    }).on("error.mfploader", function() {
                        o.hasSize = !0,
                        o.loadError = !0,
                        T("LazyLoadError", o)
                    }).attr("src", o.src)),
                    o.preloaded = !0
                }
            }
        }
    });
    var B = "retina";
    t.magnificPopup.registerModule(B, {
        options: {
            replaceSrc: function(t) {
                return t.src.replace(/\.\w+$/, function(t) {
                    return "@2x" + t
                })
            },
            ratio: 1
        },
        proto: {
            initRetina: function() {
                if (window.devicePixelRatio > 1) {
                    var t = e.st.retina
                      , i = t.ratio;
                    (i = isNaN(i) ? i() : i) > 1 && (b("ImageHasSize." + B, function(t, e) {
                        e.img.css({
                            "max-width": e.img[0].naturalWidth / i,
                            width: "100%"
                        })
                    }),
                    b("ElementParse." + B, function(e, o) {
                        o.src = t.replaceSrc(o, i)
                    }))
                }
            }
        }
    }),
    P()
}),
function(t, e) {
    if ("function" == typeof define && define.amd)
        define(["module", "exports"], e);
    else if ("undefined" != typeof exports)
        e(module, exports);
    else {
        var i = {
            exports: {}
        };
        e(i, i.exports),
        t.WOW = i.exports
    }
}(this, function(t, e) {
    "use strict";
    function i(t, e) {
        if (!(t instanceof e))
            throw new TypeError("Cannot call a class as a function")
    }
    function o(t, e) {
        return e.indexOf(t) >= 0
    }
    function r(t, e, i) {
        null != t.addEventListener ? t.addEventListener(e, i, !1) : null != t.attachEvent ? t.attachEvent("on" + e, i) : t[e] = i
    }
    function n(t, e, i) {
        null != t.removeEventListener ? t.removeEventListener(e, i, !1) : null != t.detachEvent ? t.detachEvent("on" + e, i) : delete t[e]
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var s, a, l = function() {
        function t(t, e) {
            for (var i = 0; i < e.length; i++) {
                var o = e[i];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(t, o.key, o)
            }
        }
        return function(e, i, o) {
            return i && t(e.prototype, i),
            o && t(e, o),
            e
        }
    }(), c = window.WeakMap || window.MozWeakMap || function() {
        function t() {
            i(this, t),
            this.keys = [],
            this.values = []
        }
        return l(t, [{
            key: "get",
            value: function(t) {
                for (var e = 0; e < this.keys.length; e++) {
                    if (this.keys[e] === t)
                        return this.values[e]
                }
            }
        }, {
            key: "set",
            value: function(t, e) {
                for (var i = 0; i < this.keys.length; i++) {
                    if (this.keys[i] === t)
                        return this.values[i] = e,
                        this
                }
                return this.keys.push(t),
                this.values.push(e),
                this
            }
        }]),
        t
    }(), u = window.MutationObserver || window.WebkitMutationObserver || window.MozMutationObserver || (a = s = function() {
        function t() {
            i(this, t),
            "undefined" != typeof console && null !== console && (console.warn("MutationObserver is not supported by your browser."),
            console.warn("WOW.js cannot detect dom mutations, please call .sync() after loading new content."))
        }
        return l(t, [{
            key: "observe",
            value: function() {}
        }]),
        t
    }(),
    s.notSupported = !0,
    a), h = window.getComputedStyle || function(t) {
        var e = /(\-([a-z]){1})/g;
        return {
            getPropertyValue: function(i) {
                "float" === i && (i = "styleFloat"),
                e.test(i) && i.replace(e, function(t, e) {
                    return e.toUpperCase()
                });
                var o = t.currentStyle;
                return (null != o ? o[i] : void 0) || null
            }
        }
    }
    , d = function() {
        function t() {
            var e = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
            i(this, t),
            this.defaults = {
                boxClass: "wow",
                animateClass: "animated",
                offset: 0,
                mobile: !0,
                live: !0,
                callback: null,
                scrollContainer: null,
                resetAnimation: !0
            },
            this.animate = "requestAnimationFrame"in window ? function(t) {
                return window.requestAnimationFrame(t)
            }
            : function(t) {
                return t()
            }
            ,
            this.vendors = ["moz", "webkit"],
            this.start = this.start.bind(this),
            this.resetAnimation = this.resetAnimation.bind(this),
            this.scrollHandler = this.scrollHandler.bind(this),
            this.scrollCallback = this.scrollCallback.bind(this),
            this.scrolled = !0,
            this.config = function(t, e) {
                for (var i in e)
                    if (null == t[i]) {
                        var o = e[i];
                        t[i] = o
                    }
                return t
            }(e, this.defaults),
            null != e.scrollContainer && (this.config.scrollContainer = document.querySelector(e.scrollContainer)),
            this.animationNameCache = new c,
            this.wowEvent = function(t) {
                var e = !(arguments.length <= 1 || void 0 === arguments[1]) && arguments[1]
                  , i = !(arguments.length <= 2 || void 0 === arguments[2]) && arguments[2]
                  , o = arguments.length <= 3 || void 0 === arguments[3] ? null : arguments[3]
                  , r = void 0;
                return null != document.createEvent ? (r = document.createEvent("CustomEvent")).initCustomEvent(t, e, i, o) : null != document.createEventObject ? (r = document.createEventObject()).eventType = t : r.eventName = t,
                r
            }(this.config.boxClass)
        }
        return l(t, [{
            key: "init",
            value: function() {
                this.element = window.document.documentElement,
                o(document.readyState, ["interactive", "complete"]) ? this.start() : r(document, "DOMContentLoaded", this.start),
                this.finished = []
            }
        }, {
            key: "start",
            value: function() {
                var t = this;
                if (this.stopped = !1,
                this.boxes = [].slice.call(this.element.querySelectorAll("." + this.config.boxClass)),
                this.all = this.boxes.slice(0),
                this.boxes.length)
                    if (this.disabled())
                        this.resetStyle();
                    else
                        for (var e = 0; e < this.boxes.length; e++) {
                            var i = this.boxes[e];
                            this.applyStyle(i, !0)
                        }
                (this.disabled() || (r(this.config.scrollContainer || window, "scroll", this.scrollHandler),
                r(window, "resize", this.scrollHandler),
                this.interval = setInterval(this.scrollCallback, 50)),
                this.config.live) && new u(function(e) {
                    for (var i = 0; i < e.length; i++)
                        for (var o = e[i], r = 0; r < o.addedNodes.length; r++) {
                            var n = o.addedNodes[r];
                            t.doSync(n)
                        }
                }
                ).observe(document.body, {
                    childList: !0,
                    subtree: !0
                })
            }
        }, {
            key: "stop",
            value: function() {
                this.stopped = !0,
                n(this.config.scrollContainer || window, "scroll", this.scrollHandler),
                n(window, "resize", this.scrollHandler),
                null != this.interval && clearInterval(this.interval)
            }
        }, {
            key: "sync",
            value: function() {
                u.notSupported && this.doSync(this.element)
            }
        }, {
            key: "doSync",
            value: function(t) {
                if (null != t || (t = this.element),
                1 === t.nodeType)
                    for (var e = (t = t.parentNode || t).querySelectorAll("." + this.config.boxClass), i = 0; i < e.length; i++) {
                        var r = e[i];
                        o(r, this.all) || (this.boxes.push(r),
                        this.all.push(r),
                        this.stopped || this.disabled() ? this.resetStyle() : this.applyStyle(r, !0),
                        this.scrolled = !0)
                    }
            }
        }, {
            key: "show",
            value: function(t) {
                return this.applyStyle(t),
                t.className = t.className + " " + this.config.animateClass,
                null != this.config.callback && this.config.callback(t),
                function(t, e) {
                    null != t.dispatchEvent ? t.dispatchEvent(e) : e in (null != t) ? t[e]() : "on" + e in (null != t) && t["on" + e]()
                }(t, this.wowEvent),
                this.config.resetAnimation && (r(t, "animationend", this.resetAnimation),
                r(t, "oanimationend", this.resetAnimation),
                r(t, "webkitAnimationEnd", this.resetAnimation),
                r(t, "MSAnimationEnd", this.resetAnimation)),
                t
            }
        }, {
            key: "applyStyle",
            value: function(t, e) {
                var i = this
                  , o = t.getAttribute("data-wow-duration")
                  , r = t.getAttribute("data-wow-delay")
                  , n = t.getAttribute("data-wow-iteration");
                return this.animate(function() {
                    return i.customStyle(t, e, o, r, n)
                })
            }
        }, {
            key: "resetStyle",
            value: function() {
                for (var t = 0; t < this.boxes.length; t++) {
                    this.boxes[t].style.visibility = "visible"
                }
            }
        }, {
            key: "resetAnimation",
            value: function(t) {
                if (t.type.toLowerCase().indexOf("animationend") >= 0) {
                    var e = t.target || t.srcElement;
                    e.className = e.className.replace(this.config.animateClass, "").trim()
                }
            }
        }, {
            key: "customStyle",
            value: function(t, e, i, o, r) {
                return e && this.cacheAnimationName(t),
                t.style.visibility = e ? "hidden" : "visible",
                i && this.vendorSet(t.style, {
                    animationDuration: i
                }),
                o && this.vendorSet(t.style, {
                    animationDelay: o
                }),
                r && this.vendorSet(t.style, {
                    animationIterationCount: r
                }),
                this.vendorSet(t.style, {
                    animationName: e ? "none" : this.cachedAnimationName(t)
                }),
                t
            }
        }, {
            key: "vendorSet",
            value: function(t, e) {
                for (var i in e)
                    if (e.hasOwnProperty(i)) {
                        var o = e[i];
                        t["" + i] = o;
                        for (var r = 0; r < this.vendors.length; r++) {
                            t["" + this.vendors[r] + i.charAt(0).toUpperCase() + i.substr(1)] = o
                        }
                    }
            }
        }, {
            key: "vendorCSS",
            value: function(t, e) {
                for (var i = h(t), o = i.getPropertyCSSValue(e), r = 0; r < this.vendors.length; r++) {
                    var n = this.vendors[r];
                    o = o || i.getPropertyCSSValue("-" + n + "-" + e)
                }
                return o
            }
        }, {
            key: "animationName",
            value: function(t) {
                var e = void 0;
                try {
                    e = this.vendorCSS(t, "animation-name").cssText
                } catch (i) {
                    e = h(t).getPropertyValue("animation-name")
                }
                return "none" === e ? "" : e
            }
        }, {
            key: "cacheAnimationName",
            value: function(t) {
                return this.animationNameCache.set(t, this.animationName(t))
            }
        }, {
            key: "cachedAnimationName",
            value: function(t) {
                return this.animationNameCache.get(t)
            }
        }, {
            key: "scrollHandler",
            value: function() {
                this.scrolled = !0
            }
        }, {
            key: "scrollCallback",
            value: function() {
                if (this.scrolled) {
                    this.scrolled = !1;
                    for (var t = [], e = 0; e < this.boxes.length; e++) {
                        var i = this.boxes[e];
                        if (i) {
                            if (this.isVisible(i)) {
                                this.show(i);
                                continue
                            }
                            t.push(i)
                        }
                    }
                    this.boxes = t,
                    this.boxes.length || this.config.live || this.stop()
                }
            }
        }, {
            key: "offsetTop",
            value: function(t) {
                for (; void 0 === t.offsetTop; )
                    t = t.parentNode;
                for (var e = t.offsetTop; t.offsetParent; )
                    e += (t = t.offsetParent).offsetTop;
                return e
            }
        }, {
            key: "isVisible",
            value: function(t) {
                var e = t.getAttribute("data-wow-offset") || this.config.offset
                  , i = this.config.scrollContainer && this.config.scrollContainer.scrollTop || window.pageYOffset
                  , o = i + Math.min(this.element.clientHeight, "innerHeight"in window ? window.innerHeight : document.documentElement.clientHeight) - e
                  , r = this.offsetTop(t)
                  , n = r + t.clientHeight;
                return o >= r && n >= i
            }
        }, {
            key: "disabled",
            value: function() {
                return !this.config.mobile && (t = navigator.userAgent,
                /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(t));
                var t
            }
        }]),
        t
    }();
    e.default = d,
    t.exports = e.default
}),
function(t) {
    "use strict";
    var e = {
        slide: 0,
        delay: 5e3,
        loop: !0,
        preload: !1,
        preloadImage: !1,
        preloadVideo: !1,
        timer: !0,
        overlay: !1,
        autoplay: !0,
        shuffle: !1,
        cover: !0,
        color: null,
        align: "center",
        valign: "center",
        firstTransition: null,
        firstTransitionDuration: null,
        transition: "fade",
        transitionDuration: 1e3,
        transitionRegister: [],
        animation: null,
        animationDuration: "auto",
        animationRegister: [],
        slidesToKeep: 1,
        init: function() {},
        play: function() {},
        pause: function() {},
        walk: function() {},
        slides: []
    }
      , i = {}
      , o = function(i, o) {
        this.elmt = i,
        this.settings = t.extend({}, e, t.vegas.defaults, o),
        this.slide = this.settings.slide,
        this.total = this.settings.slides.length,
        this.noshow = this.total < 2,
        this.paused = !this.settings.autoplay || this.noshow,
        this.ended = !1,
        this.$elmt = t(i),
        this.$timer = null,
        this.$overlay = null,
        this.$slide = null,
        this.timeout = null,
        this.first = !0,
        this.transitions = ["fade", "fade2", "blur", "blur2", "flash", "flash2", "negative", "negative2", "burn", "burn2", "slideLeft", "slideLeft2", "slideRight", "slideRight2", "slideUp", "slideUp2", "slideDown", "slideDown2", "zoomIn", "zoomIn2", "zoomOut", "zoomOut2", "swirlLeft", "swirlLeft2", "swirlRight", "swirlRight2"],
        this.animations = ["kenburns", "kenburnsLeft", "kenburnsRight", "kenburnsUp", "kenburnsUpLeft", "kenburnsUpRight", "kenburnsDown", "kenburnsDownLeft", "kenburnsDownRight"],
        this.settings.transitionRegister instanceof Array == 0 && (this.settings.transitionRegister = [this.settings.transitionRegister]),
        this.settings.animationRegister instanceof Array == 0 && (this.settings.animationRegister = [this.settings.animationRegister]),
        this.transitions = this.transitions.concat(this.settings.transitionRegister),
        this.animations = this.animations.concat(this.settings.animationRegister),
        this.support = {
            objectFit: "objectFit"in document.body.style,
            transition: "transition"in document.body.style || "WebkitTransition"in document.body.style,
            video: t.vegas.isVideoCompatible()
        },
        !0 === this.settings.shuffle && this.shuffle(),
        this._init()
    };
    o.prototype = {
        _init: function() {
            var e, i, o, r = "BODY" === this.elmt.tagName, n = this.settings.timer, s = this.settings.overlay, a = this;
            this._preload(),
            r || (this.$elmt.css("height", this.$elmt.css("height")),
            e = t('<div class="vegas-wrapper">').css("overflow", this.$elmt.css("overflow")).css("padding", this.$elmt.css("padding")),
            this.$elmt.css("padding") || e.css("padding-top", this.$elmt.css("padding-top")).css("padding-bottom", this.$elmt.css("padding-bottom")).css("padding-left", this.$elmt.css("padding-left")).css("padding-right", this.$elmt.css("padding-right")),
            this.$elmt.clone(!0).children().appendTo(e),
            this.elmt.innerHTML = ""),
            n && this.support.transition && (o = t('<div class="vegas-timer"><div class="vegas-timer-progress">'),
            this.$timer = o,
            this.$elmt.prepend(o)),
            s && (i = t('<div class="vegas-overlay">'),
            "string" == typeof s && i.css("background-image", "url(" + s + ")"),
            this.$overlay = i,
            this.$elmt.prepend(i)),
            this.$elmt.addClass("vegas-container"),
            r || this.$elmt.append(e),
            setTimeout(function() {
                a.trigger("init"),
                a._goto(a.slide),
                a.settings.autoplay && a.trigger("play")
            }, 1)
        },
        _preload: function() {
            var t;
            for (t = 0; t < this.settings.slides.length; t++)
                (this.settings.preload || this.settings.preloadImages) && this.settings.slides[t].src && ((new Image).src = this.settings.slides[t].src),
                (this.settings.preload || this.settings.preloadVideos) && this.support.video && this.settings.slides[t].video && (this.settings.slides[t].video instanceof Array ? this._video(this.settings.slides[t].video) : this._video(this.settings.slides[t].video.src))
        },
        _random: function(t) {
            return t[Math.floor(Math.random() * t.length)]
        },
        _slideShow: function() {
            var t = this;
            this.total > 1 && !this.ended && !this.paused && !this.noshow && (this.timeout = setTimeout(function() {
                t.next()
            }, this._options("delay")))
        },
        _timer: function(t) {
            var e = this;
            clearTimeout(this.timeout),
            this.$timer && (this.$timer.removeClass("vegas-timer-running").find("div").css("transition-duration", "0ms"),
            this.ended || this.paused || this.noshow || t && setTimeout(function() {
                e.$timer.addClass("vegas-timer-running").find("div").css("transition-duration", e._options("delay") - 100 + "ms")
            }, 100))
        },
        _video: function(t) {
            var e, o, r = t.toString();
            return i[r] ? i[r] : (t instanceof Array == 0 && (t = [t]),
            (e = document.createElement("video")).preload = !0,
            t.forEach(function(t) {
                (o = document.createElement("source")).src = t,
                e.appendChild(o)
            }),
            i[r] = e,
            e)
        },
        _fadeOutSound: function(t, e) {
            var i = this
              , o = e / 10
              , r = t.volume - .09;
            r > 0 ? (t.volume = r,
            setTimeout(function() {
                i._fadeOutSound(t, e)
            }, o)) : t.pause()
        },
        _fadeInSound: function(t, e) {
            var i = this
              , o = e / 10
              , r = t.volume + .09;
            r < 1 && (t.volume = r,
            setTimeout(function() {
                i._fadeInSound(t, e)
            }, o))
        },
        _options: function(t, e) {
            return void 0 === e && (e = this.slide),
            void 0 !== this.settings.slides[e][t] ? this.settings.slides[e][t] : this.settings[t]
        },
        _goto: function(e) {
            function i() {
                g._timer(!0),
                setTimeout(function() {
                    v && (g.support.transition ? (l.css("transition", "all " + w + "ms").addClass("vegas-transition-" + v + "-out"),
                    l.each(function() {
                        var t = l.find("video").get(0);
                        t && (t.volume = 1,
                        g._fadeOutSound(t, w))
                    }),
                    o.css("transition", "all " + w + "ms").addClass("vegas-transition-" + v + "-in")) : o.fadeIn(w));
                    for (var t = 0; t < l.length - g.settings.slidesToKeep; t++)
                        l.eq(t).remove();
                    g.trigger("walk"),
                    g._slideShow()
                }, 100)
            }
            void 0 === this.settings.slides[e] && (e = 0),
            this.slide = e;
            var o, r, n, s, a, l = this.$elmt.children(".vegas-slide"), c = this.settings.slides[e].src, u = this.settings.slides[e].video, h = this._options("delay"), d = this._options("align"), p = this._options("valign"), m = this._options("cover"), f = this._options("color") || this.$elmt.css("background-color"), g = this, y = l.length, v = this._options("transition"), w = this._options("transitionDuration"), b = this._options("animation"), x = this._options("animationDuration");
            this.settings.firstTransition && this.first && (v = this.settings.firstTransition || v),
            this.settings.firstTransitionDuration && this.first && (w = this.settings.firstTransitionDuration || w),
            this.first && (this.first = !1),
            "repeat" !== m && (!0 === m ? m = "cover" : !1 === m && (m = "contain")),
            ("random" === v || v instanceof Array) && (v = v instanceof Array ? this._random(v) : this._random(this.transitions)),
            ("random" === b || b instanceof Array) && (b = b instanceof Array ? this._random(b) : this._random(this.animations)),
            ("auto" === w || w > h) && (w = h),
            "auto" === x && (x = h),
            o = t('<div class="vegas-slide"></div>'),
            this.support.transition && v && o.addClass("vegas-transition-" + v),
            this.support.video && u ? ((s = u instanceof Array ? this._video(u) : this._video(u.src)).loop = void 0 === u.loop || u.loop,
            s.muted = void 0 === u.mute || u.mute,
            !1 === s.muted ? (s.volume = 0,
            this._fadeInSound(s, w)) : s.pause(),
            n = t(s).addClass("vegas-video").css("background-color", f),
            this.support.objectFit ? n.css("object-position", d + " " + p).css("object-fit", m).css("width", "100%").css("height", "100%") : "contain" === m && n.css("width", "100%").css("height", "100%"),
            o.append(n)) : (a = new Image,
            r = t('<div class="vegas-slide-inner"></div>').css("background-image", 'url("' + c + '")').css("background-color", f).css("background-position", d + " " + p),
            "repeat" === m ? r.css("background-repeat", "repeat") : r.css("background-size", m),
            this.support.transition && b && r.addClass("vegas-animation-" + b).css("animation-duration", x + "ms"),
            o.append(r)),
            this.support.transition || o.css("display", "none"),
            y ? l.eq(y - 1).after(o) : this.$elmt.prepend(o),
            l.css("transition", "all 0ms").each(function() {
                this.className = "vegas-slide",
                "VIDEO" === this.tagName && (this.className += " vegas-video"),
                v && (this.className += " vegas-transition-" + v,
                this.className += " vegas-transition-" + v + "-in")
            }),
            g._timer(!1),
            s ? (4 === s.readyState && (s.currentTime = 0),
            s.play(),
            i()) : (a.src = c,
            a.complete ? i() : a.onload = i)
        },
        _end: function() {
            this.ended = !0,
            this._timer(!1),
            this.trigger("end")
        },
        shuffle: function() {
            for (var t, e, i = this.total - 1; i > 0; i--)
                e = Math.floor(Math.random() * (i + 1)),
                t = this.settings.slides[i],
                this.settings.slides[i] = this.settings.slides[e],
                this.settings.slides[e] = t
        },
        play: function() {
            this.paused && (this.paused = !1,
            this.next(),
            this.trigger("play"))
        },
        pause: function() {
            this._timer(!1),
            this.paused = !0,
            this.trigger("pause")
        },
        toggle: function() {
            this.paused ? this.play() : this.pause()
        },
        playing: function() {
            return !this.paused && !this.noshow
        },
        current: function(t) {
            return t ? {
                slide: this.slide,
                data: this.settings.slides[this.slide]
            } : this.slide
        },
        jump: function(t) {
            t < 0 || t > this.total - 1 || t === this.slide || (this.slide = t,
            this._goto(this.slide))
        },
        next: function() {
            if (this.slide++,
            this.slide >= this.total) {
                if (!this.settings.loop)
                    return this._end();
                this.slide = 0
            }
            this._goto(this.slide)
        },
        previous: function() {
            if (this.slide--,
            this.slide < 0) {
                if (!this.settings.loop)
                    return void this.slide++;
                this.slide = this.total - 1
            }
            this._goto(this.slide)
        },
        trigger: function(t) {
            var e;
            e = "init" === t ? [this.settings] : [this.slide, this.settings.slides[this.slide]],
            this.$elmt.trigger("vegas" + t, e),
            "function" == typeof this.settings[t] && this.settings[t].apply(this.$elmt, e)
        },
        options: function(i, o) {
            var r = this.settings.slides.slice();
            if ("object" == typeof i)
                this.settings = t.extend({}, e, t.vegas.defaults, i);
            else {
                if ("string" != typeof i)
                    return this.settings;
                if (void 0 === o)
                    return this.settings[i];
                this.settings[i] = o
            }
            this.settings.slides !== r && (this.total = this.settings.slides.length,
            this.noshow = this.total < 2,
            this._preload())
        },
        destroy: function() {
            clearTimeout(this.timeout),
            this.$elmt.removeClass("vegas-container"),
            this.$elmt.find("> .vegas-slide").remove(),
            this.$elmt.find("> .vegas-wrapper").clone(!0).children().appendTo(this.$elmt),
            this.$elmt.find("> .vegas-wrapper").remove(),
            this.settings.timer && this.$timer.remove(),
            this.settings.overlay && this.$overlay.remove(),
            this.elmt._vegas = null
        }
    },
    t.fn.vegas = function(t) {
        var e, i = arguments, r = !1;
        if (void 0 === t || "object" == typeof t)
            return this.each(function() {
                this._vegas || (this._vegas = new o(this,t))
            });
        if ("string" == typeof t) {
            if (this.each(function() {
                var o = this._vegas;
                if (!o)
                    throw new Error("No Vegas applied to this element.");
                "function" == typeof o[t] && "_" !== t[0] ? e = o[t].apply(o, [].slice.call(i, 1)) : r = !0
            }),
            r)
                throw new Error('No method "' + t + '" in Vegas.');
            return void 0 !== e ? e : this
        }
    }
    ,
    t.vegas = {},
    t.vegas.defaults = e,
    t.vegas.isVideoCompatible = function() {
        return !/(Android|webOS|Phone|iPad|iPod|BlackBerry|Windows Phone)/i.test(navigator.userAgent)
    }
}(window.jQuery || window.Zepto);
var ytp = ytp || {};
function onYouTubePlayerAPIReady() {
    ytp.YTAPIReady || (ytp.YTAPIReady = !0,
    jQuery(document).trigger("YTAPIReady"))
}
if (function(jQuery, ytp) {
    var nAgt = navigator.userAgent;
    if (!jQuery.browser) {
        var nameOffset, verOffset, ix;
        if (jQuery.browser = {},
        jQuery.browser.mozilla = !1,
        jQuery.browser.webkit = !1,
        jQuery.browser.opera = !1,
        jQuery.browser.safari = !1,
        jQuery.browser.chrome = !1,
        jQuery.browser.msie = !1,
        jQuery.browser.ua = nAgt,
        jQuery.browser.name = navigator.appName,
        jQuery.browser.fullVersion = "" + parseFloat(navigator.appVersion),
        jQuery.browser.majorVersion = parseInt(navigator.appVersion, 10),
        -1 != (verOffset = nAgt.indexOf("Opera")))
            jQuery.browser.opera = !0,
            jQuery.browser.name = "Opera",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 6),
            -1 != (verOffset = nAgt.indexOf("Version")) && (jQuery.browser.fullVersion = nAgt.substring(verOffset + 8));
        else if (-1 != (verOffset = nAgt.indexOf("MSIE")))
            jQuery.browser.msie = !0,
            jQuery.browser.name = "Microsoft Internet Explorer",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 5);
        else if (-1 != nAgt.indexOf("Trident")) {
            jQuery.browser.msie = !0,
            jQuery.browser.name = "Microsoft Internet Explorer";
            var start = nAgt.indexOf("rv:") + 3
              , end = start + 4;
            jQuery.browser.fullVersion = nAgt.substring(start, end)
        } else
            -1 != (verOffset = nAgt.indexOf("Chrome")) ? (jQuery.browser.webkit = !0,
            jQuery.browser.chrome = !0,
            jQuery.browser.name = "Chrome",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 7)) : -1 != (verOffset = nAgt.indexOf("Safari")) ? (jQuery.browser.webkit = !0,
            jQuery.browser.safari = !0,
            jQuery.browser.name = "Safari",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 7),
            -1 != (verOffset = nAgt.indexOf("Version")) && (jQuery.browser.fullVersion = nAgt.substring(verOffset + 8))) : -1 != (verOffset = nAgt.indexOf("AppleWebkit")) ? (jQuery.browser.webkit = !0,
            jQuery.browser.name = "Safari",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 7),
            -1 != (verOffset = nAgt.indexOf("Version")) && (jQuery.browser.fullVersion = nAgt.substring(verOffset + 8))) : -1 != (verOffset = nAgt.indexOf("Firefox")) ? (jQuery.browser.mozilla = !0,
            jQuery.browser.name = "Firefox",
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 8)) : (nameOffset = nAgt.lastIndexOf(" ") + 1) < (verOffset = nAgt.lastIndexOf("/")) && (jQuery.browser.name = nAgt.substring(nameOffset, verOffset),
            jQuery.browser.fullVersion = nAgt.substring(verOffset + 1),
            jQuery.browser.name.toLowerCase() == jQuery.browser.name.toUpperCase() && (jQuery.browser.name = navigator.appName));
        -1 != (ix = jQuery.browser.fullVersion.indexOf(";")) && (jQuery.browser.fullVersion = jQuery.browser.fullVersion.substring(0, ix)),
        -1 != (ix = jQuery.browser.fullVersion.indexOf(" ")) && (jQuery.browser.fullVersion = jQuery.browser.fullVersion.substring(0, ix)),
        jQuery.browser.majorVersion = parseInt("" + jQuery.browser.fullVersion, 10),
        isNaN(jQuery.browser.majorVersion) && (jQuery.browser.fullVersion = "" + parseFloat(navigator.appVersion),
        jQuery.browser.majorVersion = parseInt(navigator.appVersion, 10)),
        jQuery.browser.version = jQuery.browser.majorVersion
    }
    jQuery.browser.android = /Android/i.test(nAgt),
    jQuery.browser.blackberry = /BlackBerry|BB|PlayBook/i.test(nAgt),
    jQuery.browser.ios = /iPhone|iPad|iPod|webOS/i.test(nAgt),
    jQuery.browser.operaMobile = /Opera Mini/i.test(nAgt),
    jQuery.browser.kindle = /Kindle|Silk/i.test(nAgt),
    jQuery.browser.windowsMobile = /IEMobile|Windows Phone/i.test(nAgt),
    jQuery.browser.mobile = jQuery.browser.android || jQuery.browser.blackberry || jQuery.browser.ios || jQuery.browser.windowsMobile || jQuery.browser.operaMobile || jQuery.browser.kindle,
    jQuery.fn.CSSAnimate = function(t, e, i, o, r) {
        function n(t) {
            return t.replace(/([A-Z])/g, function(t) {
                return "-" + t.toLowerCase()
            })
        }
        function s(t, e) {
            return "string" != typeof t || t.match(/^[\-0-9\.]+$/) ? "" + t + e : t
        }
        return jQuery.support.CSStransition = function() {
            var t = (document.body || document.documentElement).style;
            return void 0 !== t.transition || void 0 !== t.WebkitTransition || void 0 !== t.MozTransition || void 0 !== t.MsTransition || void 0 !== t.OTransition
        }(),
        this.each(function() {
            var a = this
              , l = jQuery(this);
            a.id = a.id || "CSSA_" + (new Date).getTime();
            var c = c || {
                type: "noEvent"
            };
            if (a.CSSAIsRunning && a.eventType == c.type)
                a.CSSqueue = function() {
                    l.CSSAnimate(t, e, i, o, r)
                }
                ;
            else if (a.CSSqueue = null,
            a.eventType = c.type,
            0 !== l.length && t) {
                if (a.CSSAIsRunning = !0,
                "function" == typeof e && (r = e,
                e = jQuery.fx.speeds._default),
                "function" == typeof i && (r = i,
                i = 0),
                "function" == typeof o && (r = o,
                o = "cubic-bezier(0.65,0.03,0.36,0.72)"),
                "string" == typeof e)
                    for (var u in jQuery.fx.speeds) {
                        if (e == u) {
                            e = jQuery.fx.speeds[u];
                            break
                        }
                        e = jQuery.fx.speeds._default
                    }
                if (e || (e = jQuery.fx.speeds._default),
                jQuery.support.CSStransition) {
                    (c = {
                        default: "ease",
                        in: "ease-in",
                        out: "ease-out",
                        "in-out": "ease-in-out",
                        snap: "cubic-bezier(0,1,.5,1)",
                        easeOutCubic: "cubic-bezier(.215,.61,.355,1)",
                        easeInOutCubic: "cubic-bezier(.645,.045,.355,1)",
                        easeInCirc: "cubic-bezier(.6,.04,.98,.335)",
                        easeOutCirc: "cubic-bezier(.075,.82,.165,1)",
                        easeInOutCirc: "cubic-bezier(.785,.135,.15,.86)",
                        easeInExpo: "cubic-bezier(.95,.05,.795,.035)",
                        easeOutExpo: "cubic-bezier(.19,1,.22,1)",
                        easeInOutExpo: "cubic-bezier(1,0,0,1)",
                        easeInQuad: "cubic-bezier(.55,.085,.68,.53)",
                        easeOutQuad: "cubic-bezier(.25,.46,.45,.94)",
                        easeInOutQuad: "cubic-bezier(.455,.03,.515,.955)",
                        easeInQuart: "cubic-bezier(.895,.03,.685,.22)",
                        easeOutQuart: "cubic-bezier(.165,.84,.44,1)",
                        easeInOutQuart: "cubic-bezier(.77,0,.175,1)",
                        easeInQuint: "cubic-bezier(.755,.05,.855,.06)",
                        easeOutQuint: "cubic-bezier(.23,1,.32,1)",
                        easeInOutQuint: "cubic-bezier(.86,0,.07,1)",
                        easeInSine: "cubic-bezier(.47,0,.745,.715)",
                        easeOutSine: "cubic-bezier(.39,.575,.565,1)",
                        easeInOutSine: "cubic-bezier(.445,.05,.55,.95)",
                        easeInBack: "cubic-bezier(.6,-.28,.735,.045)",
                        easeOutBack: "cubic-bezier(.175, .885,.32,1.275)",
                        easeInOutBack: "cubic-bezier(.68,-.55,.265,1.55)"
                    })[o] && (o = c[o]);
                    var h = ""
                      , d = "transitionEnd";
                    for (p in jQuery.browser.webkit ? (h = "-webkit-",
                    d = "webkitTransitionEnd") : jQuery.browser.mozilla ? (h = "-moz-",
                    d = "transitionend") : jQuery.browser.opera ? (h = "-o-",
                    d = "otransitionend") : jQuery.browser.msie && (h = "-ms-",
                    d = "msTransitionEnd"),
                    c = [],
                    t)
                        "transform" === (u = p) && (t[u = h + "transform"] = t[p],
                        delete t[p]),
                        "filter" === u && (t[u = h + "filter"] = t[p],
                        delete t[p]),
                        "transform-origin" !== u && "origin" !== u || (t[u = h + "transform-origin"] = t[p],
                        delete t[p]),
                        "x" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " translateX(" + s(t[p], "px") + ")",
                        delete t[p]),
                        "y" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " translateY(" + s(t[p], "px") + ")",
                        delete t[p]),
                        "z" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " translateZ(" + s(t[p], "px") + ")",
                        delete t[p]),
                        "rotate" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " rotate(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "rotateX" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " rotateX(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "rotateY" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " rotateY(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "rotateZ" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " rotateZ(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "scale" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " scale(" + s(t[p], "") + ")",
                        delete t[p]),
                        "scaleX" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " scaleX(" + s(t[p], "") + ")",
                        delete t[p]),
                        "scaleY" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " scaleY(" + s(t[p], "") + ")",
                        delete t[p]),
                        "scaleZ" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " scaleZ(" + s(t[p], "") + ")",
                        delete t[p]),
                        "skew" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " skew(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "skewX" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " skewX(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "skewY" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " skewY(" + s(t[p], "deg") + ")",
                        delete t[p]),
                        "perspective" === u && (t[u = h + "transform"] = t[u] || "",
                        t[u] += " perspective(" + s(t[p], "px") + ")",
                        delete t[p]),
                        0 > c.indexOf(u) && c.push(n(u));
                    var p = c.join(",")
                      , m = function() {
                        l.off(d + "." + a.id),
                        clearTimeout(a.timeout),
                        l.css(h + "transition", ""),
                        "function" == typeof r && r(l),
                        a.called = !0,
                        a.CSSAIsRunning = !1,
                        "function" == typeof a.CSSqueue && (a.CSSqueue(),
                        a.CSSqueue = null)
                    }
                      , f = {};
                    jQuery.extend(f, t),
                    f[h + "transition-property"] = p,
                    f[h + "transition-duration"] = e + "ms",
                    f[h + "transition-delay"] = i + "ms",
                    f[h + "transition-style"] = "preserve-3d",
                    f[h + "transition-timing-function"] = o,
                    setTimeout(function() {
                        l.one(d + "." + a.id, m),
                        l.css(f)
                    }, 1),
                    a.timeout = setTimeout(function() {
                        l.called || !r ? (l.called = !1,
                        a.CSSAIsRunning = !1) : (l.css(h + "transition", ""),
                        r(l),
                        a.CSSAIsRunning = !1,
                        "function" == typeof a.CSSqueue && (a.CSSqueue(),
                        a.CSSqueue = null))
                    }, e + i + 100)
                } else {
                    for (var p in t)
                        "transform" === p && delete t[p],
                        "filter" === p && delete t[p],
                        "transform-origin" === p && delete t[p],
                        "auto" === t[p] && delete t[p];
                    r && "string" != typeof r || (r = "linear"),
                    l.animate(t, e, r)
                }
            }
        })
    }
    ;
    var getYTPVideoID = function(t) {
        var e, i;
        return t.indexOf("youtu.be") > 0 ? (i = (e = t.substr(t.lastIndexOf("/") + 1, t.length)).indexOf("?list=") > 0 ? e.substr(e.lastIndexOf("="), e.length) : null,
        e = i ? e.substr(0, e.lastIndexOf("?")) : e) : t.indexOf("http") > -1 ? (e = t.match(/[\\?&]v=([^&#]*)/)[1],
        i = t.indexOf("list=") > 0 ? t.match(/[\\?&]list=([^&#]*)/)[1] : null) : i = (e = t.length > 15 ? null : t) ? null : t,
        {
            videoID: e,
            playlistID: i
        }
    };
    jQuery.mbYTPlayer = {
        name: "jquery.mb.YTPlayer",
        version: "2.7.8",
        author: "Matteo Bicocchi",
        defaults: {
            containment: "body",
            ratio: "16/9",
            videoURL: null,
            playlistURL: null,
            startAt: 0,
            stopAt: 0,
            autoPlay: !0,
            vol: 100,
            addRaster: !1,
            opacity: 1,
            quality: "default",
            mute: !1,
            loop: !0,
            showControls: !0,
            showAnnotations: !1,
            showYTLogo: !0,
            stopMovieOnClick: !1,
            stopMovieOnBlur: !0,
            realfullscreen: !0,
            gaTrack: !0,
            onReady: function(t) {}
        },
        controls: {
            play: "P",
            pause: "p",
            mute: "M",
            unmute: "A",
            onlyYT: "O",
            showSite: "R",
            ytLogo: "Y"
        },
        locationProtocol: "https:",
        buildPlayer: function(options) {
            return this.each(function() {
                var YTPlayer = this
                  , $YTPlayer = jQuery(YTPlayer);
                YTPlayer.loop = 0,
                YTPlayer.opt = {},
                $YTPlayer.addClass("mb_YTPlayer");
                var property = $YTPlayer.data("property") && "string" == typeof $YTPlayer.data("property") ? eval("(" + $YTPlayer.data("property") + ")") : $YTPlayer.data("property");
                void 0 !== property && void 0 !== property.vol && (property.vol = 0 == property.vol ? property.vol = 1 : property.vol),
                jQuery.extend(YTPlayer.opt, jQuery.mbYTPlayer.defaults, options, property);
                var canGoFullscreen = !(jQuery.browser.msie || jQuery.browser.opera || self.location.href != top.location.href);
                canGoFullscreen || (YTPlayer.opt.realfullscreen = !1),
                $YTPlayer.attr("id") || $YTPlayer.attr("id", "video_" + (new Date).getTime());
                var playerID = "mbYTP_" + YTPlayer.id;
                YTPlayer.isAlone = !1,
                YTPlayer.hasFocus = !0;
                var videoID = this.opt.videoURL ? getYTPVideoID(this.opt.videoURL).videoID : !!$YTPlayer.attr("href") && getYTPVideoID($YTPlayer.attr("href")).videoID
                  , playlistID = this.opt.videoURL ? getYTPVideoID(this.opt.videoURL).playlistID : !!$YTPlayer.attr("href") && getYTPVideoID($YTPlayer.attr("href")).playlistID;
                YTPlayer.videoID = videoID,
                YTPlayer.playlistID = playlistID,
                YTPlayer.opt.showAnnotations = YTPlayer.opt.showAnnotations ? "0" : "3";
                var playerVars = {
                    autoplay: 0,
                    modestbranding: 1,
                    controls: 0,
                    showinfo: 0,
                    rel: 0,
                    enablejsapi: 1,
                    version: 3,
                    playerapiid: playerID,
                    origin: "*",
                    allowfullscreen: !0,
                    wmode: "transparent",
                    iv_load_policy: YTPlayer.opt.showAnnotations
                }
                  , v = document.createElement("video");
                v.canPlayType && jQuery.extend(playerVars, {
                    html5: 1
                }),
                jQuery.browser.msie && jQuery.browser.version < 9 && (this.opt.opacity = 1);
                var playerBox = jQuery("<div/>").attr("id", playerID).addClass("playerBox")
                  , overlay = jQuery("<div/>").css({
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%"
                }).addClass("YTPOverlay");
                if (YTPlayer.isSelf = "self" == YTPlayer.opt.containment,
                YTPlayer.opt.containment = "self" == YTPlayer.opt.containment ? jQuery(this) : jQuery(YTPlayer.opt.containment),
                YTPlayer.isBackground = "body" == YTPlayer.opt.containment.get(0).tagName.toLowerCase(),
                !YTPlayer.isBackground || !ytp.backgroundIsInited) {
                    var isPlayer = YTPlayer.opt.containment.is(jQuery(this)) && 0 == jQuery(this).children().length;
                    if (isPlayer ? YTPlayer.isPlayer = !0 : $YTPlayer.hide(),
                    jQuery.browser.mobile && YTPlayer.isBackground)
                        $YTPlayer.remove();
                    else {
                        if (YTPlayer.opt.addRaster) {
                            var classN = "dot" == YTPlayer.opt.addRaster ? "raster-dot" : "raster"
                              , retina = window.retina || window.devicePixelRatio > 1;
                            overlay.addClass(retina ? classN + " retina" : classN)
                        } else
                            overlay.removeClass(function(t, e) {
                                var i = e.split(" ")
                                  , o = [];
                                return jQuery.each(i, function(t, e) {
                                    /raster-.*/.test(e) && o.push(e)
                                }),
                                o.push("retina"),
                                o.join(" ")
                            });
                        var wrapper = jQuery("<div/>").addClass("mbYTP_wrapper").attr("id", "wrapper_" + playerID);
                        if (wrapper.css({
                            position: "absolute",
                            zIndex: 0,
                            minWidth: "100%",
                            minHeight: "100%",
                            left: 0,
                            top: 0,
                            overflow: "hidden",
                            opacity: 0
                        }),
                        playerBox.css({
                            position: "absolute",
                            zIndex: 0,
                            width: "100%",
                            height: "100%",
                            top: 0,
                            left: 0,
                            overflow: "hidden"
                        }),
                        wrapper.append(playerBox),
                        YTPlayer.opt.containment.children().not("script, style").each(function() {
                            "static" == jQuery(this).css("position") && jQuery(this).css("position", "relative")
                        }),
                        YTPlayer.isBackground ? (wrapper.css({
                            position: "fixed",
                            top: 0,
                            left: 0,
                            zIndex: 0,
                            webkitTransform: "translateZ(0)"
                        }),
                        $YTPlayer.hide()) : "static" == YTPlayer.opt.containment.css("position") && YTPlayer.opt.containment.css({
                            position: "relative"
                        }),
                        YTPlayer.opt.containment.prepend(wrapper),
                        YTPlayer.wrapper = wrapper,
                        playerBox.css({
                            opacity: 1
                        }),
                        jQuery.browser.mobile || (playerBox.after(overlay),
                        YTPlayer.overlay = overlay),
                        YTPlayer.isBackground || overlay.on("mouseenter", function() {
                            $YTPlayer.find(".mb_YTPBar").addClass("visible")
                        }).on("mouseleave", function() {
                            $YTPlayer.find(".mb_YTPBar").removeClass("visible")
                        }),
                        ytp.YTAPIReady)
                            setTimeout(function() {
                                jQuery(document).trigger("YTAPIReady")
                            }, 100);
                        else {
                            jQuery("#YTAPI").remove();
                            var tag = jQuery("<script><\/script>").attr({
                                src: jQuery.mbYTPlayer.locationProtocol + "//www.youtube.com/player_api?v=" + jQuery.mbYTPlayer.version,
                                id: "YTAPI"
                            });
                            jQuery("head title").after(tag)
                        }
                        jQuery(document).on("YTAPIReady", function() {
                            YTPlayer.isBackground && ytp.backgroundIsInited || YTPlayer.isInit || (YTPlayer.isBackground && YTPlayer.opt.stopMovieOnClick && jQuery(document).off("mousedown.ytplayer").on("mousedown,.ytplayer", function(t) {
                                var e = jQuery(t.target);
                                (e.is("a") || e.parents().is("a")) && $YTPlayer.pauseYTP()
                            }),
                            YTPlayer.isBackground && (ytp.backgroundIsInited = !0),
                            YTPlayer.opt.autoPlay = void 0 === YTPlayer.opt.autoPlay ? !!YTPlayer.isBackground : YTPlayer.opt.autoPlay,
                            YTPlayer.opt.vol = YTPlayer.opt.vol ? YTPlayer.opt.vol : 100,
                            jQuery.mbYTPlayer.getDataFromFeed(YTPlayer),
                            jQuery(YTPlayer).on("YTPChanged", function() {
                                YTPlayer.isInit || (YTPlayer.isInit = !0,
                                jQuery.browser.mobile && YTPlayer.isPlayer ? new YT.Player(playerID,{
                                    videoId: YTPlayer.videoID.toString(),
                                    height: "100%",
                                    width: "100%",
                                    videoId: YTPlayer.videoID,
                                    events: {
                                        onReady: function(t) {
                                            YTPlayer.player = t.target,
                                            playerBox.css({
                                                opacity: 1
                                            }),
                                            YTPlayer.wrapper.css({
                                                opacity: YTPlayer.opt.opacity
                                            }),
                                            $YTPlayer.optimizeDisplay()
                                        },
                                        onStateChange: function() {}
                                    }
                                }) : new YT.Player(playerID,{
                                    videoId: YTPlayer.videoID.toString(),
                                    playerVars: playerVars,
                                    events: {
                                        onReady: function(t) {
                                            if (YTPlayer.player = t.target,
                                            !YTPlayer.isReady) {
                                                YTPlayer.isReady = !0,
                                                YTPlayer.playerEl = YTPlayer.player.getIframe(),
                                                $YTPlayer.optimizeDisplay(),
                                                YTPlayer.videoID = videoID,
                                                jQuery(window).on("resize.YTP", function() {
                                                    $YTPlayer.optimizeDisplay()
                                                }),
                                                YTPlayer.opt.showControls && jQuery(YTPlayer).buildYTPControls();
                                                var e = YTPlayer.opt.startAt ? YTPlayer.opt.startAt : 1;
                                                YTPlayer.player.setVolume(0),
                                                jQuery(YTPlayer).muteYTPVolume(),
                                                jQuery.mbYTPlayer.checkForState(YTPlayer),
                                                YTPlayer.checkForStartAt = setInterval(function() {
                                                    var t = !(!jQuery.browser.mozilla || window.MediaSource) || YTPlayer.player.getVideoLoadedFraction() > e / YTPlayer.player.getDuration();
                                                    YTPlayer.player.getDuration() > 0 && YTPlayer.player.getCurrentTime() >= e && t ? (clearInterval(YTPlayer.checkForStartAt),
                                                    YTPlayer.player.setVolume(0),
                                                    jQuery(YTPlayer).muteYTPVolume(),
                                                    "function" == typeof YTPlayer.opt.onReady && YTPlayer.opt.onReady(YTPlayer),
                                                    YTPlayer.opt.mute || jQuery(YTPlayer).unmuteYTP(),
                                                    jQuery.mbYTPlayer.checkForState(YTPlayer),
                                                    YTPlayer.player.pauseVideo(),
                                                    setTimeout(function() {
                                                        YTPlayer.canTrigger = !0,
                                                        YTPlayer.opt.autoPlay ? ($YTPlayer.playYTP(),
                                                        $YTPlayer.css("background-image", "none"),
                                                        YTPlayer.wrapper.CSSAnimate({
                                                            opacity: YTPlayer.isAlone ? 1 : YTPlayer.opt.opacity
                                                        }, 2e3)) : YTPlayer.player.pauseVideo()
                                                    }, 100)) : (YTPlayer.player.playVideo(),
                                                    YTPlayer.player.seekTo(e, !0))
                                                }, jQuery.browser.chrome ? 1e3 : 1)
                                            }
                                        },
                                        onStateChange: function(event) {
                                            if ("function" == typeof event.target.getPlayerState) {
                                                var state = event.target.getPlayerState();
                                                if (YTPlayer.state != state) {
                                                    YTPlayer.state = state;
                                                    var controls = jQuery("#controlBar_" + YTPlayer.id), data = YTPlayer.opt, eventType;
                                                    switch (state) {
                                                    case -1:
                                                        eventType = "YTPUnstarted";
                                                        break;
                                                    case 0:
                                                        eventType = "YTPEnd",
                                                        YTPlayer.player.pauseVideo();
                                                        var startAt = YTPlayer.opt.startAt ? YTPlayer.opt.startAt : 1;
                                                        data.loop ? (YTPlayer.wrapper.css({
                                                            opacity: 0
                                                        }),
                                                        $YTPlayer.playYTP(),
                                                        YTPlayer.player.seekTo(startAt, !0)) : YTPlayer.isBackground || (YTPlayer.player.seekTo(startAt, !0),
                                                        $YTPlayer.playYTP(),
                                                        setTimeout(function() {
                                                            $YTPlayer.pauseYTP()
                                                        }, 10)),
                                                        !data.loop && YTPlayer.isBackground ? YTPlayer.wrapper.CSSAnimate({
                                                            opacity: 0
                                                        }, 2e3) : data.loop && YTPlayer.loop++,
                                                        controls.find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.play);
                                                        break;
                                                    case 1:
                                                        eventType = "YTPStart",
                                                        jQuery.browser.chrome || YTPlayer.player.setPlaybackQuality(YTPlayer.opt.quality),
                                                        controls.find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.pause),
                                                        "undefined" != typeof _gaq && eval(YTPlayer.opt.gaTrack) && _gaq.push(["_trackEvent", "YTPlayer", "Play", YTPlayer.videoTitle || YTPlayer.videoID.toString()]),
                                                        "undefined" != typeof ga && eval(YTPlayer.opt.gaTrack) && ga("send", "event", "YTPlayer", "play", YTPlayer.videoTitle || YTPlayer.videoID.toString());
                                                        break;
                                                    case 2:
                                                        eventType = "YTPPause",
                                                        controls.find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.play);
                                                        break;
                                                    case 3:
                                                        eventType = "YTPBuffering",
                                                        jQuery.browser.chrome || YTPlayer.player.setPlaybackQuality(YTPlayer.opt.quality),
                                                        controls.find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.play);
                                                        break;
                                                    case 5:
                                                        eventType = "YTPCued"
                                                    }
                                                    var YTPevent = jQuery.Event(eventType);
                                                    YTPevent.time = YTPlayer.player.time,
                                                    YTPlayer.canTrigger && jQuery(YTPlayer).trigger(YTPevent)
                                                }
                                            }
                                        },
                                        onPlaybackQualityChange: function(t) {
                                            var e = t.target.getPlaybackQuality()
                                              , i = jQuery.Event("YTPQualityChange");
                                            i.quality = e,
                                            jQuery(YTPlayer).trigger(i)
                                        },
                                        onError: function(t) {
                                            150 == t.data && (console.log("Embedding this video is restricted by Youtube."),
                                            YTPlayer.isPlayList && jQuery(YTPlayer).playNext()),
                                            2 == t.data && YTPlayer.isPlayList && jQuery(YTPlayer).playNext(),
                                            "function" == typeof YTPlayer.opt.onError && YTPlayer.opt.onError($YTPlayer, t)
                                        }
                                    }
                                }))
                            }))
                        })
                    }
                }
            })
        },
        getDataFromFeed: function(t) {
            jQuery.browser.msie && jQuery.browser.version <= 9 ? ("auto" == t.opt.ratio ? t.opt.ratio = "16/9" : t.opt.ratio,
            t.hasData || (t.hasData = !0,
            setTimeout(function() {
                jQuery(t).trigger("YTPChanged")
            }, 100))) : (jQuery.getJSON(jQuery.mbYTPlayer.locationProtocol + "//gdata.youtube.com/feeds/api/videos/" + t.videoID + "?v=2&alt=jsonc", function(e, i, o) {
                t.dataReceived = !0,
                t.videoData = e.data,
                jQuery(t).trigger("YTPChanged");
                var r = jQuery.Event("YTPData");
                for (var n in r.prop = {},
                t.videoData)
                    r.prop[n] = t.videoData[n];
                if (jQuery(t).trigger(r),
                t.videoTitle = t.videoData.title,
                "auto" == t.opt.ratio && (t.videoData.aspectRatio && "widescreen" === t.videoData.aspectRatio ? t.opt.ratio = "16/9" : t.opt.ratio = "4/3"),
                !t.hasData && (t.hasData = !0,
                t.isPlayer)) {
                    var s = t.videoData.thumbnail.hqDefault;
                    t.opt.containment.css({
                        background: "rgba(0,0,0,0.5) url(" + s + ") center center",
                        backgroundSize: "cover"
                    })
                }
            }),
            setTimeout(function() {
                t.dataReceived || t.hasData || (t.hasData = !0,
                jQuery(t).trigger("YTPChanged"))
            }, 1500))
        },
        getVideoData: function() {
            return this.get(0).videoData
        },
        getVideoID: function() {
            return this.get(0).videoID || !1
        },
        setVideoQuality: function(t) {
            var e = this.get(0);
            jQuery.browser.chrome || e.player.setPlaybackQuality(t)
        },
        YTPlaylist: function(t, e, i) {
            var o = this.get(0);
            o.isPlayList = !0,
            e && (t = jQuery.shuffle(t)),
            o.videoID || (o.videos = t,
            o.videoCounter = 0,
            o.videoLength = t.length,
            jQuery(o).data("property", t[0]),
            jQuery(o).mb_YTPlayer()),
            "function" == typeof i && jQuery(o).on("YTPChanged", function() {
                i(o)
            }),
            jQuery(o).on("YTPEnd", function() {
                jQuery(o).playNext()
            })
        },
        playNext: function() {
            var t = this.get(0);
            t.videoCounter++,
            t.videoCounter >= t.videoLength && (t.videoCounter = 0),
            jQuery(t.playerEl).css({
                opacity: 0
            }),
            jQuery(t).changeMovie(t.videos[t.videoCounter])
        },
        playPrev: function() {
            var t = this.get(0);
            t.videoCounter--,
            t.videoCounter < 0 && (t.videoCounter = t.videoLength - 1),
            jQuery(t.playerEl).css({
                opacity: 0
            }),
            jQuery(t).changeMovie(t.videos[t.videoCounter])
        },
        changeMovie: function(t) {
            var e = this.get(0);
            e.opt.startAt = 0,
            e.opt.stopAt = 0,
            e.opt.mute = !0,
            t && jQuery.extend(e.opt, t),
            e.videoID = getYTPVideoID(e.opt.videoURL).videoID,
            jQuery(e).pauseYTP();
            var i = jQuery.browser.msie ? 1e3 : 0;
            if (jQuery(e.playerEl).CSSAnimate({
                opacity: 0
            }, i),
            setTimeout(function() {
                var t = jQuery.browser.chrome ? "default" : e.opt.quality;
                jQuery(e).getPlayer().cueVideoByUrl(encodeURI(jQuery.mbYTPlayer.locationProtocol + "//www.youtube.com/v/" + e.videoID), 1, t),
                jQuery(e).playYTP(),
                jQuery(e).one("YTPStart", function() {
                    e.wrapper.CSSAnimate({
                        opacity: e.isAlone ? 1 : e.opt.opacity
                    }, 1e3),
                    jQuery(e.playerEl).CSSAnimate({
                        opacity: 1
                    }, i),
                    e.opt.startAt && e.player.seekTo(e.opt.startAt),
                    jQuery.mbYTPlayer.checkForState(e),
                    e.opt.autoPlay || jQuery(e).pauseYTP()
                }),
                e.opt.mute ? jQuery(e).muteYTPVolume() : jQuery(e).unmuteYTP()
            }, i),
            e.opt.addRaster) {
                var o = window.retina || window.devicePixelRatio > 1;
                e.overlay.addClass(o ? "raster retina" : "raster")
            } else
                e.overlay.removeClass("raster"),
                e.overlay.removeClass("retina");
            jQuery("#controlBar_" + e.id).remove(),
            e.opt.showControls && jQuery(e).buildYTPControls(),
            jQuery.mbYTPlayer.getDataFromFeed(e),
            jQuery(e).optimizeDisplay()
        },
        getPlayer: function() {
            return jQuery(this).get(0).player
        },
        playerDestroy: function() {
            var t = this.get(0);
            ytp.YTAPIReady = !1,
            ytp.backgroundIsInited = !1,
            t.isInit = !1,
            t.videoID = null,
            t.wrapper.remove(),
            jQuery("#controlBar_" + t.id).remove()
        },
        fullscreen: function(real) {
            var YTPlayer = this.get(0);
            void 0 === real && (real = YTPlayer.opt.realfullscreen),
            real = eval(real);
            var controls = jQuery("#controlBar_" + YTPlayer.id)
              , fullScreenBtn = controls.find(".mb_OnlyYT")
              , videoWrapper = YTPlayer.isSelf ? YTPlayer.opt.containment : YTPlayer.wrapper;
            if (real) {
                var fullscreenchange = jQuery.browser.mozilla ? "mozfullscreenchange" : jQuery.browser.webkit ? "webkitfullscreenchange" : "fullscreenchange";
                jQuery(document).off(fullscreenchange).on(fullscreenchange, function() {
                    RunPrefixMethod(document, "IsFullScreen") || RunPrefixMethod(document, "FullScreen") ? (jQuery(YTPlayer).setVideoQuality("default"),
                    jQuery(YTPlayer).trigger("YTPFullScreenStart")) : (YTPlayer.isAlone = !1,
                    fullScreenBtn.html(jQuery.mbYTPlayer.controls.onlyYT),
                    jQuery(YTPlayer).setVideoQuality(YTPlayer.opt.quality),
                    videoWrapper.removeClass("fullscreen"),
                    videoWrapper.CSSAnimate({
                        opacity: YTPlayer.opt.opacity
                    }, 500),
                    videoWrapper.css({
                        zIndex: 0
                    }),
                    YTPlayer.isBackground ? jQuery("body").after(controls) : YTPlayer.wrapper.before(controls),
                    jQuery(window).resize(),
                    jQuery(YTPlayer).trigger("YTPFullScreenEnd"))
                })
            }
            function RunPrefixMethod(t, e) {
                for (var i, o, r = ["webkit", "moz", "ms", "o", ""], n = 0; n < r.length && !t[i]; ) {
                    if (i = e,
                    "" == r[n] && (i = i.substr(0, 1).toLowerCase() + i.substr(1)),
                    "undefined" != (o = typeof t[i = r[n] + i]))
                        return r = [r[n]],
                        "function" == o ? t[i]() : t[i];
                    n++
                }
            }
            function launchFullscreen(t) {
                RunPrefixMethod(t, "RequestFullScreen")
            }
            function cancelFullscreen() {
                (RunPrefixMethod(document, "FullScreen") || RunPrefixMethod(document, "IsFullScreen")) && RunPrefixMethod(document, "CancelFullScreen")
            }
            YTPlayer.isAlone ? (real ? cancelFullscreen() : (videoWrapper.CSSAnimate({
                opacity: YTPlayer.opt.opacity
            }, 500),
            videoWrapper.css({
                zIndex: 0
            })),
            fullScreenBtn.html(jQuery.mbYTPlayer.controls.onlyYT),
            YTPlayer.isAlone = !1) : (real ? (videoWrapper.css({
                opacity: 0
            }),
            videoWrapper.addClass("fullscreen"),
            launchFullscreen(videoWrapper.get(0)),
            setTimeout(function() {
                videoWrapper.CSSAnimate({
                    opacity: 1
                }, 1e3),
                YTPlayer.wrapper.append(controls),
                jQuery(YTPlayer).optimizeDisplay(),
                YTPlayer.player.seekTo(YTPlayer.player.getCurrentTime() + .1, !0)
            }, 500)) : videoWrapper.css({
                zIndex: 1e4
            }).CSSAnimate({
                opacity: 1
            }, 1e3),
            fullScreenBtn.html(jQuery.mbYTPlayer.controls.showSite),
            YTPlayer.isAlone = !0)
        },
        playYTP: function() {
            var t = this.get(0);
            void 0 !== t.player && (jQuery("#controlBar_" + t.id).find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.pause),
            t.player.playVideo(),
            t.wrapper.CSSAnimate({
                opacity: t.isAlone ? 1 : t.opt.opacity
            }, 2e3),
            jQuery(t).on("YTPStart", function() {
                jQuery(t).css("background-image", "none")
            }))
        },
        toggleLoops: function() {
            var t = this.get(0)
              , e = t.opt;
            1 == e.loop ? e.loop = 0 : (e.startAt ? t.player.seekTo(e.startAt) : t.player.playVideo(),
            e.loop = 1)
        },
        stopYTP: function() {
            var t = this.get(0);
            jQuery("#controlBar_" + t.id).find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.play),
            t.player.stopVideo()
        },
        pauseYTP: function() {
            var t = this.get(0);
            t.opt;
            jQuery("#controlBar_" + t.id).find(".mb_YTPPlaypause").html(jQuery.mbYTPlayer.controls.play),
            t.player.pauseVideo()
        },
        seekToYTP: function(t) {
            this.get(0).player.seekTo(t, !0)
        },
        setYTPVolume: function(t) {
            var e = this.get(0);
            t || e.opt.vol || 0 != e.player.getVolume() ? !t && e.player.getVolume() > 0 || t && e.player.getVolume() == t ? jQuery(e).muteYTPVolume() : e.opt.vol = t : jQuery(e).unmuteYTP(),
            e.player.setVolume(e.opt.vol)
        },
        muteYTP: function() {
            var t = this.get(0);
            t.player.mute(),
            t.player.setVolume(0),
            jQuery("#controlBar_" + t.id).find(".mb_YTPMuteUnmute").html(jQuery.mbYTPlayer.controls.unmute),
            jQuery(t).addClass("isMuted"),
            jQuery(t).trigger("YTPMuted")
        },
        unmuteYTP: function() {
            var t = this.get(0);
            t.player.unMute(),
            t.player.setVolume(t.opt.vol),
            jQuery("#controlBar_" + t.id).find(".mb_YTPMuteUnmute").html(jQuery.mbYTPlayer.controls.mute),
            jQuery(t).removeClass("isMuted"),
            jQuery(t).trigger("YTPUnmuted")
        },
        manageYTPProgress: function() {
            var t = this.get(0)
              , e = jQuery("#controlBar_" + t.id)
              , i = e.find(".mb_YTPProgress")
              , o = e.find(".mb_YTPLoaded")
              , r = e.find(".mb_YTPseekbar")
              , n = i.outerWidth()
              , s = Math.floor(t.player.getCurrentTime())
              , a = Math.floor(t.player.getDuration())
              , l = s * n / a
              , c = 100 * t.player.getVideoLoadedFraction();
            return o.css({
                left: 0,
                width: c + "%"
            }),
            r.css({
                left: 0,
                width: l
            }),
            {
                totalTime: a,
                currentTime: s
            }
        },
        buildYTPControls: function() {
            var YTPlayer = this.get(0)
              , data = YTPlayer.opt;
            if (data.showYTLogo = data.showYTLogo || data.printUrl,
            !jQuery("#controlBar_" + YTPlayer.id).length) {
                var controlBar = jQuery("<span/>").attr("id", "controlBar_" + YTPlayer.id).addClass("mb_YTPBar").css({
                    whiteSpace: "noWrap",
                    position: YTPlayer.isBackground ? "fixed" : "absolute",
                    zIndex: YTPlayer.isBackground ? 1e4 : 1e3
                }).hide()
                  , buttonBar = jQuery("<div/>").addClass("buttonBar")
                  , playpause = jQuery("<span>" + jQuery.mbYTPlayer.controls.play + "</span>").addClass("mb_YTPPlaypause ytpicon").click(function() {
                    1 == YTPlayer.player.getPlayerState() ? jQuery(YTPlayer).pauseYTP() : jQuery(YTPlayer).playYTP()
                })
                  , MuteUnmute = jQuery("<span>" + jQuery.mbYTPlayer.controls.mute + "</span>").addClass("mb_YTPMuteUnmute ytpicon").click(function() {
                    0 == YTPlayer.player.getVolume() ? jQuery(YTPlayer).unmuteYTP() : jQuery(YTPlayer).muteYTP()
                })
                  , idx = jQuery("<span/>").addClass("mb_YTPTime")
                  , vURL = data.videoURL ? data.videoURL : "";
                vURL.indexOf("http") < 0 && (vURL = jQuery.mbYTPlayer.locationProtocol + "//www.youtube.com/watch?v=" + data.videoURL);
                var movieUrl = jQuery("<span/>").html(jQuery.mbYTPlayer.controls.ytLogo).addClass("mb_YTPUrl ytpicon").attr("title", "view on YouTube").on("click", function() {
                    window.open(vURL, "viewOnYT")
                })
                  , onlyVideo = jQuery("<span/>").html(jQuery.mbYTPlayer.controls.onlyYT).addClass("mb_OnlyYT ytpicon").on("click", function() {
                    jQuery(YTPlayer).fullscreen(data.realfullscreen)
                })
                  , progressBar = jQuery("<div/>").addClass("mb_YTPProgress").css("position", "absolute").click(function(t) {
                    timeBar.css({
                        width: t.clientX - timeBar.offset().left
                    }),
                    YTPlayer.timeW = t.clientX - timeBar.offset().left,
                    controlBar.find(".mb_YTPLoaded").css({
                        width: 0
                    });
                    var e = Math.floor(YTPlayer.player.getDuration());
                    YTPlayer.goto = timeBar.outerWidth() * e / progressBar.outerWidth(),
                    YTPlayer.player.seekTo(parseFloat(YTPlayer.goto), !0),
                    controlBar.find(".mb_YTPLoaded").css({
                        width: 0
                    })
                })
                  , loadedBar = jQuery("<div/>").addClass("mb_YTPLoaded").css("position", "absolute")
                  , timeBar = jQuery("<div/>").addClass("mb_YTPseekbar").css("position", "absolute");
                progressBar.append(loadedBar).append(timeBar),
                buttonBar.append(playpause).append(MuteUnmute).append(idx),
                data.showYTLogo && buttonBar.append(movieUrl),
                (YTPlayer.isBackground || eval(YTPlayer.opt.realfullscreen) && !YTPlayer.isBackground) && buttonBar.append(onlyVideo),
                controlBar.append(buttonBar).append(progressBar),
                YTPlayer.isBackground ? jQuery("body").after(controlBar) : (controlBar.addClass("inlinePlayer"),
                YTPlayer.wrapper.before(controlBar)),
                controlBar.fadeIn()
            }
        },
        checkForState: function(t) {
            var e = t.opt.showControls ? 10 : 1e3;
            clearInterval(t.getState),
            t.getState = setInterval(function() {
                var e = jQuery(t).manageYTPProgress()
                  , i = jQuery(t)
                  , o = jQuery("#controlBar_" + t.id)
                  , r = t.opt
                  , n = t.opt.startAt ? t.opt.startAt : 1
                  , s = t.opt.stopAt > t.opt.startAt ? t.opt.stopAt : 0;
                if (s = s < t.player.getDuration() ? s : 0,
                t.player.time != e.currentTime) {
                    var a = jQuery.Event("YTPTime");
                    a.time = t.player.time,
                    jQuery(t).trigger(a)
                }
                if (t.player.time = e.currentTime,
                0 == t.player.getVolume() ? i.addClass("isMuted") : i.removeClass("isMuted"),
                t.opt.showControls && (e.totalTime ? o.find(".mb_YTPTime").html(jQuery.mbYTPlayer.formatTime(e.currentTime) + " / " + jQuery.mbYTPlayer.formatTime(e.totalTime)) : o.find(".mb_YTPTime").html("-- : -- / -- : --")),
                t.opt.stopMovieOnBlur && (document.hasFocus() ? document.hasFocus() && !t.hasFocus && (t.hasFocus = !0,
                i.playYTP()) : 1 == t.state && (t.hasFocus = !1,
                i.pauseYTP())),
                1 == t.player.getPlayerState() && (parseFloat(t.player.getDuration() - 3) < t.player.getCurrentTime() || s > 0 && parseFloat(t.player.getCurrentTime()) > s)) {
                    if (t.isEnded)
                        return;
                    if (t.isEnded = !0,
                    setTimeout(function() {
                        t.isEnded = !1
                    }, 2e3),
                    t.isPlayList) {
                        clearInterval(t.getState);
                        var l = jQuery.Event("YTPEnd");
                        return l.time = t.player.time,
                        void jQuery(t).trigger(l)
                    }
                    r.loop ? t.player.seekTo(n, !0) : (t.player.pauseVideo(),
                    t.wrapper.CSSAnimate({
                        opacity: 0
                    }, 1e3, function() {
                        var e = jQuery.Event("YTPEnd");
                        if (e.time = t.player.time,
                        jQuery(t).trigger(e),
                        t.player.seekTo(n, !0),
                        !t.isBackground) {
                            var i = t.videoData.thumbnail.hqDefault;
                            jQuery(t).css({
                                background: "rgba(0,0,0,0.5) url(" + i + ") center center",
                                backgroundSize: "cover"
                            })
                        }
                    }))
                }
            }, e)
        },
        formatTime: function(t) {
            var e = Math.floor(t / 60)
              , i = Math.floor(t - 60 * e);
            return (e <= 9 ? "0" + e : e) + " : " + (i <= 9 ? "0" + i : i)
        }
    },
    jQuery.fn.toggleVolume = function() {
        var t = this.get(0);
        if (t)
            return t.player.isMuted() ? (jQuery(t).unmuteYTP(),
            !0) : (jQuery(t).muteYTP(),
            !1)
    }
    ,
    jQuery.fn.optimizeDisplay = function() {
        var t = this.get(0)
          , e = t.opt
          , i = jQuery(t.playerEl)
          , o = {}
          , r = t.wrapper;
        o.width = r.outerWidth(),
        o.height = r.outerHeight();
        var n = {};
        n.width = o.width + 24 * o.width / 100,
        n.height = "16/9" == e.ratio ? Math.ceil(9 * o.width / 16) : Math.ceil(3 * o.width / 4),
        n.marginTop = -(n.height - o.height) / 2,
        n.marginLeft = -12 * o.width / 100,
        n.height < o.height && (n.height = o.height + 24 * o.height / 100,
        n.width = "16/9" == e.ratio ? Math.floor(16 * o.height / 9) : Math.floor(4 * o.height / 3),
        n.marginTop = -12 * o.height / 100,
        n.marginLeft = -(n.width - o.width) / 2),
        n.width += 100,
        n.height += 100,
        n.marginTop -= 50,
        n.marginLeft -= 50,
        i.css({
            width: n.width,
            height: n.height,
            marginTop: n.marginTop,
            marginLeft: n.marginLeft
        })
    }
    ,
    jQuery.shuffle = function(t) {
        for (var e = t.slice(), i = e.length, o = i; o--; ) {
            var r = parseInt(Math.random() * i)
              , n = e[o];
            e[o] = e[r],
            e[r] = n
        }
        return e
    }
    ,
    jQuery.fn.YTPlayer = jQuery.mbYTPlayer.buildPlayer,
    jQuery.fn.YTPlaylist = jQuery.mbYTPlayer.YTPlaylist,
    jQuery.fn.playNext = jQuery.mbYTPlayer.playNext,
    jQuery.fn.playPrev = jQuery.mbYTPlayer.playPrev,
    jQuery.fn.changeMovie = jQuery.mbYTPlayer.changeMovie,
    jQuery.fn.getVideoID = jQuery.mbYTPlayer.getVideoID,
    jQuery.fn.getPlayer = jQuery.mbYTPlayer.getPlayer,
    jQuery.fn.playerDestroy = jQuery.mbYTPlayer.playerDestroy,
    jQuery.fn.fullscreen = jQuery.mbYTPlayer.fullscreen,
    jQuery.fn.buildYTPControls = jQuery.mbYTPlayer.buildYTPControls,
    jQuery.fn.playYTP = jQuery.mbYTPlayer.playYTP,
    jQuery.fn.toggleLoops = jQuery.mbYTPlayer.toggleLoops,
    jQuery.fn.stopYTP = jQuery.mbYTPlayer.stopYTP,
    jQuery.fn.pauseYTP = jQuery.mbYTPlayer.pauseYTP,
    jQuery.fn.seekToYTP = jQuery.mbYTPlayer.seekToYTP,
    jQuery.fn.muteYTP = jQuery.mbYTPlayer.muteYTP,
    jQuery.fn.unmuteYTP = jQuery.mbYTPlayer.unmuteYTP,
    jQuery.fn.setYTPVolume = jQuery.mbYTPlayer.setYTPVolume,
    jQuery.fn.setVideoQuality = jQuery.mbYTPlayer.setVideoQuality,
    jQuery.fn.manageYTPProgress = jQuery.mbYTPlayer.manageYTPProgress,
    jQuery.fn.getDataFromFeed = jQuery.mbYTPlayer.getVideoData,
    jQuery.fn.mb_YTPlayer = jQuery.fn.YTPlayer,
    jQuery.fn.muteYTPVolume = jQuery.mbYTPlayer.muteYTP,
    jQuery.fn.unmuteYTPVolume = jQuery.mbYTPlayer.unmuteYTP
}(jQuery, ytp),
function(t, e) {
    "function" == typeof define && define.amd ? define("jquery-bridget/jquery-bridget", ["jquery"], function(i) {
        return e(t, i)
    }) : "object" == typeof module && module.exports ? module.exports = e(t, require("jquery")) : t.jQueryBridget = e(t, t.jQuery)
}(window, function(t, e) {
    "use strict";
    var i = Array.prototype.slice
      , o = t.console
      , r = void 0 === o ? function() {}
    : function(t) {
        o.error(t)
    }
    ;
    function n(o, n, a) {
        (a = a || e || t.jQuery) && (n.prototype.option || (n.prototype.option = function(t) {
            a.isPlainObject(t) && (this.options = a.extend(!0, this.options, t))
        }
        ),
        a.fn[o] = function(t) {
            var e;
            return "string" == typeof t ? function(t, e, i) {
                var n, s = "$()." + o + '("' + e + '")';
                return t.each(function(t, l) {
                    var c = a.data(l, o);
                    if (c) {
                        var u = c[e];
                        if (u && "_" != e.charAt(0)) {
                            var h = u.apply(c, i);
                            n = void 0 === n ? h : n
                        } else
                            r(s + " is not a valid method")
                    } else
                        r(o + " not initialized. Cannot call methods, i.e. " + s)
                }),
                void 0 !== n ? n : t
            }(this, t, i.call(arguments, 1)) : (e = t,
            this.each(function(t, i) {
                var r = a.data(i, o);
                r ? (r.option(e),
                r._init()) : (r = new n(i,e),
                a.data(i, o, r))
            }),
            this)
        }
        ,
        s(a))
    }
    function s(t) {
        !t || t && t.bridget || (t.bridget = n)
    }
    return s(e || t.jQuery),
    n
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("ev-emitter/ev-emitter", e) : "object" == typeof module && module.exports ? module.exports = e() : t.EvEmitter = e()
}("undefined" != typeof window ? window : this, function() {
    function t() {}
    var e = t.prototype;
    return e.on = function(t, e) {
        if (t && e) {
            var i = this._events = this._events || {}
              , o = i[t] = i[t] || [];
            return -1 == o.indexOf(e) && o.push(e),
            this
        }
    }
    ,
    e.once = function(t, e) {
        if (t && e) {
            this.on(t, e);
            var i = this._onceEvents = this._onceEvents || {};
            return (i[t] = i[t] || {})[e] = !0,
            this
        }
    }
    ,
    e.off = function(t, e) {
        var i = this._events && this._events[t];
        if (i && i.length) {
            var o = i.indexOf(e);
            return -1 != o && i.splice(o, 1),
            this
        }
    }
    ,
    e.emitEvent = function(t, e) {
        var i = this._events && this._events[t];
        if (i && i.length) {
            i = i.slice(0),
            e = e || [];
            for (var o = this._onceEvents && this._onceEvents[t], r = 0; r < i.length; r++) {
                var n = i[r];
                o && o[n] && (this.off(t, n),
                delete o[n]),
                n.apply(this, e)
            }
            return this
        }
    }
    ,
    e.allOff = function() {
        delete this._events,
        delete this._onceEvents
    }
    ,
    t
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("get-size/get-size", e) : "object" == typeof module && module.exports ? module.exports = e() : t.getSize = e()
}(window, function() {
    "use strict";
    function t(t) {
        var e = parseFloat(t);
        return -1 == t.indexOf("%") && !isNaN(e) && e
    }
    var e = "undefined" == typeof console ? function() {}
    : function(t) {
        console.error(t)
    }
      , i = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"]
      , o = i.length;
    function r(t) {
        var i = getComputedStyle(t);
        return i || e("Style returned " + i + ". Are you running this code in a hidden iframe on Firefox? See https://bit.ly/getsizebug1"),
        i
    }
    var n, s = !1;
    function a(e) {
        if (function() {
            if (!s) {
                s = !0;
                var e = document.createElement("div");
                e.style.width = "200px",
                e.style.padding = "1px 2px 3px 4px",
                e.style.borderStyle = "solid",
                e.style.borderWidth = "1px 2px 3px 4px",
                e.style.boxSizing = "border-box";
                var i = document.body || document.documentElement;
                i.appendChild(e);
                var o = r(e);
                n = 200 == Math.round(t(o.width)),
                a.isBoxSizeOuter = n,
                i.removeChild(e)
            }
        }(),
        "string" == typeof e && (e = document.querySelector(e)),
        e && "object" == typeof e && e.nodeType) {
            var l = r(e);
            if ("none" == l.display)
                return function() {
                    for (var t = {
                        width: 0,
                        height: 0,
                        innerWidth: 0,
                        innerHeight: 0,
                        outerWidth: 0,
                        outerHeight: 0
                    }, e = 0; e < o; e++)
                        t[i[e]] = 0;
                    return t
                }();
            var c = {};
            c.width = e.offsetWidth,
            c.height = e.offsetHeight;
            for (var u = c.isBorderBox = "border-box" == l.boxSizing, h = 0; h < o; h++) {
                var d = i[h]
                  , p = l[d]
                  , m = parseFloat(p);
                c[d] = isNaN(m) ? 0 : m
            }
            var f = c.paddingLeft + c.paddingRight
              , g = c.paddingTop + c.paddingBottom
              , y = c.marginLeft + c.marginRight
              , v = c.marginTop + c.marginBottom
              , w = c.borderLeftWidth + c.borderRightWidth
              , b = c.borderTopWidth + c.borderBottomWidth
              , x = u && n
              , T = t(l.width);
            !1 !== T && (c.width = T + (x ? 0 : f + w));
            var _ = t(l.height);
            return !1 !== _ && (c.height = _ + (x ? 0 : g + b)),
            c.innerWidth = c.width - (f + w),
            c.innerHeight = c.height - (g + b),
            c.outerWidth = c.width + y,
            c.outerHeight = c.height + v,
            c
        }
    }
    return a
}),
function(t, e) {
    "use strict";
    "function" == typeof define && define.amd ? define("desandro-matches-selector/matches-selector", e) : "object" == typeof module && module.exports ? module.exports = e() : t.matchesSelector = e()
}(window, function() {
    "use strict";
    var t = function() {
        var t = window.Element.prototype;
        if (t.matches)
            return "matches";
        if (t.matchesSelector)
            return "matchesSelector";
        for (var e = ["webkit", "moz", "ms", "o"], i = 0; i < e.length; i++) {
            var o = e[i] + "MatchesSelector";
            if (t[o])
                return o
        }
    }();
    return function(e, i) {
        return e[t](i)
    }
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("fizzy-ui-utils/utils", ["desandro-matches-selector/matches-selector"], function(i) {
        return e(t, i)
    }) : "object" == typeof module && module.exports ? module.exports = e(t, require("desandro-matches-selector")) : t.fizzyUIUtils = e(t, t.matchesSelector)
}(window, function(t, e) {
    var i = {
        extend: function(t, e) {
            for (var i in e)
                t[i] = e[i];
            return t
        },
        modulo: function(t, e) {
            return (t % e + e) % e
        }
    }
      , o = Array.prototype.slice;
    i.makeArray = function(t) {
        return Array.isArray(t) ? t : null == t ? [] : "object" == typeof t && "number" == typeof t.length ? o.call(t) : [t]
    }
    ,
    i.removeFrom = function(t, e) {
        var i = t.indexOf(e);
        -1 != i && t.splice(i, 1)
    }
    ,
    i.getParent = function(t, i) {
        for (; t.parentNode && t != document.body; )
            if (t = t.parentNode,
            e(t, i))
                return t
    }
    ,
    i.getQueryElement = function(t) {
        return "string" == typeof t ? document.querySelector(t) : t
    }
    ,
    i.handleEvent = function(t) {
        var e = "on" + t.type;
        this[e] && this[e](t)
    }
    ,
    i.filterFindElements = function(t, o) {
        t = i.makeArray(t);
        var r = [];
        return t.forEach(function(t) {
            if (t instanceof HTMLElement)
                if (o) {
                    e(t, o) && r.push(t);
                    for (var i = t.querySelectorAll(o), n = 0; n < i.length; n++)
                        r.push(i[n])
                } else
                    r.push(t)
        }),
        r
    }
    ,
    i.debounceMethod = function(t, e, i) {
        i = i || 100;
        var o = t.prototype[e]
          , r = e + "Timeout";
        t.prototype[e] = function() {
            var t = this[r];
            clearTimeout(t);
            var e = arguments
              , n = this;
            this[r] = setTimeout(function() {
                o.apply(n, e),
                delete n[r]
            }, i)
        }
    }
    ,
    i.docReady = function(t) {
        var e = document.readyState;
        "complete" == e || "interactive" == e ? setTimeout(t) : document.addEventListener("DOMContentLoaded", t)
    }
    ,
    i.toDashed = function(t) {
        return t.replace(/(.)([A-Z])/g, function(t, e, i) {
            return e + "-" + i
        }).toLowerCase()
    }
    ;
    var r = t.console;
    return i.htmlInit = function(e, o) {
        i.docReady(function() {
            var n = i.toDashed(o)
              , s = "data-" + n
              , a = document.querySelectorAll("[" + s + "]")
              , l = document.querySelectorAll(".js-" + n)
              , c = i.makeArray(a).concat(i.makeArray(l))
              , u = s + "-options"
              , h = t.jQuery;
            c.forEach(function(t) {
                var i, n = t.getAttribute(s) || t.getAttribute(u);
                try {
                    i = n && JSON.parse(n)
                } catch (e) {
                    return void (r && r.error("Error parsing " + s + " on " + t.className + ": " + e))
                }
                var a = new e(t,i);
                h && h.data(t, o, a)
            })
        })
    }
    ,
    i
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("outlayer/item", ["ev-emitter/ev-emitter", "get-size/get-size"], e) : "object" == typeof module && module.exports ? module.exports = e(require("ev-emitter"), require("get-size")) : (t.Outlayer = {},
    t.Outlayer.Item = e(t.EvEmitter, t.getSize))
}(window, function(t, e) {
    "use strict";
    var i = document.documentElement.style
      , o = "string" == typeof i.transition ? "transition" : "WebkitTransition"
      , r = "string" == typeof i.transform ? "transform" : "WebkitTransform"
      , n = {
        WebkitTransition: "webkitTransitionEnd",
        transition: "transitionend"
    }[o]
      , s = {
        transform: r,
        transition: o,
        transitionDuration: o + "Duration",
        transitionProperty: o + "Property",
        transitionDelay: o + "Delay"
    };
    function a(t, e) {
        t && (this.element = t,
        this.layout = e,
        this.position = {
            x: 0,
            y: 0
        },
        this._create())
    }
    var l = a.prototype = Object.create(t.prototype);
    l.constructor = a,
    l._create = function() {
        this._transn = {
            ingProperties: {},
            clean: {},
            onEnd: {}
        },
        this.css({
            position: "absolute"
        })
    }
    ,
    l.handleEvent = function(t) {
        var e = "on" + t.type;
        this[e] && this[e](t)
    }
    ,
    l.getSize = function() {
        this.size = e(this.element)
    }
    ,
    l.css = function(t) {
        var e = this.element.style;
        for (var i in t) {
            e[s[i] || i] = t[i]
        }
    }
    ,
    l.getPosition = function() {
        var t = getComputedStyle(this.element)
          , e = this.layout._getOption("originLeft")
          , i = this.layout._getOption("originTop")
          , o = t[e ? "left" : "right"]
          , r = t[i ? "top" : "bottom"]
          , n = parseFloat(o)
          , s = parseFloat(r)
          , a = this.layout.size;
        -1 != o.indexOf("%") && (n = n / 100 * a.width),
        -1 != r.indexOf("%") && (s = s / 100 * a.height),
        n = isNaN(n) ? 0 : n,
        s = isNaN(s) ? 0 : s,
        n -= e ? a.paddingLeft : a.paddingRight,
        s -= i ? a.paddingTop : a.paddingBottom,
        this.position.x = n,
        this.position.y = s
    }
    ,
    l.layoutPosition = function() {
        var t = this.layout.size
          , e = {}
          , i = this.layout._getOption("originLeft")
          , o = this.layout._getOption("originTop")
          , r = i ? "paddingLeft" : "paddingRight"
          , n = i ? "left" : "right"
          , s = i ? "right" : "left"
          , a = this.position.x + t[r];
        e[n] = this.getXValue(a),
        e[s] = "";
        var l = o ? "paddingTop" : "paddingBottom"
          , c = o ? "top" : "bottom"
          , u = o ? "bottom" : "top"
          , h = this.position.y + t[l];
        e[c] = this.getYValue(h),
        e[u] = "",
        this.css(e),
        this.emitEvent("layout", [this])
    }
    ,
    l.getXValue = function(t) {
        var e = this.layout._getOption("horizontal");
        return this.layout.options.percentPosition && !e ? t / this.layout.size.width * 100 + "%" : t + "px"
    }
    ,
    l.getYValue = function(t) {
        var e = this.layout._getOption("horizontal");
        return this.layout.options.percentPosition && e ? t / this.layout.size.height * 100 + "%" : t + "px"
    }
    ,
    l._transitionTo = function(t, e) {
        this.getPosition();
        var i = this.position.x
          , o = this.position.y
          , r = t == this.position.x && e == this.position.y;
        if (this.setPosition(t, e),
        !r || this.isTransitioning) {
            var n = t - i
              , s = e - o
              , a = {};
            a.transform = this.getTranslate(n, s),
            this.transition({
                to: a,
                onTransitionEnd: {
                    transform: this.layoutPosition
                },
                isCleaning: !0
            })
        } else
            this.layoutPosition()
    }
    ,
    l.getTranslate = function(t, e) {
        return "translate3d(" + (t = this.layout._getOption("originLeft") ? t : -t) + "px, " + (e = this.layout._getOption("originTop") ? e : -e) + "px, 0)"
    }
    ,
    l.goTo = function(t, e) {
        this.setPosition(t, e),
        this.layoutPosition()
    }
    ,
    l.moveTo = l._transitionTo,
    l.setPosition = function(t, e) {
        this.position.x = parseFloat(t),
        this.position.y = parseFloat(e)
    }
    ,
    l._nonTransition = function(t) {
        for (var e in this.css(t.to),
        t.isCleaning && this._removeStyles(t.to),
        t.onTransitionEnd)
            t.onTransitionEnd[e].call(this)
    }
    ,
    l.transition = function(t) {
        if (parseFloat(this.layout.options.transitionDuration)) {
            var e = this._transn;
            for (var i in t.onTransitionEnd)
                e.onEnd[i] = t.onTransitionEnd[i];
            for (i in t.to)
                e.ingProperties[i] = !0,
                t.isCleaning && (e.clean[i] = !0);
            if (t.from) {
                this.css(t.from);
                this.element.offsetHeight;
                null
            }
            this.enableTransition(t.to),
            this.css(t.to),
            this.isTransitioning = !0
        } else
            this._nonTransition(t)
    }
    ;
    var c = "opacity," + r.replace(/([A-Z])/g, function(t) {
        return "-" + t.toLowerCase()
    });
    l.enableTransition = function() {
        if (!this.isTransitioning) {
            var t = this.layout.options.transitionDuration;
            t = "number" == typeof t ? t + "ms" : t,
            this.css({
                transitionProperty: c,
                transitionDuration: t,
                transitionDelay: this.staggerDelay || 0
            }),
            this.element.addEventListener(n, this, !1)
        }
    }
    ,
    l.onwebkitTransitionEnd = function(t) {
        this.ontransitionend(t)
    }
    ,
    l.onotransitionend = function(t) {
        this.ontransitionend(t)
    }
    ;
    var u = {
        "-webkit-transform": "transform"
    };
    l.ontransitionend = function(t) {
        if (t.target === this.element) {
            var e = this._transn
              , i = u[t.propertyName] || t.propertyName;
            if (delete e.ingProperties[i],
            function(t) {
                for (var e in t)
                    return !1;
                return !0
            }(e.ingProperties) && this.disableTransition(),
            i in e.clean && (this.element.style[t.propertyName] = "",
            delete e.clean[i]),
            i in e.onEnd)
                e.onEnd[i].call(this),
                delete e.onEnd[i];
            this.emitEvent("transitionEnd", [this])
        }
    }
    ,
    l.disableTransition = function() {
        this.removeTransitionStyles(),
        this.element.removeEventListener(n, this, !1),
        this.isTransitioning = !1
    }
    ,
    l._removeStyles = function(t) {
        var e = {};
        for (var i in t)
            e[i] = "";
        this.css(e)
    }
    ;
    var h = {
        transitionProperty: "",
        transitionDuration: "",
        transitionDelay: ""
    };
    return l.removeTransitionStyles = function() {
        this.css(h)
    }
    ,
    l.stagger = function(t) {
        t = isNaN(t) ? 0 : t,
        this.staggerDelay = t + "ms"
    }
    ,
    l.removeElem = function() {
        this.element.parentNode.removeChild(this.element),
        this.css({
            display: ""
        }),
        this.emitEvent("remove", [this])
    }
    ,
    l.remove = function() {
        o && parseFloat(this.layout.options.transitionDuration) ? (this.once("transitionEnd", function() {
            this.removeElem()
        }),
        this.hide()) : this.removeElem()
    }
    ,
    l.reveal = function() {
        delete this.isHidden,
        this.css({
            display: ""
        });
        var t = this.layout.options
          , e = {};
        e[this.getHideRevealTransitionEndProperty("visibleStyle")] = this.onRevealTransitionEnd,
        this.transition({
            from: t.hiddenStyle,
            to: t.visibleStyle,
            isCleaning: !0,
            onTransitionEnd: e
        })
    }
    ,
    l.onRevealTransitionEnd = function() {
        this.isHidden || this.emitEvent("reveal")
    }
    ,
    l.getHideRevealTransitionEndProperty = function(t) {
        var e = this.layout.options[t];
        if (e.opacity)
            return "opacity";
        for (var i in e)
            return i
    }
    ,
    l.hide = function() {
        this.isHidden = !0,
        this.css({
            display: ""
        });
        var t = this.layout.options
          , e = {};
        e[this.getHideRevealTransitionEndProperty("hiddenStyle")] = this.onHideTransitionEnd,
        this.transition({
            from: t.visibleStyle,
            to: t.hiddenStyle,
            isCleaning: !0,
            onTransitionEnd: e
        })
    }
    ,
    l.onHideTransitionEnd = function() {
        this.isHidden && (this.css({
            display: "none"
        }),
        this.emitEvent("hide"))
    }
    ,
    l.destroy = function() {
        this.css({
            position: "",
            left: "",
            right: "",
            top: "",
            bottom: "",
            transition: "",
            transform: ""
        })
    }
    ,
    a
}),
function(t, e) {
    "use strict";
    "function" == typeof define && define.amd ? define("outlayer/outlayer", ["ev-emitter/ev-emitter", "get-size/get-size", "fizzy-ui-utils/utils", "./item"], function(i, o, r, n) {
        return e(t, i, o, r, n)
    }) : "object" == typeof module && module.exports ? module.exports = e(t, require("ev-emitter"), require("get-size"), require("fizzy-ui-utils"), require("./item")) : t.Outlayer = e(t, t.EvEmitter, t.getSize, t.fizzyUIUtils, t.Outlayer.Item)
}(window, function(t, e, i, o, r) {
    "use strict";
    var n = t.console
      , s = t.jQuery
      , a = function() {}
      , l = 0
      , c = {};
    function u(t, e) {
        var i = o.getQueryElement(t);
        if (i) {
            this.element = i,
            s && (this.$element = s(this.element)),
            this.options = o.extend({}, this.constructor.defaults),
            this.option(e);
            var r = ++l;
            this.element.outlayerGUID = r,
            c[r] = this,
            this._create(),
            this._getOption("initLayout") && this.layout()
        } else
            n && n.error("Bad element for " + this.constructor.namespace + ": " + (i || t))
    }
    u.namespace = "outlayer",
    u.Item = r,
    u.defaults = {
        containerStyle: {
            position: "relative"
        },
        initLayout: !0,
        originLeft: !0,
        originTop: !0,
        resize: !0,
        resizeContainer: !0,
        transitionDuration: "0.4s",
        hiddenStyle: {
            opacity: 0,
            transform: "scale(0.001)"
        },
        visibleStyle: {
            opacity: 1,
            transform: "scale(1)"
        }
    };
    var h = u.prototype;
    function d(t) {
        function e() {
            t.apply(this, arguments)
        }
        return e.prototype = Object.create(t.prototype),
        e.prototype.constructor = e,
        e
    }
    o.extend(h, e.prototype),
    h.option = function(t) {
        o.extend(this.options, t)
    }
    ,
    h._getOption = function(t) {
        var e = this.constructor.compatOptions[t];
        return e && void 0 !== this.options[e] ? this.options[e] : this.options[t]
    }
    ,
    u.compatOptions = {
        initLayout: "isInitLayout",
        horizontal: "isHorizontal",
        layoutInstant: "isLayoutInstant",
        originLeft: "isOriginLeft",
        originTop: "isOriginTop",
        resize: "isResizeBound",
        resizeContainer: "isResizingContainer"
    },
    h._create = function() {
        this.reloadItems(),
        this.stamps = [],
        this.stamp(this.options.stamp),
        o.extend(this.element.style, this.options.containerStyle),
        this._getOption("resize") && this.bindResize()
    }
    ,
    h.reloadItems = function() {
        this.items = this._itemize(this.element.children)
    }
    ,
    h._itemize = function(t) {
        for (var e = this._filterFindItemElements(t), i = this.constructor.Item, o = [], r = 0; r < e.length; r++) {
            var n = new i(e[r],this);
            o.push(n)
        }
        return o
    }
    ,
    h._filterFindItemElements = function(t) {
        return o.filterFindElements(t, this.options.itemSelector)
    }
    ,
    h.getItemElements = function() {
        return this.items.map(function(t) {
            return t.element
        })
    }
    ,
    h.layout = function() {
        this._resetLayout(),
        this._manageStamps();
        var t = this._getOption("layoutInstant")
          , e = void 0 !== t ? t : !this._isLayoutInited;
        this.layoutItems(this.items, e),
        this._isLayoutInited = !0
    }
    ,
    h._init = h.layout,
    h._resetLayout = function() {
        this.getSize()
    }
    ,
    h.getSize = function() {
        this.size = i(this.element)
    }
    ,
    h._getMeasurement = function(t, e) {
        var o, r = this.options[t];
        r ? ("string" == typeof r ? o = this.element.querySelector(r) : r instanceof HTMLElement && (o = r),
        this[t] = o ? i(o)[e] : r) : this[t] = 0
    }
    ,
    h.layoutItems = function(t, e) {
        t = this._getItemsForLayout(t),
        this._layoutItems(t, e),
        this._postLayout()
    }
    ,
    h._getItemsForLayout = function(t) {
        return t.filter(function(t) {
            return !t.isIgnored
        })
    }
    ,
    h._layoutItems = function(t, e) {
        if (this._emitCompleteOnItems("layout", t),
        t && t.length) {
            var i = [];
            t.forEach(function(t) {
                var o = this._getItemLayoutPosition(t);
                o.item = t,
                o.isInstant = e || t.isLayoutInstant,
                i.push(o)
            }, this),
            this._processLayoutQueue(i)
        }
    }
    ,
    h._getItemLayoutPosition = function() {
        return {
            x: 0,
            y: 0
        }
    }
    ,
    h._processLayoutQueue = function(t) {
        this.updateStagger(),
        t.forEach(function(t, e) {
            this._positionItem(t.item, t.x, t.y, t.isInstant, e)
        }, this)
    }
    ,
    h.updateStagger = function() {
        var t = this.options.stagger;
        if (null != t)
            return this.stagger = function(t) {
                if ("number" == typeof t)
                    return t;
                var e = t.match(/(^\d*\.?\d*)(\w*)/)
                  , i = e && e[1]
                  , o = e && e[2];
                if (!i.length)
                    return 0;
                i = parseFloat(i);
                var r = p[o] || 1;
                return i * r
            }(t),
            this.stagger;
        this.stagger = 0
    }
    ,
    h._positionItem = function(t, e, i, o, r) {
        o ? t.goTo(e, i) : (t.stagger(r * this.stagger),
        t.moveTo(e, i))
    }
    ,
    h._postLayout = function() {
        this.resizeContainer()
    }
    ,
    h.resizeContainer = function() {
        if (this._getOption("resizeContainer")) {
            var t = this._getContainerSize();
            t && (this._setContainerMeasure(t.width, !0),
            this._setContainerMeasure(t.height, !1))
        }
    }
    ,
    h._getContainerSize = a,
    h._setContainerMeasure = function(t, e) {
        if (void 0 !== t) {
            var i = this.size;
            i.isBorderBox && (t += e ? i.paddingLeft + i.paddingRight + i.borderLeftWidth + i.borderRightWidth : i.paddingBottom + i.paddingTop + i.borderTopWidth + i.borderBottomWidth),
            t = Math.max(t, 0),
            this.element.style[e ? "width" : "height"] = t + "px"
        }
    }
    ,
    h._emitCompleteOnItems = function(t, e) {
        var i = this;
        function o() {
            i.dispatchEvent(t + "Complete", null, [e])
        }
        var r = e.length;
        if (e && r) {
            var n = 0;
            e.forEach(function(e) {
                e.once(t, s)
            })
        } else
            o();
        function s() {
            ++n == r && o()
        }
    }
    ,
    h.dispatchEvent = function(t, e, i) {
        var o = e ? [e].concat(i) : i;
        if (this.emitEvent(t, o),
        s)
            if (this.$element = this.$element || s(this.element),
            e) {
                var r = s.Event(e);
                r.type = t,
                this.$element.trigger(r, i)
            } else
                this.$element.trigger(t, i)
    }
    ,
    h.ignore = function(t) {
        var e = this.getItem(t);
        e && (e.isIgnored = !0)
    }
    ,
    h.unignore = function(t) {
        var e = this.getItem(t);
        e && delete e.isIgnored
    }
    ,
    h.stamp = function(t) {
        (t = this._find(t)) && (this.stamps = this.stamps.concat(t),
        t.forEach(this.ignore, this))
    }
    ,
    h.unstamp = function(t) {
        (t = this._find(t)) && t.forEach(function(t) {
            o.removeFrom(this.stamps, t),
            this.unignore(t)
        }, this)
    }
    ,
    h._find = function(t) {
        if (t)
            return "string" == typeof t && (t = this.element.querySelectorAll(t)),
            t = o.makeArray(t)
    }
    ,
    h._manageStamps = function() {
        this.stamps && this.stamps.length && (this._getBoundingRect(),
        this.stamps.forEach(this._manageStamp, this))
    }
    ,
    h._getBoundingRect = function() {
        var t = this.element.getBoundingClientRect()
          , e = this.size;
        this._boundingRect = {
            left: t.left + e.paddingLeft + e.borderLeftWidth,
            top: t.top + e.paddingTop + e.borderTopWidth,
            right: t.right - (e.paddingRight + e.borderRightWidth),
            bottom: t.bottom - (e.paddingBottom + e.borderBottomWidth)
        }
    }
    ,
    h._manageStamp = a,
    h._getElementOffset = function(t) {
        var e = t.getBoundingClientRect()
          , o = this._boundingRect
          , r = i(t);
        return {
            left: e.left - o.left - r.marginLeft,
            top: e.top - o.top - r.marginTop,
            right: o.right - e.right - r.marginRight,
            bottom: o.bottom - e.bottom - r.marginBottom
        }
    }
    ,
    h.handleEvent = o.handleEvent,
    h.bindResize = function() {
        t.addEventListener("resize", this),
        this.isResizeBound = !0
    }
    ,
    h.unbindResize = function() {
        t.removeEventListener("resize", this),
        this.isResizeBound = !1
    }
    ,
    h.onresize = function() {
        this.resize()
    }
    ,
    o.debounceMethod(u, "onresize", 100),
    h.resize = function() {
        this.isResizeBound && this.needsResizeLayout() && this.layout()
    }
    ,
    h.needsResizeLayout = function() {
        var t = i(this.element);
        return this.size && t && t.innerWidth !== this.size.innerWidth
    }
    ,
    h.addItems = function(t) {
        var e = this._itemize(t);
        return e.length && (this.items = this.items.concat(e)),
        e
    }
    ,
    h.appended = function(t) {
        var e = this.addItems(t);
        e.length && (this.layoutItems(e, !0),
        this.reveal(e))
    }
    ,
    h.prepended = function(t) {
        var e = this._itemize(t);
        if (e.length) {
            var i = this.items.slice(0);
            this.items = e.concat(i),
            this._resetLayout(),
            this._manageStamps(),
            this.layoutItems(e, !0),
            this.reveal(e),
            this.layoutItems(i)
        }
    }
    ,
    h.reveal = function(t) {
        if (this._emitCompleteOnItems("reveal", t),
        t && t.length) {
            var e = this.updateStagger();
            t.forEach(function(t, i) {
                t.stagger(i * e),
                t.reveal()
            })
        }
    }
    ,
    h.hide = function(t) {
        if (this._emitCompleteOnItems("hide", t),
        t && t.length) {
            var e = this.updateStagger();
            t.forEach(function(t, i) {
                t.stagger(i * e),
                t.hide()
            })
        }
    }
    ,
    h.revealItemElements = function(t) {
        var e = this.getItems(t);
        this.reveal(e)
    }
    ,
    h.hideItemElements = function(t) {
        var e = this.getItems(t);
        this.hide(e)
    }
    ,
    h.getItem = function(t) {
        for (var e = 0; e < this.items.length; e++) {
            var i = this.items[e];
            if (i.element == t)
                return i
        }
    }
    ,
    h.getItems = function(t) {
        t = o.makeArray(t);
        var e = [];
        return t.forEach(function(t) {
            var i = this.getItem(t);
            i && e.push(i)
        }, this),
        e
    }
    ,
    h.remove = function(t) {
        var e = this.getItems(t);
        this._emitCompleteOnItems("remove", e),
        e && e.length && e.forEach(function(t) {
            t.remove(),
            o.removeFrom(this.items, t)
        }, this)
    }
    ,
    h.destroy = function() {
        var t = this.element.style;
        t.height = "",
        t.position = "",
        t.width = "",
        this.items.forEach(function(t) {
            t.destroy()
        }),
        this.unbindResize();
        var e = this.element.outlayerGUID;
        delete c[e],
        delete this.element.outlayerGUID,
        s && s.removeData(this.element, this.constructor.namespace)
    }
    ,
    u.data = function(t) {
        var e = (t = o.getQueryElement(t)) && t.outlayerGUID;
        return e && c[e]
    }
    ,
    u.create = function(t, e) {
        var i = d(u);
        return i.defaults = o.extend({}, u.defaults),
        o.extend(i.defaults, e),
        i.compatOptions = o.extend({}, u.compatOptions),
        i.namespace = t,
        i.data = u.data,
        i.Item = d(r),
        o.htmlInit(i, t),
        s && s.bridget && s.bridget(t, i),
        i
    }
    ;
    var p = {
        ms: 1,
        s: 1e3
    };
    return u.Item = r,
    u
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("isotope-layout/js/item", ["outlayer/outlayer"], e) : "object" == typeof module && module.exports ? module.exports = e(require("outlayer")) : (t.Isotope = t.Isotope || {},
    t.Isotope.Item = e(t.Outlayer))
}(window, function(t) {
    "use strict";
    function e() {
        t.Item.apply(this, arguments)
    }
    var i = e.prototype = Object.create(t.Item.prototype)
      , o = i._create;
    i._create = function() {
        this.id = this.layout.itemGUID++,
        o.call(this),
        this.sortData = {}
    }
    ,
    i.updateSortData = function() {
        if (!this.isIgnored) {
            this.sortData.id = this.id,
            this.sortData["original-order"] = this.id,
            this.sortData.random = Math.random();
            var t = this.layout.options.getSortData
              , e = this.layout._sorters;
            for (var i in t) {
                var o = e[i];
                this.sortData[i] = o(this.element, this)
            }
        }
    }
    ;
    var r = i.destroy;
    return i.destroy = function() {
        r.apply(this, arguments),
        this.css({
            display: ""
        })
    }
    ,
    e
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("isotope-layout/js/layout-mode", ["get-size/get-size", "outlayer/outlayer"], e) : "object" == typeof module && module.exports ? module.exports = e(require("get-size"), require("outlayer")) : (t.Isotope = t.Isotope || {},
    t.Isotope.LayoutMode = e(t.getSize, t.Outlayer))
}(window, function(t, e) {
    "use strict";
    function i(t) {
        this.isotope = t,
        t && (this.options = t.options[this.namespace],
        this.element = t.element,
        this.items = t.filteredItems,
        this.size = t.size)
    }
    var o = i.prototype;
    return ["_resetLayout", "_getItemLayoutPosition", "_manageStamp", "_getContainerSize", "_getElementOffset", "needsResizeLayout", "_getOption"].forEach(function(t) {
        o[t] = function() {
            return e.prototype[t].apply(this.isotope, arguments)
        }
    }),
    o.needsVerticalResizeLayout = function() {
        var e = t(this.isotope.element);
        return this.isotope.size && e && e.innerHeight != this.isotope.size.innerHeight
    }
    ,
    o._getMeasurement = function() {
        this.isotope._getMeasurement.apply(this, arguments)
    }
    ,
    o.getColumnWidth = function() {
        this.getSegmentSize("column", "Width")
    }
    ,
    o.getRowHeight = function() {
        this.getSegmentSize("row", "Height")
    }
    ,
    o.getSegmentSize = function(t, e) {
        var i = t + e
          , o = "outer" + e;
        if (this._getMeasurement(i, o),
        !this[i]) {
            var r = this.getFirstItemSize();
            this[i] = r && r[o] || this.isotope.size["inner" + e]
        }
    }
    ,
    o.getFirstItemSize = function() {
        var e = this.isotope.filteredItems[0];
        return e && e.element && t(e.element)
    }
    ,
    o.layout = function() {
        this.isotope.layout.apply(this.isotope, arguments)
    }
    ,
    o.getSize = function() {
        this.isotope.getSize(),
        this.size = this.isotope.size
    }
    ,
    i.modes = {},
    i.create = function(t, e) {
        function r() {
            i.apply(this, arguments)
        }
        return r.prototype = Object.create(o),
        r.prototype.constructor = r,
        e && (r.options = e),
        r.prototype.namespace = t,
        i.modes[t] = r,
        r
    }
    ,
    i
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("masonry-layout/masonry", ["outlayer/outlayer", "get-size/get-size"], e) : "object" == typeof module && module.exports ? module.exports = e(require("outlayer"), require("get-size")) : t.Masonry = e(t.Outlayer, t.getSize)
}(window, function(t, e) {
    var i = t.create("masonry");
    i.compatOptions.fitWidth = "isFitWidth";
    var o = i.prototype;
    return o._resetLayout = function() {
        this.getSize(),
        this._getMeasurement("columnWidth", "outerWidth"),
        this._getMeasurement("gutter", "outerWidth"),
        this.measureColumns(),
        this.colYs = [];
        for (var t = 0; t < this.cols; t++)
            this.colYs.push(0);
        this.maxY = 0,
        this.horizontalColIndex = 0
    }
    ,
    o.measureColumns = function() {
        if (this.getContainerWidth(),
        !this.columnWidth) {
            var t = this.items[0]
              , i = t && t.element;
            this.columnWidth = i && e(i).outerWidth || this.containerWidth
        }
        var o = this.columnWidth += this.gutter
          , r = this.containerWidth + this.gutter
          , n = r / o
          , s = o - r % o;
        n = Math[s && s < 1 ? "round" : "floor"](n),
        this.cols = Math.max(n, 1)
    }
    ,
    o.getContainerWidth = function() {
        var t = this._getOption("fitWidth") ? this.element.parentNode : this.element
          , i = e(t);
        this.containerWidth = i && i.innerWidth
    }
    ,
    o._getItemLayoutPosition = function(t) {
        t.getSize();
        var e = t.size.outerWidth % this.columnWidth
          , i = Math[e && e < 1 ? "round" : "ceil"](t.size.outerWidth / this.columnWidth);
        i = Math.min(i, this.cols);
        for (var o = this[this.options.horizontalOrder ? "_getHorizontalColPosition" : "_getTopColPosition"](i, t), r = {
            x: this.columnWidth * o.col,
            y: o.y
        }, n = o.y + t.size.outerHeight, s = i + o.col, a = o.col; a < s; a++)
            this.colYs[a] = n;
        return r
    }
    ,
    o._getTopColPosition = function(t) {
        var e = this._getTopColGroup(t)
          , i = Math.min.apply(Math, e);
        return {
            col: e.indexOf(i),
            y: i
        }
    }
    ,
    o._getTopColGroup = function(t) {
        if (t < 2)
            return this.colYs;
        for (var e = [], i = this.cols + 1 - t, o = 0; o < i; o++)
            e[o] = this._getColGroupY(o, t);
        return e
    }
    ,
    o._getColGroupY = function(t, e) {
        if (e < 2)
            return this.colYs[t];
        var i = this.colYs.slice(t, t + e);
        return Math.max.apply(Math, i)
    }
    ,
    o._getHorizontalColPosition = function(t, e) {
        var i = this.horizontalColIndex % this.cols;
        i = t > 1 && i + t > this.cols ? 0 : i;
        var o = e.size.outerWidth && e.size.outerHeight;
        return this.horizontalColIndex = o ? i + t : this.horizontalColIndex,
        {
            col: i,
            y: this._getColGroupY(i, t)
        }
    }
    ,
    o._manageStamp = function(t) {
        var i = e(t)
          , o = this._getElementOffset(t)
          , r = this._getOption("originLeft") ? o.left : o.right
          , n = r + i.outerWidth
          , s = Math.floor(r / this.columnWidth);
        s = Math.max(0, s);
        var a = Math.floor(n / this.columnWidth);
        a -= n % this.columnWidth ? 0 : 1,
        a = Math.min(this.cols - 1, a);
        for (var l = (this._getOption("originTop") ? o.top : o.bottom) + i.outerHeight, c = s; c <= a; c++)
            this.colYs[c] = Math.max(l, this.colYs[c])
    }
    ,
    o._getContainerSize = function() {
        this.maxY = Math.max.apply(Math, this.colYs);
        var t = {
            height: this.maxY
        };
        return this._getOption("fitWidth") && (t.width = this._getContainerFitWidth()),
        t
    }
    ,
    o._getContainerFitWidth = function() {
        for (var t = 0, e = this.cols; --e && 0 === this.colYs[e]; )
            t++;
        return (this.cols - t) * this.columnWidth - this.gutter
    }
    ,
    o.needsResizeLayout = function() {
        var t = this.containerWidth;
        return this.getContainerWidth(),
        t != this.containerWidth
    }
    ,
    i
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("isotope-layout/js/layout-modes/masonry", ["../layout-mode", "masonry-layout/masonry"], e) : "object" == typeof module && module.exports ? module.exports = e(require("../layout-mode"), require("masonry-layout")) : e(t.Isotope.LayoutMode, t.Masonry)
}(window, function(t, e) {
    "use strict";
    var i = t.create("masonry")
      , o = i.prototype
      , r = {
        _getElementOffset: !0,
        layout: !0,
        _getMeasurement: !0
    };
    for (var n in e.prototype)
        r[n] || (o[n] = e.prototype[n]);
    var s = o.measureColumns;
    o.measureColumns = function() {
        this.items = this.isotope.filteredItems,
        s.call(this)
    }
    ;
    var a = o._getOption;
    return o._getOption = function(t) {
        return "fitWidth" == t ? void 0 !== this.options.isFitWidth ? this.options.isFitWidth : this.options.fitWidth : a.apply(this.isotope, arguments)
    }
    ,
    i
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("isotope-layout/js/layout-modes/fit-rows", ["../layout-mode"], e) : "object" == typeof exports ? module.exports = e(require("../layout-mode")) : e(t.Isotope.LayoutMode)
}(window, function(t) {
    "use strict";
    var e = t.create("fitRows")
      , i = e.prototype;
    return i._resetLayout = function() {
        this.x = 0,
        this.y = 0,
        this.maxY = 0,
        this._getMeasurement("gutter", "outerWidth")
    }
    ,
    i._getItemLayoutPosition = function(t) {
        t.getSize();
        var e = t.size.outerWidth + this.gutter
          , i = this.isotope.size.innerWidth + this.gutter;
        0 !== this.x && e + this.x > i && (this.x = 0,
        this.y = this.maxY);
        var o = {
            x: this.x,
            y: this.y
        };
        return this.maxY = Math.max(this.maxY, this.y + t.size.outerHeight),
        this.x += e,
        o
    }
    ,
    i._getContainerSize = function() {
        return {
            height: this.maxY
        }
    }
    ,
    e
}),
function(t, e) {
    "function" == typeof define && define.amd ? define("isotope-layout/js/layout-modes/vertical", ["../layout-mode"], e) : "object" == typeof module && module.exports ? module.exports = e(require("../layout-mode")) : e(t.Isotope.LayoutMode)
}(window, function(t) {
    "use strict";
    var e = t.create("vertical", {
        horizontalAlignment: 0
    })
      , i = e.prototype;
    return i._resetLayout = function() {
        this.y = 0
    }
    ,
    i._getItemLayoutPosition = function(t) {
        t.getSize();
        var e = (this.isotope.size.innerWidth - t.size.outerWidth) * this.options.horizontalAlignment
          , i = this.y;
        return this.y += t.size.outerHeight,
        {
            x: e,
            y: i
        }
    }
    ,
    i._getContainerSize = function() {
        return {
            height: this.y
        }
    }
    ,
    e
}),
function(t, e) {
    "function" == typeof define && define.amd ? define(["outlayer/outlayer", "get-size/get-size", "desandro-matches-selector/matches-selector", "fizzy-ui-utils/utils", "isotope-layout/js/item", "isotope-layout/js/layout-mode", "isotope-layout/js/layout-modes/masonry", "isotope-layout/js/layout-modes/fit-rows", "isotope-layout/js/layout-modes/vertical"], function(i, o, r, n, s, a) {
        return e(t, i, o, r, n, s, a)
    }) : "object" == typeof module && module.exports ? module.exports = e(t, require("outlayer"), require("get-size"), require("desandro-matches-selector"), require("fizzy-ui-utils"), require("isotope-layout/js/item"), require("isotope-layout/js/layout-mode"), require("isotope-layout/js/layout-modes/masonry"), require("isotope-layout/js/layout-modes/fit-rows"), require("isotope-layout/js/layout-modes/vertical")) : t.Isotope = e(t, t.Outlayer, t.getSize, t.matchesSelector, t.fizzyUIUtils, t.Isotope.Item, t.Isotope.LayoutMode)
}(window, function(t, e, i, o, r, n, s) {
    var a = t.jQuery
      , l = String.prototype.trim ? function(t) {
        return t.trim()
    }
    : function(t) {
        return t.replace(/^\s+|\s+$/g, "")
    }
      , c = e.create("isotope", {
        layoutMode: "masonry",
        isJQueryFiltering: !0,
        sortAscending: !0
    });
    c.Item = n,
    c.LayoutMode = s;
    var u = c.prototype;
    u._create = function() {
        for (var t in this.itemGUID = 0,
        this._sorters = {},
        this._getSorters(),
        e.prototype._create.call(this),
        this.modes = {},
        this.filteredItems = this.items,
        this.sortHistory = ["original-order"],
        s.modes)
            this._initLayoutMode(t)
    }
    ,
    u.reloadItems = function() {
        this.itemGUID = 0,
        e.prototype.reloadItems.call(this)
    }
    ,
    u._itemize = function() {
        for (var t = e.prototype._itemize.apply(this, arguments), i = 0; i < t.length; i++) {
            t[i].id = this.itemGUID++
        }
        return this._updateItemsSortData(t),
        t
    }
    ,
    u._initLayoutMode = function(t) {
        var e = s.modes[t]
          , i = this.options[t] || {};
        this.options[t] = e.options ? r.extend(e.options, i) : i,
        this.modes[t] = new e(this)
    }
    ,
    u.layout = function() {
        this._isLayoutInited || !this._getOption("initLayout") ? this._layout() : this.arrange()
    }
    ,
    u._layout = function() {
        var t = this._getIsInstant();
        this._resetLayout(),
        this._manageStamps(),
        this.layoutItems(this.filteredItems, t),
        this._isLayoutInited = !0
    }
    ,
    u.arrange = function(t) {
        this.option(t),
        this._getIsInstant();
        var e = this._filter(this.items);
        this.filteredItems = e.matches,
        this._bindArrangeComplete(),
        this._isInstant ? this._noTransition(this._hideReveal, [e]) : this._hideReveal(e),
        this._sort(),
        this._layout()
    }
    ,
    u._init = u.arrange,
    u._hideReveal = function(t) {
        this.reveal(t.needReveal),
        this.hide(t.needHide)
    }
    ,
    u._getIsInstant = function() {
        var t = this._getOption("layoutInstant")
          , e = void 0 !== t ? t : !this._isLayoutInited;
        return this._isInstant = e,
        e
    }
    ,
    u._bindArrangeComplete = function() {
        var t, e, i, o = this;
        function r() {
            t && e && i && o.dispatchEvent("arrangeComplete", null, [o.filteredItems])
        }
        this.once("layoutComplete", function() {
            t = !0,
            r()
        }),
        this.once("hideComplete", function() {
            e = !0,
            r()
        }),
        this.once("revealComplete", function() {
            i = !0,
            r()
        })
    }
    ,
    u._filter = function(t) {
        var e = this.options.filter;
        e = e || "*";
        for (var i = [], o = [], r = [], n = this._getFilterTest(e), s = 0; s < t.length; s++) {
            var a = t[s];
            if (!a.isIgnored) {
                var l = n(a);
                l && i.push(a),
                l && a.isHidden ? o.push(a) : l || a.isHidden || r.push(a)
            }
        }
        return {
            matches: i,
            needReveal: o,
            needHide: r
        }
    }
    ,
    u._getFilterTest = function(t) {
        return a && this.options.isJQueryFiltering ? function(e) {
            return a(e.element).is(t)
        }
        : "function" == typeof t ? function(e) {
            return t(e.element)
        }
        : function(e) {
            return o(e.element, t)
        }
    }
    ,
    u.updateSortData = function(t) {
        var e;
        t ? (t = r.makeArray(t),
        e = this.getItems(t)) : e = this.items,
        this._getSorters(),
        this._updateItemsSortData(e)
    }
    ,
    u._getSorters = function() {
        var t = this.options.getSortData;
        for (var e in t) {
            var i = t[e];
            this._sorters[e] = h(i)
        }
    }
    ,
    u._updateItemsSortData = function(t) {
        for (var e = t && t.length, i = 0; e && i < e; i++) {
            t[i].updateSortData()
        }
    }
    ;
    var h = function() {
        return function(t) {
            if ("string" != typeof t)
                return t;
            var e = l(t).split(" ")
              , i = e[0]
              , o = i.match(/^\[(.+)\]$/)
              , r = function(t, e) {
                return t ? function(e) {
                    return e.getAttribute(t)
                }
                : function(t) {
                    var i = t.querySelector(e);
                    return i && i.textContent
                }
            }(o && o[1], i)
              , n = c.sortDataParsers[e[1]];
            return t = n ? function(t) {
                return t && n(r(t))
            }
            : function(t) {
                return t && r(t)
            }
        }
    }();
    c.sortDataParsers = {
        parseInt: function(t) {
            return parseInt(t, 10)
        },
        parseFloat: function(t) {
            return parseFloat(t)
        }
    },
    u._sort = function() {
        if (this.options.sortBy) {
            var t = r.makeArray(this.options.sortBy);
            this._getIsSameSortBy(t) || (this.sortHistory = t.concat(this.sortHistory));
            var e = function(t, e) {
                return function(i, o) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r]
                          , s = i.sortData[n]
                          , a = o.sortData[n];
                        if (s > a || s < a) {
                            var l = void 0 !== e[n] ? e[n] : e
                              , c = l ? 1 : -1;
                            return (s > a ? 1 : -1) * c
                        }
                    }
                    return 0
                }
            }(this.sortHistory, this.options.sortAscending);
            this.filteredItems.sort(e)
        }
    }
    ,
    u._getIsSameSortBy = function(t) {
        for (var e = 0; e < t.length; e++)
            if (t[e] != this.sortHistory[e])
                return !1;
        return !0
    }
    ,
    u._mode = function() {
        var t = this.options.layoutMode
          , e = this.modes[t];
        if (!e)
            throw new Error("No layout mode: " + t);
        return e.options = this.options[t],
        e
    }
    ,
    u._resetLayout = function() {
        e.prototype._resetLayout.call(this),
        this._mode()._resetLayout()
    }
    ,
    u._getItemLayoutPosition = function(t) {
        return this._mode()._getItemLayoutPosition(t)
    }
    ,
    u._manageStamp = function(t) {
        this._mode()._manageStamp(t)
    }
    ,
    u._getContainerSize = function() {
        return this._mode()._getContainerSize()
    }
    ,
    u.needsResizeLayout = function() {
        return this._mode().needsResizeLayout()
    }
    ,
    u.appended = function(t) {
        var e = this.addItems(t);
        if (e.length) {
            var i = this._filterRevealAdded(e);
            this.filteredItems = this.filteredItems.concat(i)
        }
    }
    ,
    u.prepended = function(t) {
        var e = this._itemize(t);
        if (e.length) {
            this._resetLayout(),
            this._manageStamps();
            var i = this._filterRevealAdded(e);
            this.layoutItems(this.filteredItems),
            this.filteredItems = i.concat(this.filteredItems),
            this.items = e.concat(this.items)
        }
    }
    ,
    u._filterRevealAdded = function(t) {
        var e = this._filter(t);
        return this.hide(e.needHide),
        this.reveal(e.matches),
        this.layoutItems(e.matches, !0),
        e.matches
    }
    ,
    u.insert = function(t) {
        var e = this.addItems(t);
        if (e.length) {
            var i, o, r = e.length;
            for (i = 0; i < r; i++)
                o = e[i],
                this.element.appendChild(o.element);
            var n = this._filter(e).matches;
            for (i = 0; i < r; i++)
                e[i].isLayoutInstant = !0;
            for (this.arrange(),
            i = 0; i < r; i++)
                delete e[i].isLayoutInstant;
            this.reveal(n)
        }
    }
    ;
    var d = u.remove;
    return u.remove = function(t) {
        t = r.makeArray(t);
        var e = this.getItems(t);
        d.call(this, t);
        for (var i = e && e.length, o = 0; i && o < i; o++) {
            var n = e[o];
            r.removeFrom(this.filteredItems, n)
        }
    }
    ,
    u.shuffle = function() {
        for (var t = 0; t < this.items.length; t++) {
            this.items[t].sortData.random = Math.random()
        }
        this.options.sortBy = "random",
        this._sort(),
        this._layout()
    }
    ,
    u._noTransition = function(t, e) {
        var i = this.options.transitionDuration;
        this.options.transitionDuration = 0;
        var o = t.apply(this, e);
        return this.options.transitionDuration = i,
        o
    }
    ,
    u.getFilteredItemElements = function() {
        return this.filteredItems.map(function(t) {
            return t.element
        })
    }
    ,
    c
}),
function(t) {
    var e = !1
      , i = !1
      , o = 5e3
      , r = 2e3
      , n = 0
      , s = function() {
        var t;
        return 0 < (t = (t = document.getElementsByTagName("script"))[t.length - 1].src.split("?")[0]).split("/").length ? t.split("/").slice(0, -1).join("/") + "/" : ""
    }();
    Array.prototype.forEach || (Array.prototype.forEach = function(t, e) {
        for (var i = 0, o = this.length; i < o; ++i)
            t.call(e, this[i], i, this)
    }
    );
    var l = window.requestAnimationFrame || !1
      , c = window.cancelAnimationFrame || !1;
    ["ms", "moz", "webkit", "o"].forEach(function(t) {
        l || (l = window[t + "RequestAnimationFrame"]),
        c || (c = window[t + "CancelAnimationFrame"] || window[t + "CancelRequestAnimationFrame"])
    });
    var u = window.MutationObserver || window.WebKitMutationObserver || !1
      , h = {
        zindex: "auto",
        cursoropacitymin: 0,
        cursoropacitymax: 1,
        cursorcolor: "#424242",
        cursorwidth: "5px",
        cursorborder: "1px solid #fff",
        cursorborderradius: "5px",
        scrollspeed: 60,
        mousescrollstep: 24,
        touchbehavior: !1,
        hwacceleration: !0,
        usetransition: !0,
        boxzoom: !1,
        dblclickzoom: !0,
        gesturezoom: !0,
        grabcursorenabled: !0,
        autohidemode: !0,
        background: "",
        iframeautoresize: !0,
        cursorminheight: 32,
        preservenativescrolling: !0,
        railoffset: !1,
        bouncescroll: !0,
        spacebarenabled: !0,
        railpadding: {
            top: 0,
            right: 0,
            left: 0,
            bottom: 0
        },
        disableoutline: !0,
        horizrailenabled: !0,
        railalign: "right",
        railvalign: "bottom",
        enabletranslate3d: !0,
        enablemousewheel: !0,
        enablekeyboard: !0,
        smoothscroll: !0,
        sensitiverail: !0,
        enablemouselockapi: !0,
        cursorfixedheight: !1,
        directionlockdeadzone: 6,
        hidecursordelay: 400,
        nativeparentscrolling: !0,
        enablescrollonselection: !0,
        overflowx: !0,
        overflowy: !0,
        cursordragspeed: .3,
        rtlmode: !1,
        cursordragontouch: !1
    }
      , d = !1
      , p = function(a, p) {
        function f(t, e, i) {
            return e = t.css(e),
            t = parseFloat(e),
            isNaN(t) ? (i = 3 == (t = T[e] || 0) ? i ? v.win.outerHeight() - v.win.innerHeight() : v.win.outerWidth() - v.win.innerWidth() : 1,
            v.isie8 && t && (t += 1),
            i ? t : 0) : t
        }
        function g(t, e, i, o) {
            v._bind(t, e, function(o) {
                var r = {
                    original: o = o || window.event,
                    target: o.target || o.srcElement,
                    type: "wheel",
                    deltaMode: "MozMousePixelScroll" == o.type ? 0 : 1,
                    deltaX: 0,
                    deltaZ: 0,
                    preventDefault: function() {
                        return o.preventDefault ? o.preventDefault() : o.returnValue = !1,
                        !1
                    },
                    stopImmediatePropagation: function() {
                        o.stopImmediatePropagation ? o.stopImmediatePropagation() : o.cancelBubble = !0
                    }
                };
                return "mousewheel" == e ? (r.deltaY = -.025 * o.wheelDelta,
                o.wheelDeltaX && (r.deltaX = -.025 * o.wheelDeltaX)) : r.deltaY = o.detail,
                i.call(t, r)
            }, o)
        }
        function y(t, e, i) {
            var o, r;
            if (0 == t.deltaMode ? (o = -Math.floor(t.deltaX * (v.opt.mousescrollstep / 54)),
            r = -Math.floor(t.deltaY * (v.opt.mousescrollstep / 54))) : 1 == t.deltaMode && (o = -Math.floor(t.deltaX * v.opt.mousescrollstep),
            r = -Math.floor(t.deltaY * v.opt.mousescrollstep)),
            e && 0 == o && r && (o = r,
            r = 0),
            o && (v.scrollmom && v.scrollmom.stop(),
            v.lastdeltax += o,
            v.debounced("mousewheelx", function() {
                var t = v.lastdeltax;
                v.lastdeltax = 0,
                v.rail.drag || v.doScrollLeftBy(t)
            }, 120)),
            r) {
                if (v.opt.nativeparentscrolling && i && !v.ispage && !v.zoomactive)
                    if (0 > r) {
                        if (v.getScrollTop() >= v.page.maxh)
                            return !0
                    } else if (0 >= v.getScrollTop())
                        return !0;
                v.scrollmom && v.scrollmom.stop(),
                v.lastdeltay += r,
                v.debounced("mousewheely", function() {
                    var t = v.lastdeltay;
                    v.lastdeltay = 0,
                    v.rail.drag || v.doScrollBy(t)
                }, 120)
            }
            return t.stopImmediatePropagation(),
            t.preventDefault()
        }
        var v = this;
        if (this.version = "3.4.0",
        this.name = "nicescroll",
        this.me = p,
        this.opt = {
            doc: t("body"),
            win: !1
        },
        t.extend(this.opt, h),
        this.opt.snapbackspeed = 80,
        a)
            for (var w in v.opt)
                void 0 !== a[w] && (v.opt[w] = a[w]);
        this.iddoc = (this.doc = v.opt.doc) && this.doc[0] && this.doc[0].id || "",
        this.ispage = /BODY|HTML/.test(v.opt.win ? v.opt.win[0].nodeName : this.doc[0].nodeName),
        this.haswrapper = !1 !== v.opt.win,
        this.win = v.opt.win || (this.ispage ? t(window) : this.doc),
        this.docscroll = this.ispage && !this.haswrapper ? t(window) : this.win,
        this.body = t("body"),
        this.iframe = this.isfixed = this.viewport = !1,
        this.isiframe = "IFRAME" == this.doc[0].nodeName && "IFRAME" == this.win[0].nodeName,
        this.istextarea = "TEXTAREA" == this.win[0].nodeName,
        this.forcescreen = !1,
        this.canshowonmouseevent = "scroll" != v.opt.autohidemode,
        this.page = this.view = this.onzoomout = this.onzoomin = this.onscrollcancel = this.onscrollend = this.onscrollstart = this.onclick = this.ongesturezoom = this.onkeypress = this.onmousewheel = this.onmousemove = this.onmouseup = this.onmousedown = !1,
        this.scroll = {
            x: 0,
            y: 0
        },
        this.scrollratio = {
            x: 0,
            y: 0
        },
        this.cursorheight = 20,
        this.scrollvaluemax = 0,
        this.observerremover = this.observer = this.scrollmom = this.scrollrunning = this.checkrtlmode = !1;
        do {
            this.id = "ascrail" + r++
        } while (document.getElementById(this.id));
        this.hasmousefocus = this.hasfocus = this.zoomactive = this.zoom = this.selectiondrag = this.cursorfreezed = this.cursor = this.rail = !1,
        this.visibility = !0,
        this.hidden = this.locked = !1,
        this.cursoractive = !0,
        this.overflowx = v.opt.overflowx,
        this.overflowy = v.opt.overflowy,
        this.nativescrollingarea = !1,
        this.checkarea = 0,
        this.events = [],
        this.saved = {},
        this.delaylist = {},
        this.synclist = {},
        this.lastdeltay = this.lastdeltax = 0,
        this.detected = function() {
            if (d)
                return d;
            var t = document.createElement("DIV")
              , e = {
                haspointerlock: "pointerLockElement"in document || "mozPointerLockElement"in document || "webkitPointerLockElement"in document
            };
            e.isopera = "opera"in window,
            e.isopera12 = e.isopera && "getUserMedia"in navigator,
            e.isie = "all"in document && "attachEvent"in t && !e.isopera,
            e.isieold = e.isie && !("msInterpolationMode"in t.style),
            e.isie7 = e.isie && !e.isieold && (!("documentMode"in document) || 7 == document.documentMode),
            e.isie8 = e.isie && "documentMode"in document && 8 == document.documentMode,
            e.isie9 = e.isie && "performance"in window && 9 <= document.documentMode,
            e.isie10 = e.isie && "performance"in window && 10 <= document.documentMode,
            e.isie9mobile = /iemobile.9/i.test(navigator.userAgent),
            e.isie9mobile && (e.isie9 = !1),
            e.isie7mobile = !e.isie9mobile && e.isie7 && /iemobile/i.test(navigator.userAgent),
            e.ismozilla = "MozAppearance"in t.style,
            e.iswebkit = "WebkitAppearance"in t.style,
            e.ischrome = "chrome"in window,
            e.ischrome22 = e.ischrome && e.haspointerlock,
            e.ischrome26 = e.ischrome && "transition"in t.style,
            e.cantouch = "ontouchstart"in document.documentElement || "ontouchstart"in window,
            e.hasmstouch = window.navigator.msPointerEnabled || !1,
            e.ismac = /^mac$/i.test(navigator.platform),
            e.isios = e.cantouch && /iphone|ipad|ipod/i.test(navigator.platform),
            e.isios4 = e.isios && !("seal"in Object),
            e.isandroid = /android/i.test(navigator.userAgent),
            e.trstyle = !1,
            e.hastransform = !1,
            e.hastranslate3d = !1,
            e.transitionstyle = !1,
            e.hastransition = !1,
            e.transitionend = !1;
            for (var i = ["transform", "msTransform", "webkitTransform", "MozTransform", "OTransform"], o = 0; o < i.length; o++)
                if (void 0 !== t.style[i[o]]) {
                    e.trstyle = i[o];
                    break
                }
            e.hastransform = 0 != e.trstyle,
            e.hastransform && (t.style[e.trstyle] = "translate3d(1px,2px,3px)",
            e.hastranslate3d = /translate3d/.test(t.style[e.trstyle])),
            e.transitionstyle = !1,
            e.prefixstyle = "",
            e.transitionend = !1;
            i = "transition webkitTransition MozTransition OTransition OTransition msTransition KhtmlTransition".split(" ");
            var r = " -webkit- -moz- -o- -o -ms- -khtml-".split(" ")
              , n = "transitionend webkitTransitionEnd transitionend otransitionend oTransitionEnd msTransitionEnd KhtmlTransitionEnd".split(" ");
            for (o = 0; o < i.length; o++)
                if (i[o]in t.style) {
                    e.transitionstyle = i[o],
                    e.prefixstyle = r[o],
                    e.transitionend = n[o];
                    break
                }
            e.ischrome26 && (e.prefixstyle = r[1]),
            e.hastransition = e.transitionstyle;
            t: {
                for (i = ["-moz-grab", "-webkit-grab", "grab"],
                (e.ischrome && !e.ischrome22 || e.isie) && (i = []),
                o = 0; o < i.length; o++)
                    if (r = i[o],
                    t.style.cursor = r,
                    t.style.cursor == r) {
                        i = r;
                        break t
                    }
                i = "url(http://www.google.com/intl/en_ALL/mapfiles/openhand.cur),n-resize"
            }
            return e.cursorgrabvalue = i,
            e.hasmousecapture = "setCapture"in t,
            e.hasMutationObserver = !1 !== u,
            d = e
        }();
        var b = t.extend({}, this.detected);
        if (this.ishwscroll = (this.canhwscroll = b.hastransform && v.opt.hwacceleration) && v.haswrapper,
        this.istouchcapable = !1,
        b.cantouch && b.ischrome && !b.isios && !b.isandroid && (this.istouchcapable = !0,
        b.cantouch = !1),
        b.cantouch && b.ismozilla && !b.isios && (this.istouchcapable = !0,
        b.cantouch = !1),
        v.opt.enablemouselockapi || (b.hasmousecapture = !1,
        b.haspointerlock = !1),
        this.delayed = function(t, e, i, o) {
            var r = v.delaylist[t]
              , n = (new Date).getTime();
            if (!o && r && r.tt)
                return !1;
            r && r.tt && clearTimeout(r.tt),
            r && r.last + i > n && !r.tt ? v.delaylist[t] = {
                last: n + i,
                tt: setTimeout(function() {
                    v.delaylist[t].tt = 0,
                    e.call()
                }, i)
            } : r && r.tt || (v.delaylist[t] = {
                last: n,
                tt: 0
            },
            setTimeout(function() {
                e.call()
            }, 0))
        }
        ,
        this.debounced = function(t, e, i) {
            var o = v.delaylist[t];
            (new Date).getTime(),
            v.delaylist[t] = e,
            o || setTimeout(function() {
                var e = v.delaylist[t];
                v.delaylist[t] = !1,
                e.call()
            }, i)
        }
        ,
        this.synched = function(t, e) {
            return v.synclist[t] = e,
            v.onsync || (l(function() {
                for (t in v.onsync = !1,
                v.synclist) {
                    var e = v.synclist[t];
                    e && e.call(v),
                    v.synclist[t] = !1
                }
            }),
            v.onsync = !0),
            t
        }
        ,
        this.unsynched = function(t) {
            v.synclist[t] && (v.synclist[t] = !1)
        }
        ,
        this.css = function(t, e) {
            for (var i in e)
                v.saved.css.push([t, i, t.css(i)]),
                t.css(i, e[i])
        }
        ,
        this.scrollTop = function(t) {
            return void 0 === t ? v.getScrollTop() : v.setScrollTop(t)
        }
        ,
        this.scrollLeft = function(t) {
            return void 0 === t ? v.getScrollLeft() : v.setScrollLeft(t)
        }
        ,
        BezierClass = function(t, e, i, o, r, n, s) {
            this.st = t,
            this.ed = e,
            this.spd = i,
            this.p1 = o || 0,
            this.p2 = r || 1,
            this.p3 = n || 0,
            this.p4 = s || 1,
            this.ts = (new Date).getTime(),
            this.df = this.ed - this.st
        }
        ,
        BezierClass.prototype = {
            B2: function(t) {
                return 3 * t * t * (1 - t)
            },
            B3: function(t) {
                return 3 * t * (1 - t) * (1 - t)
            },
            B4: function(t) {
                return (1 - t) * (1 - t) * (1 - t)
            },
            getNow: function() {
                var t = 1 - ((new Date).getTime() - this.ts) / this.spd
                  , e = this.B2(t) + this.B3(t) + this.B4(t);
                return 0 > t ? this.ed : this.st + Math.round(this.df * e)
            },
            update: function(t, e) {
                return this.st = this.getNow(),
                this.ed = t,
                this.spd = e,
                this.ts = (new Date).getTime(),
                this.df = this.ed - this.st,
                this
            }
        },
        this.ishwscroll) {
            this.doc.translate = {
                x: 0,
                y: 0,
                tx: "0px",
                ty: "0px"
            },
            b.hastranslate3d && b.isios && this.doc.css("-webkit-backface-visibility", "hidden");
            var x = function() {
                var t = v.doc.css(b.trstyle);
                return !(!t || "matrix" != t.substr(0, 6)) && t.replace(/^.*\((.*)\)$/g, "$1").replace(/px/g, "").split(/, +/)
            };
            this.getScrollTop = function(t) {
                if (!t) {
                    if (t = x())
                        return 16 == t.length ? -t[13] : -t[5];
                    if (v.timerscroll && v.timerscroll.bz)
                        return v.timerscroll.bz.getNow()
                }
                return v.doc.translate.y
            }
            ,
            this.getScrollLeft = function(t) {
                if (!t) {
                    if (t = x())
                        return 16 == t.length ? -t[12] : -t[4];
                    if (v.timerscroll && v.timerscroll.bh)
                        return v.timerscroll.bh.getNow()
                }
                return v.doc.translate.x
            }
            ,
            this.notifyScrollEvent = document.createEvent ? function(t) {
                var e = document.createEvent("UIEvents");
                e.initUIEvent("scroll", !1, !0, window, 1),
                t.dispatchEvent(e)
            }
            : document.fireEvent ? function(t) {
                var e = document.createEventObject();
                t.fireEvent("onscroll"),
                e.cancelBubble = !0
            }
            : function(t, e) {}
            ,
            b.hastranslate3d && v.opt.enabletranslate3d ? (this.setScrollTop = function(t, e) {
                v.doc.translate.y = t,
                v.doc.translate.ty = -1 * t + "px",
                v.doc.css(b.trstyle, "translate3d(" + v.doc.translate.tx + "," + v.doc.translate.ty + ",0px)"),
                e || v.notifyScrollEvent(v.win[0])
            }
            ,
            this.setScrollLeft = function(t, e) {
                v.doc.translate.x = t,
                v.doc.translate.tx = -1 * t + "px",
                v.doc.css(b.trstyle, "translate3d(" + v.doc.translate.tx + "," + v.doc.translate.ty + ",0px)"),
                e || v.notifyScrollEvent(v.win[0])
            }
            ) : (this.setScrollTop = function(t, e) {
                v.doc.translate.y = t,
                v.doc.translate.ty = -1 * t + "px",
                v.doc.css(b.trstyle, "translate(" + v.doc.translate.tx + "," + v.doc.translate.ty + ")"),
                e || v.notifyScrollEvent(v.win[0])
            }
            ,
            this.setScrollLeft = function(t, e) {
                v.doc.translate.x = t,
                v.doc.translate.tx = -1 * t + "px",
                v.doc.css(b.trstyle, "translate(" + v.doc.translate.tx + "," + v.doc.translate.ty + ")"),
                e || v.notifyScrollEvent(v.win[0])
            }
            )
        } else
            this.getScrollTop = function() {
                return v.docscroll.scrollTop()
            }
            ,
            this.setScrollTop = function(t) {
                return v.docscroll.scrollTop(t)
            }
            ,
            this.getScrollLeft = function() {
                return v.docscroll.scrollLeft()
            }
            ,
            this.setScrollLeft = function(t) {
                return v.docscroll.scrollLeft(t)
            }
            ;
        this.getTarget = function(t) {
            return !!t && (t.target ? t.target : !!t.srcElement && t.srcElement)
        }
        ,
        this.hasParent = function(t, e) {
            if (!t)
                return !1;
            for (var i = t.target || t.srcElement || t || !1; i && i.id != e; )
                i = i.parentNode || !1;
            return !1 !== i
        }
        ;
        var T = {
            thin: 1,
            medium: 3,
            thick: 5
        };
        this.getOffset = function() {
            if (v.isfixed)
                return {
                    top: parseFloat(v.win.css("top")),
                    left: parseFloat(v.win.css("left"))
                };
            if (!v.viewport)
                return v.win.offset();
            var t = v.win.offset()
              , e = v.viewport.offset();
            return {
                top: t.top - e.top + v.viewport.scrollTop(),
                left: t.left - e.left + v.viewport.scrollLeft()
            }
        }
        ,
        this.updateScrollBar = function(t) {
            if (v.ishwscroll)
                v.rail.css({
                    height: v.win.innerHeight()
                }),
                v.railh && v.railh.css({
                    width: v.win.innerWidth()
                });
            else {
                var e = v.getOffset()
                  , i = e.top
                  , o = e.left;
                i = i + f(v.win, "border-top-width", !0);
                v.win.outerWidth(),
                v.win.innerWidth();
                o = o + (v.rail.align ? v.win.outerWidth() - f(v.win, "border-right-width") - v.rail.width : f(v.win, "border-left-width"));
                var r = v.opt.railoffset;
                r && (r.top && (i += r.top),
                v.rail.align && r.left && (o += r.left)),
                v.locked || v.rail.css({
                    top: i,
                    left: o,
                    height: t ? t.h : v.win.innerHeight()
                }),
                v.zoom && v.zoom.css({
                    top: i + 1,
                    left: 1 == v.rail.align ? o - 20 : o + v.rail.width + 4
                }),
                v.railh && !v.locked && (i = e.top,
                o = e.left,
                t = v.railh.align ? i + f(v.win, "border-top-width", !0) + v.win.innerHeight() - v.railh.height : i + f(v.win, "border-top-width", !0),
                o += f(v.win, "border-left-width"),
                v.railh.css({
                    top: t,
                    left: o,
                    width: v.railh.width
                }))
            }
        }
        ,
        this.doRailClick = function(t, e, i) {
            var o;
            v.locked || (v.cancelEvent(t),
            e ? (e = i ? v.doScrollLeft : v.doScrollTop)(o = i ? (t.pageX - v.railh.offset().left - v.cursorwidth / 2) * v.scrollratio.x : (t.pageY - v.rail.offset().top - v.cursorheight / 2) * v.scrollratio.y) : (e = i ? v.doScrollLeftBy : v.doScrollBy,
            o = i ? v.scroll.x : v.scroll.y,
            t = i ? t.pageX - v.railh.offset().left : t.pageY - v.rail.offset().top,
            i = i ? v.view.w : v.view.h,
            e(o >= t ? i : -i)))
        }
        ,
        v.hasanimationframe = l,
        v.hascancelanimationframe = c,
        v.hasanimationframe ? v.hascancelanimationframe || (c = function() {
            v.cancelAnimationFrame = !0
        }
        ) : (l = function(t) {
            return setTimeout(t, 15 - Math.floor(+new Date / 1e3) % 16)
        }
        ,
        c = clearInterval),
        this.init = function() {
            if (v.saved.css = [],
            b.isie7mobile)
                return !0;
            if (b.hasmstouch && v.css(v.ispage ? t("html") : v.win, {
                "-ms-touch-action": "none"
            }),
            v.zindex = "auto",
            v.zindex = v.ispage || "auto" != v.opt.zindex ? v.opt.zindex : function() {
                var t = v.win;
                if ("zIndex"in t)
                    return t.zIndex();
                for (; 0 < t.length && 9 != t[0].nodeType; ) {
                    var e = t.css("zIndex");
                    if (!isNaN(e) && 0 != e)
                        return parseInt(e);
                    t = t.parent()
                }
                return !1
            }() || "auto",
            !v.ispage && "auto" != v.zindex && v.zindex > n && (n = v.zindex),
            v.isie && 0 == v.zindex && "auto" == v.opt.zindex && (v.zindex = "auto"),
            !v.ispage || !b.cantouch && !b.isieold && !b.isie9mobile) {
                var r = v.docscroll;
                v.ispage && (r = v.haswrapper ? v.win : v.doc),
                b.isie9mobile || v.css(r, {
                    "overflow-y": "hidden"
                }),
                v.ispage && b.isie7 && ("BODY" == v.doc[0].nodeName ? v.css(t("html"), {
                    "overflow-y": "hidden"
                }) : "HTML" == v.doc[0].nodeName && v.css(t("body"), {
                    "overflow-y": "hidden"
                })),
                b.isios && !v.ispage && !v.haswrapper && v.css(t("body"), {
                    "-webkit-overflow-scrolling": "touch"
                });
                var a = t(document.createElement("div"));
                a.css({
                    position: "relative",
                    top: 0,
                    float: "right",
                    width: v.opt.cursorwidth,
                    height: "0px",
                    "background-color": v.opt.cursorcolor,
                    border: v.opt.cursorborder,
                    "background-clip": "padding-box",
                    "-webkit-border-radius": v.opt.cursorborderradius,
                    "-moz-border-radius": v.opt.cursorborderradius,
                    "border-radius": v.opt.cursorborderradius
                }),
                a.hborder = parseFloat(a.outerHeight() - a.innerHeight()),
                v.cursor = a,
                (w = t(document.createElement("div"))).attr("id", v.id),
                w.addClass("nicescroll-rails");
                var l, c, h, d = ["left", "right"];
                for (h in d)
                    c = d[h],
                    (l = v.opt.railpadding[c]) ? w.css("padding-" + c, l + "px") : v.opt.railpadding[c] = 0;
                if (w.append(a),
                w.width = Math.max(parseFloat(v.opt.cursorwidth), a.outerWidth()) + v.opt.railpadding.left + v.opt.railpadding.right,
                w.css({
                    width: w.width + "px",
                    zIndex: v.zindex,
                    background: v.opt.background,
                    cursor: "default"
                }),
                w.visibility = !0,
                w.scrollable = !0,
                w.align = "left" == v.opt.railalign ? 0 : 1,
                v.rail = w,
                a = v.rail.drag = !1,
                v.opt.boxzoom && !v.ispage && !b.isieold && (a = document.createElement("div"),
                v.bind(a, "click", v.doZoom),
                v.zoom = t(a),
                v.zoom.css({
                    cursor: "pointer",
                    "z-index": v.zindex,
                    backgroundImage: "url(" + s + "zoomico.png)",
                    height: 18,
                    width: 18,
                    backgroundPosition: "0px 0px"
                }),
                v.opt.dblclickzoom && v.bind(v.win, "dblclick", v.doZoom),
                b.cantouch && v.opt.gesturezoom && (v.ongesturezoom = function(t) {
                    return 1.5 < t.scale && v.doZoomIn(t),
                    .8 > t.scale && v.doZoomOut(t),
                    v.cancelEvent(t)
                }
                ,
                v.bind(v.win, "gestureend", v.ongesturezoom))),
                v.railh = !1,
                v.opt.horizrailenabled) {
                    v.css(r, {
                        "overflow-x": "hidden"
                    }),
                    (a = t(document.createElement("div"))).css({
                        position: "relative",
                        top: 0,
                        height: v.opt.cursorwidth,
                        width: "0px",
                        "background-color": v.opt.cursorcolor,
                        border: v.opt.cursorborder,
                        "background-clip": "padding-box",
                        "-webkit-border-radius": v.opt.cursorborderradius,
                        "-moz-border-radius": v.opt.cursorborderradius,
                        "border-radius": v.opt.cursorborderradius
                    }),
                    a.wborder = parseFloat(a.outerWidth() - a.innerWidth()),
                    v.cursorh = a;
                    var p = t(document.createElement("div"));
                    p.attr("id", v.id + "-hr"),
                    p.addClass("nicescroll-rails"),
                    p.height = Math.max(parseFloat(v.opt.cursorwidth), a.outerHeight()),
                    p.css({
                        height: p.height + "px",
                        zIndex: v.zindex,
                        background: v.opt.background
                    }),
                    p.append(a),
                    p.visibility = !0,
                    p.scrollable = !0,
                    p.align = "top" == v.opt.railvalign ? 0 : 1,
                    v.railh = p,
                    v.railh.drag = !1
                }
                if (v.ispage ? (w.css({
                    position: "fixed",
                    top: "0px",
                    height: "100%"
                }),
                w.align ? w.css({
                    right: "0px"
                }) : w.css({
                    left: "0px"
                }),
                v.body.append(w),
                v.railh && (p.css({
                    position: "fixed",
                    left: "0px",
                    width: "100%"
                }),
                p.align ? p.css({
                    bottom: "0px"
                }) : p.css({
                    top: "0px"
                }),
                v.body.append(p))) : (v.ishwscroll ? ("static" == v.win.css("position") && v.css(v.win, {
                    position: "relative"
                }),
                r = "HTML" == v.win[0].nodeName ? v.body : v.win,
                v.zoom && (v.zoom.css({
                    position: "absolute",
                    top: 1,
                    right: 0,
                    "margin-right": w.width + 4
                }),
                r.append(v.zoom)),
                w.css({
                    position: "absolute",
                    top: 0
                }),
                w.align ? w.css({
                    right: 0
                }) : w.css({
                    left: 0
                }),
                r.append(w),
                p && (p.css({
                    position: "absolute",
                    left: 0,
                    bottom: 0
                }),
                p.align ? p.css({
                    bottom: 0
                }) : p.css({
                    top: 0
                }),
                r.append(p))) : (v.isfixed = "fixed" == v.win.css("position"),
                r = v.isfixed ? "fixed" : "absolute",
                v.isfixed || (v.viewport = v.getViewport(v.win[0])),
                v.viewport && (v.body = v.viewport,
                0 == /relative|absolute/.test(v.viewport.css("position")) && v.css(v.viewport, {
                    position: "relative"
                })),
                w.css({
                    position: r
                }),
                v.zoom && v.zoom.css({
                    position: r
                }),
                v.updateScrollBar(),
                v.body.append(w),
                v.zoom && v.body.append(v.zoom),
                v.railh && (p.css({
                    position: r
                }),
                v.body.append(p))),
                b.isios && v.css(v.win, {
                    "-webkit-tap-highlight-color": "rgba(0,0,0,0)",
                    "-webkit-touch-callout": "none"
                }),
                b.isie && v.opt.disableoutline && v.win.attr("hideFocus", "true"),
                b.iswebkit && v.opt.disableoutline && v.win.css({
                    outline: "none"
                })),
                !1 === v.opt.autohidemode ? (v.autohidedom = !1,
                v.rail.css({
                    opacity: v.opt.cursoropacitymax
                }),
                v.railh && v.railh.css({
                    opacity: v.opt.cursoropacitymax
                })) : !0 === v.opt.autohidemode ? (v.autohidedom = t().add(v.rail),
                b.isie8 && (v.autohidedom = v.autohidedom.add(v.cursor)),
                v.railh && (v.autohidedom = v.autohidedom.add(v.railh)),
                v.railh && b.isie8 && (v.autohidedom = v.autohidedom.add(v.cursorh))) : "scroll" == v.opt.autohidemode ? (v.autohidedom = t().add(v.rail),
                v.railh && (v.autohidedom = v.autohidedom.add(v.railh))) : "cursor" == v.opt.autohidemode ? (v.autohidedom = t().add(v.cursor),
                v.railh && (v.autohidedom = v.autohidedom.add(v.cursorh))) : "hidden" == v.opt.autohidemode && (v.autohidedom = !1,
                v.hide(),
                v.locked = !1),
                b.isie9mobile)
                    v.scrollmom = new m(v),
                    v.onmangotouch = function(t) {
                        t = v.getScrollTop();
                        var e = v.getScrollLeft();
                        if (t == v.scrollmom.lastscrolly && e == v.scrollmom.lastscrollx)
                            return !0;
                        var i = t - v.mangotouch.sy
                          , o = e - v.mangotouch.sx;
                        if (0 != Math.round(Math.sqrt(Math.pow(o, 2) + Math.pow(i, 2)))) {
                            var r = 0 > i ? -1 : 1
                              , n = 0 > o ? -1 : 1
                              , s = +new Date;
                            v.mangotouch.lazy && clearTimeout(v.mangotouch.lazy),
                            80 < s - v.mangotouch.tm || v.mangotouch.dry != r || v.mangotouch.drx != n ? (v.scrollmom.stop(),
                            v.scrollmom.reset(e, t),
                            v.mangotouch.sy = t,
                            v.mangotouch.ly = t,
                            v.mangotouch.sx = e,
                            v.mangotouch.lx = e,
                            v.mangotouch.dry = r,
                            v.mangotouch.drx = n,
                            v.mangotouch.tm = s) : (v.scrollmom.stop(),
                            v.scrollmom.update(v.mangotouch.sx - o, v.mangotouch.sy - i),
                            v.mangotouch.tm = s,
                            i = Math.max(Math.abs(v.mangotouch.ly - t), Math.abs(v.mangotouch.lx - e)),
                            v.mangotouch.ly = t,
                            v.mangotouch.lx = e,
                            2 < i && (v.mangotouch.lazy = setTimeout(function() {
                                v.mangotouch.lazy = !1,
                                v.mangotouch.dry = 0,
                                v.mangotouch.drx = 0,
                                v.mangotouch.tm = 0,
                                v.scrollmom.doMomentum(30)
                            }, 100)))
                        }
                    }
                    ,
                    w = v.getScrollTop(),
                    p = v.getScrollLeft(),
                    v.mangotouch = {
                        sy: w,
                        ly: w,
                        dry: 0,
                        sx: p,
                        lx: p,
                        drx: 0,
                        lazy: !1,
                        tm: 0
                    },
                    v.bind(v.docscroll, "scroll", v.onmangotouch);
                else {
                    if (b.cantouch || v.istouchcapable || v.opt.touchbehavior || b.hasmstouch) {
                        v.scrollmom = new m(v),
                        v.ontouchstart = function(e) {
                            if (e.pointerType && 2 != e.pointerType)
                                return !1;
                            if (!v.locked) {
                                if (b.hasmstouch)
                                    for (var i = !!e.target && e.target; i; ) {
                                        if (0 < (o = t(i).getNiceScroll()).length && o[0].me == v.me)
                                            break;
                                        if (0 < o.length)
                                            return !1;
                                        if ("DIV" == i.nodeName && i.id == v.id)
                                            break;
                                        i = !!i.parentNode && i.parentNode
                                    }
                                if (v.cancelScroll(),
                                (i = v.getTarget(e)) && /INPUT/i.test(i.nodeName) && /range/i.test(i.type))
                                    return v.stopPropagation(e);
                                if (!("clientX"in e) && "changedTouches"in e && (e.clientX = e.changedTouches[0].clientX,
                                e.clientY = e.changedTouches[0].clientY),
                                v.forcescreen && (o = e,
                                (e = {
                                    original: e.original ? e.original : e
                                }).clientX = o.screenX,
                                e.clientY = o.screenY),
                                v.rail.drag = {
                                    x: e.clientX,
                                    y: e.clientY,
                                    sx: v.scroll.x,
                                    sy: v.scroll.y,
                                    st: v.getScrollTop(),
                                    sl: v.getScrollLeft(),
                                    pt: 2,
                                    dl: !1
                                },
                                v.ispage || !v.opt.directionlockdeadzone)
                                    v.rail.drag.dl = "f";
                                else {
                                    var o = t(window).width()
                                      , r = t(window).height()
                                      , n = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth)
                                      , s = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                                    r = Math.max(0, s - r),
                                    o = Math.max(0, n - o);
                                    v.rail.drag.ck = !v.rail.scrollable && v.railh.scrollable ? 0 < r && "v" : !(!v.rail.scrollable || v.railh.scrollable) && (0 < o && "h"),
                                    v.rail.drag.ck || (v.rail.drag.dl = "f")
                                }
                                if (v.opt.touchbehavior && v.isiframe && b.isie && (o = v.win.position(),
                                v.rail.drag.x += o.left,
                                v.rail.drag.y += o.top),
                                v.hasmoving = !1,
                                v.lastmouseup = !1,
                                v.scrollmom.reset(e.clientX, e.clientY),
                                !b.cantouch && !this.istouchcapable && !b.hasmstouch) {
                                    if (!i || !/INPUT|SELECT|TEXTAREA/i.test(i.nodeName))
                                        return !v.ispage && b.hasmousecapture && i.setCapture(),
                                        v.cancelEvent(e);
                                    /SUBMIT|CANCEL|BUTTON/i.test(t(i).attr("type")) && (pc = {
                                        tg: i,
                                        click: !1
                                    },
                                    v.preventclick = pc)
                                }
                            }
                        }
                        ,
                        v.ontouchend = function(t) {
                            return (!t.pointerType || 2 == t.pointerType) && (v.rail.drag && 2 == v.rail.drag.pt && (v.scrollmom.doMomentum(),
                            v.rail.drag = !1,
                            v.hasmoving && (v.hasmoving = !1,
                            v.lastmouseup = !0,
                            v.hideCursor(),
                            b.hasmousecapture && document.releaseCapture(),
                            !b.cantouch)) ? v.cancelEvent(t) : void 0)
                        }
                        ;
                        var f = v.opt.touchbehavior && v.isiframe && !b.hasmousecapture;
                        v.ontouchmove = function(e, i) {
                            if (e.pointerType && 2 != e.pointerType)
                                return !1;
                            if (v.rail.drag && 2 == v.rail.drag.pt) {
                                if (b.cantouch && void 0 === e.original)
                                    return !0;
                                if (v.hasmoving = !0,
                                v.preventclick && !v.preventclick.click && (v.preventclick.click = v.preventclick.tg.onclick || !1,
                                v.preventclick.tg.onclick = v.onpreventclick),
                                "changedTouches"in (e = t.extend({
                                    original: e
                                }, e)) && (e.clientX = e.changedTouches[0].clientX,
                                e.clientY = e.changedTouches[0].clientY),
                                v.forcescreen) {
                                    var o = e;
                                    (e = {
                                        original: e.original ? e.original : e
                                    }).clientX = o.screenX,
                                    e.clientY = o.screenY
                                }
                                if (o = ofy = 0,
                                f && !i) {
                                    o = -(n = v.win.position()).left;
                                    ofy = -n.top
                                }
                                var r = e.clientY + ofy
                                  , n = r - v.rail.drag.y
                                  , s = e.clientX + o
                                  , a = s - v.rail.drag.x
                                  , l = v.rail.drag.st - n;
                                if (v.ishwscroll && v.opt.bouncescroll ? 0 > l ? l = Math.round(l / 2) : l > v.page.maxh && (l = v.page.maxh + Math.round((l - v.page.maxh) / 2)) : (0 > l && (r = l = 0),
                                l > v.page.maxh && (l = v.page.maxh,
                                r = 0)),
                                v.railh && v.railh.scrollable) {
                                    var c = v.rail.drag.sl - a;
                                    v.ishwscroll && v.opt.bouncescroll ? 0 > c ? c = Math.round(c / 2) : c > v.page.maxw && (c = v.page.maxw + Math.round((c - v.page.maxw) / 2)) : (0 > c && (s = c = 0),
                                    c > v.page.maxw && (c = v.page.maxw,
                                    s = 0))
                                }
                                if (o = !1,
                                v.rail.drag.dl)
                                    o = !0,
                                    "v" == v.rail.drag.dl ? c = v.rail.drag.sl : "h" == v.rail.drag.dl && (l = v.rail.drag.st);
                                else {
                                    n = Math.abs(n),
                                    a = Math.abs(a);
                                    var u = v.opt.directionlockdeadzone;
                                    if ("v" == v.rail.drag.ck) {
                                        if (n > u && a <= .3 * n)
                                            return v.rail.drag = !1,
                                            !0;
                                        a > u && (v.rail.drag.dl = "f",
                                        t("body").scrollTop(t("body").scrollTop()))
                                    } else if ("h" == v.rail.drag.ck) {
                                        if (a > u && n <= .3 * az)
                                            return v.rail.drag = !1,
                                            !0;
                                        n > u && (v.rail.drag.dl = "f",
                                        t("body").scrollLeft(t("body").scrollLeft()))
                                    }
                                }
                                if (v.synched("touchmove", function() {
                                    v.rail.drag && 2 == v.rail.drag.pt && (v.prepareTransition && v.prepareTransition(0),
                                    v.rail.scrollable && v.setScrollTop(l),
                                    v.scrollmom.update(s, r),
                                    v.railh && v.railh.scrollable ? (v.setScrollLeft(c),
                                    v.showCursor(l, c)) : v.showCursor(l),
                                    b.isie10 && document.selection.clear())
                                }),
                                b.ischrome && v.istouchcapable && (o = !1),
                                o)
                                    return v.cancelEvent(e)
                            }
                        }
                    }
                    if (v.onmousedown = function(t, e) {
                        if (!v.rail.drag || 1 == v.rail.drag.pt) {
                            if (v.locked)
                                return v.cancelEvent(t);
                            v.cancelScroll(),
                            v.rail.drag = {
                                x: t.clientX,
                                y: t.clientY,
                                sx: v.scroll.x,
                                sy: v.scroll.y,
                                pt: 1,
                                hr: !!e
                            };
                            var i = v.getTarget(t);
                            return !v.ispage && b.hasmousecapture && i.setCapture(),
                            v.isiframe && !b.hasmousecapture && (v.saved.csspointerevents = v.doc.css("pointer-events"),
                            v.css(v.doc, {
                                "pointer-events": "none"
                            })),
                            v.cancelEvent(t)
                        }
                    }
                    ,
                    v.onmouseup = function(t) {
                        if (v.rail.drag && (b.hasmousecapture && document.releaseCapture(),
                        v.isiframe && !b.hasmousecapture && v.doc.css("pointer-events", v.saved.csspointerevents),
                        1 == v.rail.drag.pt))
                            return v.rail.drag = !1,
                            v.cancelEvent(t)
                    }
                    ,
                    v.onmousemove = function(t) {
                        if (v.rail.drag && 1 == v.rail.drag.pt) {
                            if (b.ischrome && 0 == t.which)
                                return v.onmouseup(t);
                            if (v.cursorfreezed = !0,
                            v.rail.drag.hr) {
                                v.scroll.x = v.rail.drag.sx + (t.clientX - v.rail.drag.x),
                                0 > v.scroll.x && (v.scroll.x = 0);
                                var e = v.scrollvaluemaxw;
                                v.scroll.x > e && (v.scroll.x = e)
                            } else
                                v.scroll.y = v.rail.drag.sy + (t.clientY - v.rail.drag.y),
                                0 > v.scroll.y && (v.scroll.y = 0),
                                e = v.scrollvaluemax,
                                v.scroll.y > e && (v.scroll.y = e);
                            return v.synched("mousemove", function() {
                                v.rail.drag && 1 == v.rail.drag.pt && (v.showCursor(),
                                v.rail.drag.hr ? v.doScrollLeft(Math.round(v.scroll.x * v.scrollratio.x), v.opt.cursordragspeed) : v.doScrollTop(Math.round(v.scroll.y * v.scrollratio.y), v.opt.cursordragspeed))
                            }),
                            v.cancelEvent(t)
                        }
                    }
                    ,
                    b.cantouch || v.opt.touchbehavior)
                        v.onpreventclick = function(t) {
                            if (v.preventclick)
                                return v.preventclick.tg.onclick = v.preventclick.click,
                                v.preventclick = !1,
                                v.cancelEvent(t)
                        }
                        ,
                        v.bind(v.win, "mousedown", v.ontouchstart),
                        v.onclick = !b.isios && function(t) {
                            return !v.lastmouseup || (v.lastmouseup = !1,
                            v.cancelEvent(t))
                        }
                        ,
                        v.opt.grabcursorenabled && b.cursorgrabvalue && (v.css(v.ispage ? v.doc : v.win, {
                            cursor: b.cursorgrabvalue
                        }),
                        v.css(v.rail, {
                            cursor: b.cursorgrabvalue
                        }));
                    else {
                        var g = function(t) {
                            if (v.selectiondrag) {
                                if (t) {
                                    var e = v.win.outerHeight();
                                    0 < (t = t.pageY - v.selectiondrag.top) && t < e && (t = 0),
                                    t >= e && (t -= e),
                                    v.selectiondrag.df = t
                                }
                                0 != v.selectiondrag.df && (v.doScrollBy(2 * -Math.floor(v.selectiondrag.df / 6)),
                                v.debounced("doselectionscroll", function() {
                                    g()
                                }, 50))
                            }
                        };
                        v.hasTextSelected = "getSelection"in document ? function() {
                            return 0 < document.getSelection().rangeCount
                        }
                        : "selection"in document ? function() {
                            return "None" != document.selection.type
                        }
                        : function() {
                            return !1
                        }
                        ,
                        v.onselectionstart = function(t) {
                            v.ispage || (v.selectiondrag = v.win.offset())
                        }
                        ,
                        v.onselectionend = function(t) {
                            v.selectiondrag = !1
                        }
                        ,
                        v.onselectiondrag = function(t) {
                            v.selectiondrag && v.hasTextSelected() && v.debounced("selectionscroll", function() {
                                g(t)
                            }, 250)
                        }
                    }
                    b.hasmstouch && (v.css(v.rail, {
                        "-ms-touch-action": "none"
                    }),
                    v.css(v.cursor, {
                        "-ms-touch-action": "none"
                    }),
                    v.bind(v.win, "MSPointerDown", v.ontouchstart),
                    v.bind(document, "MSPointerUp", v.ontouchend),
                    v.bind(document, "MSPointerMove", v.ontouchmove),
                    v.bind(v.cursor, "MSGestureHold", function(t) {
                        t.preventDefault()
                    }),
                    v.bind(v.cursor, "contextmenu", function(t) {
                        t.preventDefault()
                    })),
                    this.istouchcapable && (v.bind(v.win, "touchstart", v.ontouchstart),
                    v.bind(document, "touchend", v.ontouchend),
                    v.bind(document, "touchcancel", v.ontouchend),
                    v.bind(document, "touchmove", v.ontouchmove)),
                    v.bind(v.cursor, "mousedown", v.onmousedown),
                    v.bind(v.cursor, "mouseup", v.onmouseup),
                    v.railh && (v.bind(v.cursorh, "mousedown", function(t) {
                        v.onmousedown(t, !0)
                    }),
                    v.bind(v.cursorh, "mouseup", function(t) {
                        if (!v.rail.drag || 2 != v.rail.drag.pt)
                            return v.rail.drag = !1,
                            v.hasmoving = !1,
                            v.hideCursor(),
                            b.hasmousecapture && document.releaseCapture(),
                            v.cancelEvent(t)
                    })),
                    (v.opt.cursordragontouch || !b.cantouch && !v.opt.touchbehavior) && (v.rail.css({
                        cursor: "default"
                    }),
                    v.railh && v.railh.css({
                        cursor: "default"
                    }),
                    v.jqbind(v.rail, "mouseenter", function() {
                        v.canshowonmouseevent && v.showCursor(),
                        v.rail.active = !0
                    }),
                    v.jqbind(v.rail, "mouseleave", function() {
                        v.rail.active = !1,
                        v.rail.drag || v.hideCursor()
                    }),
                    v.opt.sensitiverail && (v.bind(v.rail, "click", function(t) {
                        v.doRailClick(t, !1, !1)
                    }),
                    v.bind(v.rail, "dblclick", function(t) {
                        v.doRailClick(t, !0, !1)
                    }),
                    v.bind(v.cursor, "click", function(t) {
                        v.cancelEvent(t)
                    }),
                    v.bind(v.cursor, "dblclick", function(t) {
                        v.cancelEvent(t)
                    })),
                    v.railh && (v.jqbind(v.railh, "mouseenter", function() {
                        v.canshowonmouseevent && v.showCursor(),
                        v.rail.active = !0
                    }),
                    v.jqbind(v.railh, "mouseleave", function() {
                        v.rail.active = !1,
                        v.rail.drag || v.hideCursor()
                    }),
                    v.opt.sensitiverail && (v.bind(v.railh, "click", function(t) {
                        v.doRailClick(t, !1, !0)
                    }),
                    v.bind(v.railh, "dblclick", function(t) {
                        v.doRailClick(t, !0, !0)
                    }),
                    v.bind(v.cursorh, "click", function(t) {
                        v.cancelEvent(t)
                    }),
                    v.bind(v.cursorh, "dblclick", function(t) {
                        v.cancelEvent(t)
                    })))),
                    b.cantouch || v.opt.touchbehavior ? (v.bind(b.hasmousecapture ? v.win : document, "mouseup", v.ontouchend),
                    v.bind(document, "mousemove", v.ontouchmove),
                    v.onclick && v.bind(document, "click", v.onclick),
                    v.opt.cursordragontouch && (v.bind(v.cursor, "mousedown", v.onmousedown),
                    v.bind(v.cursor, "mousemove", v.onmousemove),
                    v.cursorh && v.bind(v.cursorh, "mousedown", v.onmousedown),
                    v.cursorh && v.bind(v.cursorh, "mousemove", v.onmousemove))) : (v.bind(b.hasmousecapture ? v.win : document, "mouseup", v.onmouseup),
                    v.bind(document, "mousemove", v.onmousemove),
                    v.onclick && v.bind(document, "click", v.onclick),
                    !v.ispage && v.opt.enablescrollonselection && (v.bind(v.win[0], "mousedown", v.onselectionstart),
                    v.bind(document, "mouseup", v.onselectionend),
                    v.bind(v.cursor, "mouseup", v.onselectionend),
                    v.cursorh && v.bind(v.cursorh, "mouseup", v.onselectionend),
                    v.bind(document, "mousemove", v.onselectiondrag)),
                    v.zoom && (v.jqbind(v.zoom, "mouseenter", function() {
                        v.canshowonmouseevent && v.showCursor(),
                        v.rail.active = !0
                    }),
                    v.jqbind(v.zoom, "mouseleave", function() {
                        v.rail.active = !1,
                        v.rail.drag || v.hideCursor()
                    }))),
                    v.opt.enablemousewheel && (v.isiframe || v.bind(b.isie && v.ispage ? document : v.docscroll, "mousewheel", v.onmousewheel),
                    v.bind(v.rail, "mousewheel", v.onmousewheel),
                    v.railh && v.bind(v.railh, "mousewheel", v.onmousewheelhr)),
                    !v.ispage && !b.cantouch && !/HTML|BODY/.test(v.win[0].nodeName) && (v.win.attr("tabindex") || v.win.attr({
                        tabindex: o++
                    }),
                    v.jqbind(v.win, "focus", function(t) {
                        e = v.getTarget(t).id || !0,
                        v.hasfocus = !0,
                        v.canshowonmouseevent && v.noticeCursor()
                    }),
                    v.jqbind(v.win, "blur", function(t) {
                        e = !1,
                        v.hasfocus = !1
                    }),
                    v.jqbind(v.win, "mouseenter", function(t) {
                        i = v.getTarget(t).id || !0,
                        v.hasmousefocus = !0,
                        v.canshowonmouseevent && v.noticeCursor()
                    }),
                    v.jqbind(v.win, "mouseleave", function() {
                        i = !1,
                        v.hasmousefocus = !1
                    }))
                }
                if (v.onkeypress = function(t) {
                    if (v.locked && 0 == v.page.maxh)
                        return !0;
                    t = t || window.e;
                    var o = v.getTarget(t);
                    if (o && /INPUT|TEXTAREA|SELECT|OPTION/.test(o.nodeName) && (!o.getAttribute("type") && !o.type || !/submit|button|cancel/i.tp))
                        return !0;
                    if (v.hasfocus || v.hasmousefocus && !e || v.ispage && !e && !i) {
                        if (o = t.keyCode,
                        v.locked && 27 != o)
                            return v.cancelEvent(t);
                        var r = t.ctrlKey || !1
                          , n = t.shiftKey || !1
                          , s = !1;
                        switch (o) {
                        case 38:
                        case 63233:
                            v.doScrollBy(72),
                            s = !0;
                            break;
                        case 40:
                        case 63235:
                            v.doScrollBy(-72),
                            s = !0;
                            break;
                        case 37:
                        case 63232:
                            v.railh && (r ? v.doScrollLeft(0) : v.doScrollLeftBy(72),
                            s = !0);
                            break;
                        case 39:
                        case 63234:
                            v.railh && (r ? v.doScrollLeft(v.page.maxw) : v.doScrollLeftBy(-72),
                            s = !0);
                            break;
                        case 33:
                        case 63276:
                            v.doScrollBy(v.view.h),
                            s = !0;
                            break;
                        case 34:
                        case 63277:
                            v.doScrollBy(-v.view.h),
                            s = !0;
                            break;
                        case 36:
                        case 63273:
                            v.railh && r ? v.doScrollPos(0, 0) : v.doScrollTo(0),
                            s = !0;
                            break;
                        case 35:
                        case 63275:
                            v.railh && r ? v.doScrollPos(v.page.maxw, v.page.maxh) : v.doScrollTo(v.page.maxh),
                            s = !0;
                            break;
                        case 32:
                            v.opt.spacebarenabled && (n ? v.doScrollBy(v.view.h) : v.doScrollBy(-v.view.h),
                            s = !0);
                            break;
                        case 27:
                            v.zoomactive && (v.doZoom(),
                            s = !0)
                        }
                        if (s)
                            return v.cancelEvent(t)
                    }
                }
                ,
                v.opt.enablekeyboard && v.bind(document, b.isopera && !b.isopera12 ? "keypress" : "keydown", v.onkeypress),
                v.bind(window, "resize", v.lazyResize),
                v.bind(window, "orientationchange", v.lazyResize),
                v.bind(window, "load", v.lazyResize),
                b.ischrome && !v.ispage && !v.haswrapper) {
                    var y = v.win.attr("style")
                      , w = parseFloat(v.win.css("width")) + 1;
                    v.win.css("width", w),
                    v.synched("chromefix", function() {
                        v.win.attr("style", y)
                    })
                }
                v.onAttributeChange = function(t) {
                    v.lazyResize(250)
                }
                ,
                !v.ispage && !v.haswrapper && (!1 !== u ? (v.observer = new u(function(t) {
                    t.forEach(v.onAttributeChange)
                }
                ),
                v.observer.observe(v.win[0], {
                    childList: !0,
                    characterData: !1,
                    attributes: !0,
                    subtree: !1
                }),
                v.observerremover = new u(function(t) {
                    t.forEach(function(t) {
                        if (0 < t.removedNodes.length)
                            for (var e in t.removedNodes)
                                if (t.removedNodes[e] == v.win[0])
                                    return v.remove()
                    })
                }
                ),
                v.observerremover.observe(v.win[0].parentNode, {
                    childList: !0,
                    characterData: !1,
                    attributes: !1,
                    subtree: !1
                })) : (v.bind(v.win, b.isie && !b.isie9 ? "propertychange" : "DOMAttrModified", v.onAttributeChange),
                b.isie9 && v.win[0].attachEvent("onpropertychange", v.onAttributeChange),
                v.bind(v.win, "DOMNodeRemoved", function(t) {
                    t.target == v.win[0] && v.remove()
                }))),
                !v.ispage && v.opt.boxzoom && v.bind(window, "resize", v.resizeZoom),
                v.istextarea && v.bind(v.win, "mouseup", v.lazyResize),
                v.checkrtlmode = !0,
                v.lazyResize(30)
            }
            if ("IFRAME" == this.doc[0].nodeName) {
                var x = function(e) {
                    v.iframexd = !1;
                    try {
                        var i = "contentDocument"in this ? this.contentDocument : this.contentWindow.document
                    } catch (t) {
                        v.iframexd = !0,
                        i = !1
                    }
                    if (v.iframexd)
                        return "console"in window && console.log("NiceScroll error: policy restriced iframe"),
                        !0;
                    v.forcescreen = !0,
                    v.isiframe && (v.iframe = {
                        doc: t(i),
                        html: v.doc.contents().find("html")[0],
                        body: v.doc.contents().find("body")[0]
                    },
                    v.getContentSize = function() {
                        return {
                            w: Math.max(v.iframe.html.scrollWidth, v.iframe.body.scrollWidth),
                            h: Math.max(v.iframe.html.scrollHeight, v.iframe.body.scrollHeight)
                        }
                    }
                    ,
                    v.docscroll = t(v.iframe.body)),
                    !b.isios && v.opt.iframeautoresize && !v.isiframe && (v.win.scrollTop(0),
                    v.doc.height(""),
                    e = Math.max(i.getElementsByTagName("html")[0].scrollHeight, i.body.scrollHeight),
                    v.doc.height(e)),
                    v.lazyResize(30),
                    b.isie7 && v.css(t(v.iframe.html), {
                        "overflow-y": "hidden"
                    }),
                    v.css(t(v.iframe.body), {
                        "overflow-y": "hidden"
                    }),
                    "contentWindow"in this ? v.bind(this.contentWindow, "scroll", v.onscroll) : v.bind(i, "scroll", v.onscroll),
                    v.opt.enablemousewheel && v.bind(i, "mousewheel", v.onmousewheel),
                    v.opt.enablekeyboard && v.bind(i, b.isopera ? "keypress" : "keydown", v.onkeypress),
                    (b.cantouch || v.opt.touchbehavior) && (v.bind(i, "mousedown", v.onmousedown),
                    v.bind(i, "mousemove", function(t) {
                        v.onmousemove(t, !0)
                    }),
                    v.opt.grabcursorenabled && b.cursorgrabvalue && v.css(t(i.body), {
                        cursor: b.cursorgrabvalue
                    })),
                    v.bind(i, "mouseup", v.onmouseup),
                    v.zoom && (v.opt.dblclickzoom && v.bind(i, "dblclick", v.doZoom),
                    v.ongesturezoom && v.bind(i, "gestureend", v.ongesturezoom))
                };
                this.doc[0].readyState && "complete" == this.doc[0].readyState && setTimeout(function() {
                    x.call(v.doc[0], !1)
                }, 500),
                v.bind(this.doc, "load", x)
            }
        }
        ,
        this.showCursor = function(t, e) {
            v.cursortimeout && (clearTimeout(v.cursortimeout),
            v.cursortimeout = 0),
            v.rail && (v.autohidedom && (v.autohidedom.stop().css({
                opacity: v.opt.cursoropacitymax
            }),
            v.cursoractive = !0),
            v.rail.drag && 1 == v.rail.drag.pt || (void 0 !== t && !1 !== t && (v.scroll.y = Math.round(1 * t / v.scrollratio.y)),
            void 0 !== e && (v.scroll.x = Math.round(1 * e / v.scrollratio.x))),
            v.cursor.css({
                height: v.cursorheight,
                top: v.scroll.y
            }),
            v.cursorh && (!v.rail.align && v.rail.visibility ? v.cursorh.css({
                width: v.cursorwidth,
                left: v.scroll.x + v.rail.width
            }) : v.cursorh.css({
                width: v.cursorwidth,
                left: v.scroll.x
            }),
            v.cursoractive = !0),
            v.zoom && v.zoom.stop().css({
                opacity: v.opt.cursoropacitymax
            }))
        }
        ,
        this.hideCursor = function(t) {
            !v.cursortimeout && v.rail && v.autohidedom && (v.cursortimeout = setTimeout(function() {
                v.rail.active && v.showonmouseevent || (v.autohidedom.stop().animate({
                    opacity: v.opt.cursoropacitymin
                }),
                v.zoom && v.zoom.stop().animate({
                    opacity: v.opt.cursoropacitymin
                }),
                v.cursoractive = !1),
                v.cursortimeout = 0
            }, t || v.opt.hidecursordelay))
        }
        ,
        this.noticeCursor = function(t, e, i) {
            v.showCursor(e, i),
            v.rail.active || v.hideCursor(t)
        }
        ,
        this.getContentSize = v.ispage ? function() {
            return {
                w: Math.max(document.body.scrollWidth, document.documentElement.scrollWidth),
                h: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
            }
        }
        : v.haswrapper ? function() {
            return {
                w: v.doc.outerWidth() + parseInt(v.win.css("paddingLeft")) + parseInt(v.win.css("paddingRight")),
                h: v.doc.outerHeight() + parseInt(v.win.css("paddingTop")) + parseInt(v.win.css("paddingBottom"))
            }
        }
        : function() {
            return {
                w: v.docscroll[0].scrollWidth,
                h: v.docscroll[0].scrollHeight
            }
        }
        ,
        this.onResize = function(t, e) {
            if (!v.win)
                return !1;
            if (!v.haswrapper && !v.ispage) {
                if ("none" == v.win.css("display"))
                    return v.visibility && v.hideRail().hideRailHr(),
                    !1;
                !v.hidden && !v.visibility && v.showRail().showRailHr()
            }
            var i = v.page.maxh
              , o = v.page.maxw
              , r = v.view.w;
            if (v.view = {
                w: v.ispage ? v.win.width() : parseInt(v.win[0].clientWidth),
                h: v.ispage ? v.win.height() : parseInt(v.win[0].clientHeight)
            },
            v.page = e || v.getContentSize(),
            v.page.maxh = Math.max(0, v.page.h - v.view.h),
            v.page.maxw = Math.max(0, v.page.w - v.view.w),
            v.page.maxh == i && v.page.maxw == o && v.view.w == r) {
                if (v.ispage)
                    return v;
                if (i = v.win.offset(),
                v.lastposition && ((o = v.lastposition).top == i.top && o.left == i.left))
                    return v;
                v.lastposition = i
            }
            return 0 == v.page.maxh ? (v.hideRail(),
            v.scrollvaluemax = 0,
            v.scroll.y = 0,
            v.scrollratio.y = 0,
            v.cursorheight = 0,
            v.setScrollTop(0),
            v.rail.scrollable = !1) : v.rail.scrollable = !0,
            0 == v.page.maxw ? (v.hideRailHr(),
            v.scrollvaluemaxw = 0,
            v.scroll.x = 0,
            v.scrollratio.x = 0,
            v.cursorwidth = 0,
            v.setScrollLeft(0),
            v.railh.scrollable = !1) : v.railh.scrollable = !0,
            v.locked = 0 == v.page.maxh && 0 == v.page.maxw,
            v.locked ? (v.ispage || v.updateScrollBar(v.view),
            !1) : (v.hidden || v.visibility ? !v.hidden && !v.railh.visibility && v.showRailHr() : v.showRail().showRailHr(),
            v.istextarea && v.win.css("resize") && "none" != v.win.css("resize") && (v.view.h -= 20),
            v.cursorheight = Math.min(v.view.h, Math.round(v.view.h * (v.view.h / v.page.h))),
            v.cursorheight = v.opt.cursorfixedheight ? v.opt.cursorfixedheight : Math.max(v.opt.cursorminheight, v.cursorheight),
            v.cursorwidth = Math.min(v.view.w, Math.round(v.view.w * (v.view.w / v.page.w))),
            v.cursorwidth = v.opt.cursorfixedheight ? v.opt.cursorfixedheight : Math.max(v.opt.cursorminheight, v.cursorwidth),
            v.scrollvaluemax = v.view.h - v.cursorheight - v.cursor.hborder,
            v.railh && (v.railh.width = 0 < v.page.maxh ? v.view.w - v.rail.width : v.view.w,
            v.scrollvaluemaxw = v.railh.width - v.cursorwidth - v.cursorh.wborder),
            v.checkrtlmode && v.railh && (v.checkrtlmode = !1,
            v.opt.rtlmode && 0 == v.scroll.x && v.setScrollLeft(v.page.maxw)),
            v.ispage || v.updateScrollBar(v.view),
            v.scrollratio = {
                x: v.page.maxw / v.scrollvaluemaxw,
                y: v.page.maxh / v.scrollvaluemax
            },
            v.getScrollTop() > v.page.maxh ? v.doScrollTop(v.page.maxh) : (v.scroll.y = Math.round(v.getScrollTop() * (1 / v.scrollratio.y)),
            v.scroll.x = Math.round(v.getScrollLeft() * (1 / v.scrollratio.x)),
            v.cursoractive && v.noticeCursor()),
            v.scroll.y && 0 == v.getScrollTop() && v.doScrollTo(Math.floor(v.scroll.y * v.scrollratio.y)),
            v)
        }
        ,
        this.resize = v.onResize,
        this.lazyResize = function(t) {
            return t = isNaN(t) ? 30 : t,
            v.delayed("resize", v.resize, t),
            v
        }
        ,
        this._bind = function(t, e, i, o) {
            v.events.push({
                e: t,
                n: e,
                f: i,
                b: o,
                q: !1
            }),
            t.addEventListener ? t.addEventListener(e, i, o || !1) : t.attachEvent ? t.attachEvent("on" + e, i) : t["on" + e] = i
        }
        ,
        this.jqbind = function(e, i, o) {
            v.events.push({
                e: e,
                n: i,
                f: o,
                q: !0
            }),
            t(e).bind(i, o)
        }
        ,
        this.bind = function(t, e, i, o) {
            var r = "jquery"in t ? t[0] : t;
            "mousewheel" == e ? "onwheel"in v.win ? v._bind(r, "wheel", i, o || !1) : (t = void 0 !== document.onmousewheel ? "mousewheel" : "DOMMouseScroll",
            g(r, t, i, o || !1),
            "DOMMouseScroll" == t && g(r, "MozMousePixelScroll", i, o || !1)) : r.addEventListener ? (b.cantouch && /mouseup|mousedown|mousemove/.test(e) && v._bind(r, "mousedown" == e ? "touchstart" : "mouseup" == e ? "touchend" : "touchmove", function(t) {
                if (t.touches) {
                    if (2 > t.touches.length) {
                        var e = t.touches.length ? t.touches[0] : t;
                        e.original = t,
                        i.call(this, e)
                    }
                } else
                    t.changedTouches && ((e = t.changedTouches[0]).original = t,
                    i.call(this, e))
            }, o || !1),
            v._bind(r, e, i, o || !1),
            b.cantouch && "mouseup" == e && v._bind(r, "touchcancel", i, o || !1)) : v._bind(r, e, function(t) {
                return (t = t || window.event || !1) && t.srcElement && (t.target = t.srcElement),
                "pageY"in t || (t.pageX = t.clientX + document.documentElement.scrollLeft,
                t.pageY = t.clientY + document.documentElement.scrollTop),
                !1 !== i.call(r, t) && !1 !== o || v.cancelEvent(t)
            })
        }
        ,
        this._unbind = function(t, e, i, o) {
            t.removeEventListener ? t.removeEventListener(e, i, o) : t.detachEvent ? t.detachEvent("on" + e, i) : t["on" + e] = !1
        }
        ,
        this.unbindAll = function() {
            for (var t = 0; t < v.events.length; t++) {
                var e = v.events[t];
                e.q ? e.e.unbind(e.n, e.f) : v._unbind(e.e, e.n, e.f, e.b)
            }
        }
        ,
        this.cancelEvent = function(t) {
            return !!(t = t.original ? t.original : t || (window.event || !1)) && (t.preventDefault && t.preventDefault(),
            t.stopPropagation && t.stopPropagation(),
            t.preventManipulation && t.preventManipulation(),
            t.cancelBubble = !0,
            t.cancel = !0,
            t.returnValue = !1)
        }
        ,
        this.stopPropagation = function(t) {
            return !!(t = t.original ? t.original : t || (window.event || !1)) && (t.stopPropagation ? t.stopPropagation() : (t.cancelBubble && (t.cancelBubble = !0),
            !1))
        }
        ,
        this.showRail = function() {
            return 0 == v.page.maxh || !v.ispage && "none" == v.win.css("display") || (v.visibility = !0,
            v.rail.visibility = !0,
            v.rail.css("display", "block")),
            v
        }
        ,
        this.showRailHr = function() {
            return v.railh ? (0 == v.page.maxw || !v.ispage && "none" == v.win.css("display") || (v.railh.visibility = !0,
            v.railh.css("display", "block")),
            v) : v
        }
        ,
        this.hideRail = function() {
            return v.visibility = !1,
            v.rail.visibility = !1,
            v.rail.css("display", "none"),
            v
        }
        ,
        this.hideRailHr = function() {
            return v.railh ? (v.railh.visibility = !1,
            v.railh.css("display", "none"),
            v) : v
        }
        ,
        this.show = function() {
            return v.hidden = !1,
            v.locked = !1,
            v.showRail().showRailHr()
        }
        ,
        this.hide = function() {
            return v.hidden = !0,
            v.locked = !0,
            v.hideRail().hideRailHr()
        }
        ,
        this.toggle = function() {
            return v.hidden ? v.show() : v.hide()
        }
        ,
        this.remove = function() {
            v.stop(),
            v.cursortimeout && clearTimeout(v.cursortimeout),
            v.doZoomOut(),
            v.unbindAll(),
            !1 !== v.observer && v.observer.disconnect(),
            !1 !== v.observerremover && v.observerremover.disconnect(),
            v.events = [],
            v.cursor && (v.cursor.remove(),
            v.cursor = null),
            v.cursorh && (v.cursorh.remove(),
            v.cursorh = null),
            v.rail && (v.rail.remove(),
            v.rail = null),
            v.railh && (v.railh.remove(),
            v.railh = null),
            v.zoom && (v.zoom.remove(),
            v.zoom = null);
            for (var t = 0; t < v.saved.css.length; t++) {
                var e = v.saved.css[t];
                e[0].css(e[1], void 0 === e[2] ? "" : e[2])
            }
            return v.saved = !1,
            v.me.data("__nicescroll", ""),
            v.me = null,
            v.doc = null,
            v.docscroll = null,
            v.win = null,
            v
        }
        ,
        this.scrollstart = function(t) {
            return this.onscrollstart = t,
            v
        }
        ,
        this.scrollend = function(t) {
            return this.onscrollend = t,
            v
        }
        ,
        this.scrollcancel = function(t) {
            return this.onscrollcancel = t,
            v
        }
        ,
        this.zoomin = function(t) {
            return this.onzoomin = t,
            v
        }
        ,
        this.zoomout = function(t) {
            return this.onzoomout = t,
            v
        }
        ,
        this.isScrollable = function(e) {
            if ("OPTION" == (e = e.target ? e.target : e).nodeName)
                return !0;
            for (; e && 1 == e.nodeType && !/BODY|HTML/.test(e.nodeName); ) {
                var i = (i = t(e)).css("overflowY") || i.css("overflowX") || i.css("overflow") || "";
                if (/scroll|auto/.test(i))
                    return e.clientHeight != e.scrollHeight;
                e = !!e.parentNode && e.parentNode
            }
            return !1
        }
        ,
        this.getViewport = function(e) {
            for (e = !(!e || !e.parentNode) && e.parentNode; e && 1 == e.nodeType && !/BODY|HTML/.test(e.nodeName); ) {
                var i = t(e)
                  , o = i.css("overflowY") || i.css("overflowX") || i.css("overflow") || "";
                if (/scroll|auto/.test(o) && e.clientHeight != e.scrollHeight || 0 < i.getNiceScroll().length)
                    return i;
                e = !!e.parentNode && e.parentNode
            }
            return !1
        }
        ,
        this.onmousewheel = function(t) {
            if (v.locked)
                return !0;
            if (v.rail.drag)
                return v.cancelEvent(t);
            if (!v.rail.scrollable)
                return !v.railh || !v.railh.scrollable || v.onmousewheelhr(t);
            var e = +new Date
              , i = !1;
            return v.opt.preservenativescrolling && v.checkarea + 600 < e && (v.nativescrollingarea = v.isScrollable(t),
            i = !0),
            v.checkarea = e,
            !!v.nativescrollingarea || ((t = y(t, !1, i)) && (v.checkarea = 0),
            t)
        }
        ,
        this.onmousewheelhr = function(t) {
            if (v.locked || !v.railh.scrollable)
                return !0;
            if (v.rail.drag)
                return v.cancelEvent(t);
            var e = +new Date
              , i = !1;
            return v.opt.preservenativescrolling && v.checkarea + 600 < e && (v.nativescrollingarea = v.isScrollable(t),
            i = !0),
            v.checkarea = e,
            !!v.nativescrollingarea || (v.locked ? v.cancelEvent(t) : y(t, !0, i))
        }
        ,
        this.stop = function() {
            return v.cancelScroll(),
            v.scrollmon && v.scrollmon.stop(),
            v.cursorfreezed = !1,
            v.scroll.y = Math.round(v.getScrollTop() * (1 / v.scrollratio.y)),
            v.noticeCursor(),
            v
        }
        ,
        this.getTransitionSpeed = function(t) {
            var e = Math.round(10 * v.opt.scrollspeed);
            return 20 < (t = Math.min(e, Math.round(t / 20 * v.opt.scrollspeed))) ? t : 0
        }
        ,
        v.opt.smoothscroll ? v.ishwscroll && b.hastransition && v.opt.usetransition ? (this.prepareTransition = function(t, e) {
            var i = e ? 20 < t ? t : 0 : v.getTransitionSpeed(t)
              , o = i ? b.prefixstyle + "transform " + i + "ms ease-out" : "";
            return v.lasttransitionstyle && v.lasttransitionstyle == o || (v.lasttransitionstyle = o,
            v.doc.css(b.transitionstyle, o)),
            i
        }
        ,
        this.doScrollLeft = function(t, e) {
            var i = v.scrollrunning ? v.newscrolly : v.getScrollTop();
            v.doScrollPos(t, i, e)
        }
        ,
        this.doScrollTop = function(t, e) {
            var i = v.scrollrunning ? v.newscrollx : v.getScrollLeft();
            v.doScrollPos(i, t, e)
        }
        ,
        this.doScrollPos = function(t, e, i) {
            var o = v.getScrollTop()
              , r = v.getScrollLeft();
            return (0 > (v.newscrolly - o) * (e - o) || 0 > (v.newscrollx - r) * (t - r)) && v.cancelScroll(),
            0 == v.opt.bouncescroll && (0 > e ? e = 0 : e > v.page.maxh && (e = v.page.maxh),
            0 > t ? t = 0 : t > v.page.maxw && (t = v.page.maxw)),
            (!v.scrollrunning || t != v.newscrollx || e != v.newscrolly) && (v.newscrolly = e,
            v.newscrollx = t,
            v.newscrollspeed = i || !1,
            !v.timer && void (v.timer = setTimeout(function() {
                var i, o, r = v.getScrollTop(), n = v.getScrollLeft();
                i = t - n,
                o = e - r,
                i = Math.round(Math.sqrt(Math.pow(i, 2) + Math.pow(o, 2))),
                i = v.newscrollspeed && 1 < v.newscrollspeed ? v.newscrollspeed : v.getTransitionSpeed(i),
                v.newscrollspeed && 1 >= v.newscrollspeed && (i *= v.newscrollspeed),
                v.prepareTransition(i, !0),
                v.timerscroll && v.timerscroll.tm && clearInterval(v.timerscroll.tm),
                0 < i && (!v.scrollrunning && v.onscrollstart && v.onscrollstart.call(v, {
                    type: "scrollstart",
                    current: {
                        x: n,
                        y: r
                    },
                    request: {
                        x: t,
                        y: e
                    },
                    end: {
                        x: v.newscrollx,
                        y: v.newscrolly
                    },
                    speed: i
                }),
                b.transitionend ? v.scrollendtrapped || (v.scrollendtrapped = !0,
                v.bind(v.doc, b.transitionend, v.onScrollEnd, !1)) : (v.scrollendtrapped && clearTimeout(v.scrollendtrapped),
                v.scrollendtrapped = setTimeout(v.onScrollEnd, i)),
                v.timerscroll = {
                    bz: new BezierClass(r,v.newscrolly,i,0,0,.58,1),
                    bh: new BezierClass(n,v.newscrollx,i,0,0,.58,1)
                },
                v.cursorfreezed || (v.timerscroll.tm = setInterval(function() {
                    v.showCursor(v.getScrollTop(), v.getScrollLeft())
                }, 60))),
                v.synched("doScroll-set", function() {
                    v.timer = 0,
                    v.scrollendtrapped && (v.scrollrunning = !0),
                    v.setScrollTop(v.newscrolly),
                    v.setScrollLeft(v.newscrollx),
                    v.scrollendtrapped || v.onScrollEnd()
                })
            }, 50)))
        }
        ,
        this.cancelScroll = function() {
            if (!v.scrollendtrapped)
                return !0;
            var t = v.getScrollTop()
              , e = v.getScrollLeft();
            return v.scrollrunning = !1,
            b.transitionend || clearTimeout(b.transitionend),
            v.scrollendtrapped = !1,
            v._unbind(v.doc, b.transitionend, v.onScrollEnd),
            v.prepareTransition(0),
            v.setScrollTop(t),
            v.railh && v.setScrollLeft(e),
            v.timerscroll && v.timerscroll.tm && clearInterval(v.timerscroll.tm),
            v.timerscroll = !1,
            v.cursorfreezed = !1,
            v.showCursor(t, e),
            v
        }
        ,
        this.onScrollEnd = function() {
            v.scrollendtrapped && v._unbind(v.doc, b.transitionend, v.onScrollEnd),
            v.scrollendtrapped = !1,
            v.prepareTransition(0),
            v.timerscroll && v.timerscroll.tm && clearInterval(v.timerscroll.tm),
            v.timerscroll = !1;
            var t = v.getScrollTop()
              , e = v.getScrollLeft();
            if (v.setScrollTop(t),
            v.railh && v.setScrollLeft(e),
            v.noticeCursor(!1, t, e),
            v.cursorfreezed = !1,
            0 > t ? t = 0 : t > v.page.maxh && (t = v.page.maxh),
            0 > e ? e = 0 : e > v.page.maxw && (e = v.page.maxw),
            t != v.newscrolly || e != v.newscrollx)
                return v.doScrollPos(e, t, v.opt.snapbackspeed);
            v.onscrollend && v.scrollrunning && v.onscrollend.call(v, {
                type: "scrollend",
                current: {
                    x: e,
                    y: t
                },
                end: {
                    x: v.newscrollx,
                    y: v.newscrolly
                }
            }),
            v.scrollrunning = !1
        }
        ) : (this.doScrollLeft = function(t, e) {
            var i = v.scrollrunning ? v.newscrolly : v.getScrollTop();
            v.doScrollPos(t, i, e)
        }
        ,
        this.doScrollTop = function(t, e) {
            var i = v.scrollrunning ? v.newscrollx : v.getScrollLeft();
            v.doScrollPos(i, t, e)
        }
        ,
        this.doScrollPos = function(t, e, i) {
            if (e = void 0 === e || !1 === e ? v.getScrollTop(!0) : e,
            v.timer && v.newscrolly == e && v.newscrollx == t)
                return !0;
            v.timer && c(v.timer),
            v.timer = 0;
            var o = v.getScrollTop()
              , r = v.getScrollLeft();
            (0 > (v.newscrolly - o) * (e - o) || 0 > (v.newscrollx - r) * (t - r)) && v.cancelScroll(),
            v.newscrolly = e,
            v.newscrollx = t,
            v.bouncescroll && v.rail.visibility || (0 > v.newscrolly ? v.newscrolly = 0 : v.newscrolly > v.page.maxh && (v.newscrolly = v.page.maxh)),
            v.bouncescroll && v.railh.visibility || (0 > v.newscrollx ? v.newscrollx = 0 : v.newscrollx > v.page.maxw && (v.newscrollx = v.page.maxw)),
            v.dst = {},
            v.dst.x = t - r,
            v.dst.y = e - o,
            v.dst.px = r,
            v.dst.py = o;
            var n = Math.round(Math.sqrt(Math.pow(v.dst.x, 2) + Math.pow(v.dst.y, 2)));
            v.dst.ax = v.dst.x / n,
            v.dst.ay = v.dst.y / n;
            var s = 0
              , a = n;
            if (0 == v.dst.x ? (s = o,
            a = e,
            v.dst.ay = 1,
            v.dst.py = 0) : 0 == v.dst.y && (s = r,
            a = t,
            v.dst.ax = 1,
            v.dst.px = 0),
            n = v.getTransitionSpeed(n),
            i && 1 >= i && (n *= i),
            v.bzscroll = 0 < n && (v.bzscroll ? v.bzscroll.update(a, n) : new BezierClass(s,a,n,0,1,0,1)),
            !v.timer) {
                (o == v.page.maxh && e >= v.page.maxh || r == v.page.maxw && t >= v.page.maxw) && v.checkContentSize();
                var u = 1;
                v.cancelAnimationFrame = !1,
                v.timer = 1,
                v.onscrollstart && !v.scrollrunning && v.onscrollstart.call(v, {
                    type: "scrollstart",
                    current: {
                        x: r,
                        y: o
                    },
                    request: {
                        x: t,
                        y: e
                    },
                    end: {
                        x: v.newscrollx,
                        y: v.newscrolly
                    },
                    speed: n
                }),
                function t() {
                    if (v.cancelAnimationFrame)
                        return !0;
                    if (v.scrollrunning = !0,
                    u = 1 - u)
                        return v.timer = l(t) || 1;
                    var e = 0
                      , i = sy = v.getScrollTop();
                    if (v.dst.ay) {
                        var o = (i = v.bzscroll ? v.dst.py + v.bzscroll.getNow() * v.dst.ay : v.newscrolly) - sy;
                        (0 > o && i < v.newscrolly || 0 < o && i > v.newscrolly) && (i = v.newscrolly),
                        v.setScrollTop(i),
                        i == v.newscrolly && (e = 1)
                    } else
                        e = 1;
                    var r = sx = v.getScrollLeft();
                    v.dst.ax ? ((0 > (o = (r = v.bzscroll ? v.dst.px + v.bzscroll.getNow() * v.dst.ax : v.newscrollx) - sx) && r < v.newscrollx || 0 < o && r > v.newscrollx) && (r = v.newscrollx),
                    v.setScrollLeft(r),
                    r == v.newscrollx && (e += 1)) : e += 1,
                    2 == e ? (v.timer = 0,
                    v.cursorfreezed = !1,
                    v.bzscroll = !1,
                    v.scrollrunning = !1,
                    0 > i ? i = 0 : i > v.page.maxh && (i = v.page.maxh),
                    0 > r ? r = 0 : r > v.page.maxw && (r = v.page.maxw),
                    r != v.newscrollx || i != v.newscrolly ? v.doScrollPos(r, i) : v.onscrollend && v.onscrollend.call(v, {
                        type: "scrollend",
                        current: {
                            x: sx,
                            y: sy
                        },
                        end: {
                            x: v.newscrollx,
                            y: v.newscrolly
                        }
                    })) : v.timer = l(t) || 1
                }(),
                (o == v.page.maxh && e >= o || r == v.page.maxw && t >= r) && v.checkContentSize(),
                v.noticeCursor()
            }
        }
        ,
        this.cancelScroll = function() {
            return v.timer && c(v.timer),
            v.timer = 0,
            v.bzscroll = !1,
            v.scrollrunning = !1,
            v
        }
        ) : (this.doScrollLeft = function(t, e) {
            var i = v.getScrollTop();
            v.doScrollPos(t, i, e)
        }
        ,
        this.doScrollTop = function(t, e) {
            var i = v.getScrollLeft();
            v.doScrollPos(i, t, e)
        }
        ,
        this.doScrollPos = function(t, e, i) {
            var o = t > v.page.maxw ? v.page.maxw : t;
            0 > o && (o = 0);
            var r = e > v.page.maxh ? v.page.maxh : e;
            0 > r && (r = 0),
            v.synched("scroll", function() {
                v.setScrollTop(r),
                v.setScrollLeft(o)
            })
        }
        ,
        this.cancelScroll = function() {}
        ),
        this.doScrollBy = function(t, e) {
            var i = 0;
            i = e ? Math.floor((v.scroll.y - t) * v.scrollratio.y) : (v.timer ? v.newscrolly : v.getScrollTop(!0)) - t;
            if (v.bouncescroll) {
                var o = Math.round(v.view.h / 2);
                i < -o ? i = -o : i > v.page.maxh + o && (i = v.page.maxh + o)
            }
            return v.cursorfreezed = !1,
            py = v.getScrollTop(!0),
            0 > i && 0 >= py ? v.noticeCursor() : i > v.page.maxh && py >= v.page.maxh ? (v.checkContentSize(),
            v.noticeCursor()) : void v.doScrollTop(i)
        }
        ,
        this.doScrollLeftBy = function(t, e) {
            var i = 0;
            i = e ? Math.floor((v.scroll.x - t) * v.scrollratio.x) : (v.timer ? v.newscrollx : v.getScrollLeft(!0)) - t;
            if (v.bouncescroll) {
                var o = Math.round(v.view.w / 2);
                i < -o ? i = -o : i > v.page.maxw + o && (i = v.page.maxw + o)
            }
            if (v.cursorfreezed = !1,
            px = v.getScrollLeft(!0),
            0 > i && 0 >= px || i > v.page.maxw && px >= v.page.maxw)
                return v.noticeCursor();
            v.doScrollLeft(i)
        }
        ,
        this.doScrollTo = function(t, e) {
            e && Math.round(t * v.scrollratio.y),
            v.cursorfreezed = !1,
            v.doScrollTop(t)
        }
        ,
        this.checkContentSize = function() {
            var t = v.getContentSize();
            (t.h != v.page.h || t.w != v.page.w) && v.resize(!1, t)
        }
        ,
        v.onscroll = function(t) {
            v.rail.drag || v.cursorfreezed || v.synched("scroll", function() {
                v.scroll.y = Math.round(v.getScrollTop() * (1 / v.scrollratio.y)),
                v.railh && (v.scroll.x = Math.round(v.getScrollLeft() * (1 / v.scrollratio.x))),
                v.noticeCursor()
            })
        }
        ,
        v.bind(v.docscroll, "scroll", v.onscroll),
        this.doZoomIn = function(e) {
            if (!v.zoomactive) {
                v.zoomactive = !0,
                v.zoomrestore = {
                    style: {}
                };
                var i, o = "position top left zIndex backgroundColor marginTop marginBottom marginLeft marginRight".split(" "), r = v.win[0].style;
                for (i in o) {
                    var s = o[i];
                    v.zoomrestore.style[s] = void 0 !== r[s] ? r[s] : ""
                }
                return v.zoomrestore.style.width = v.win.css("width"),
                v.zoomrestore.style.height = v.win.css("height"),
                v.zoomrestore.padding = {
                    w: v.win.outerWidth() - v.win.width(),
                    h: v.win.outerHeight() - v.win.height()
                },
                b.isios4 && (v.zoomrestore.scrollTop = t(window).scrollTop(),
                t(window).scrollTop(0)),
                v.win.css({
                    position: b.isios4 ? "absolute" : "fixed",
                    top: 0,
                    left: 0,
                    "z-index": n + 100,
                    margin: "0px"
                }),
                ("" == (o = v.win.css("backgroundColor")) || /transparent|rgba\(0, 0, 0, 0\)|rgba\(0,0,0,0\)/.test(o)) && v.win.css("backgroundColor", "#fff"),
                v.rail.css({
                    "z-index": n + 101
                }),
                v.zoom.css({
                    "z-index": n + 102
                }),
                v.zoom.css("backgroundPosition", "0px -18px"),
                v.resizeZoom(),
                v.onzoomin && v.onzoomin.call(v),
                v.cancelEvent(e)
            }
        }
        ,
        this.doZoomOut = function(e) {
            if (v.zoomactive)
                return v.zoomactive = !1,
                v.win.css("margin", ""),
                v.win.css(v.zoomrestore.style),
                b.isios4 && t(window).scrollTop(v.zoomrestore.scrollTop),
                v.rail.css({
                    "z-index": v.zindex
                }),
                v.zoom.css({
                    "z-index": v.zindex
                }),
                v.zoomrestore = !1,
                v.zoom.css("backgroundPosition", "0px 0px"),
                v.onResize(),
                v.onzoomout && v.onzoomout.call(v),
                v.cancelEvent(e)
        }
        ,
        this.doZoom = function(t) {
            return v.zoomactive ? v.doZoomOut(t) : v.doZoomIn(t)
        }
        ,
        this.resizeZoom = function() {
            if (v.zoomactive) {
                var e = v.getScrollTop();
                v.win.css({
                    width: t(window).width() - v.zoomrestore.padding.w + "px",
                    height: t(window).height() - v.zoomrestore.padding.h + "px"
                }),
                v.onResize(),
                v.setScrollTop(Math.min(v.page.maxh, e))
            }
        }
        ,
        this.init(),
        t.nicescroll.push(this)
    }
      , m = function(t) {
        var e = this;
        this.nc = t,
        this.steptime = this.lasttime = this.speedy = this.speedx = this.lasty = this.lastx = 0,
        this.snapy = this.snapx = !1,
        this.demuly = this.demulx = 0,
        this.lastscrolly = this.lastscrollx = -1,
        this.timer = this.chky = this.chkx = 0,
        this.time = function() {
            return +new Date
        }
        ,
        this.reset = function(t, i) {
            e.stop();
            var o = e.time();
            e.steptime = 0,
            e.lasttime = o,
            e.speedx = 0,
            e.speedy = 0,
            e.lastx = t,
            e.lasty = i,
            e.lastscrollx = -1,
            e.lastscrolly = -1
        }
        ,
        this.update = function(t, i) {
            var o = e.time();
            e.steptime = o - e.lasttime,
            e.lasttime = o;
            o = i - e.lasty;
            var r = t - e.lastx
              , n = (n = e.nc.getScrollTop()) + o
              , s = (s = e.nc.getScrollLeft()) + r;
            e.snapx = 0 > s || s > e.nc.page.maxw,
            e.snapy = 0 > n || n > e.nc.page.maxh,
            e.speedx = r,
            e.speedy = o,
            e.lastx = t,
            e.lasty = i
        }
        ,
        this.stop = function() {
            e.nc.unsynched("domomentum2d"),
            e.timer && clearTimeout(e.timer),
            e.timer = 0,
            e.lastscrollx = -1,
            e.lastscrolly = -1
        }
        ,
        this.doSnapy = function(t, i) {
            var o = !1;
            0 > i ? (i = 0,
            o = !0) : i > e.nc.page.maxh && (i = e.nc.page.maxh,
            o = !0),
            0 > t ? (t = 0,
            o = !0) : t > e.nc.page.maxw && (t = e.nc.page.maxw,
            o = !0),
            o && e.nc.doScrollPos(t, i, e.nc.opt.snapbackspeed)
        }
        ,
        this.doMomentum = function(t) {
            var i = e.time()
              , o = t ? i + t : e.lasttime;
            t = e.nc.getScrollLeft();
            var r = e.nc.getScrollTop()
              , n = e.nc.page.maxh
              , s = e.nc.page.maxw;
            if (e.speedx = 0 < s ? Math.min(60, e.speedx) : 0,
            e.speedy = 0 < n ? Math.min(60, e.speedy) : 0,
            o = o && 50 >= i - o,
            (0 > r || r > n || 0 > t || t > s) && (o = !1),
            t = !(!e.speedx || !o) && e.speedx,
            e.speedy && o && e.speedy || t) {
                var a = Math.max(16, e.steptime);
                50 < a && (t = a / 50,
                e.speedx *= t,
                e.speedy *= t,
                a = 50),
                e.demulxy = 0,
                e.lastscrollx = e.nc.getScrollLeft(),
                e.chkx = e.lastscrollx,
                e.lastscrolly = e.nc.getScrollTop(),
                e.chky = e.lastscrolly;
                var l = e.lastscrollx
                  , c = e.lastscrolly
                  , u = function() {
                    var t = 600 < e.time() - i ? .04 : .02;
                    e.speedx && (l = Math.floor(e.lastscrollx - e.speedx * (1 - e.demulxy)),
                    e.lastscrollx = l,
                    0 > l || l > s) && (t = .1),
                    e.speedy && (c = Math.floor(e.lastscrolly - e.speedy * (1 - e.demulxy)),
                    e.lastscrolly = c,
                    0 > c || c > n) && (t = .1),
                    e.demulxy = Math.min(1, e.demulxy + t),
                    e.nc.synched("domomentum2d", function() {
                        e.speedx && (e.nc.getScrollLeft() != e.chkx && e.stop(),
                        e.chkx = l,
                        e.nc.setScrollLeft(l)),
                        e.speedy && (e.nc.getScrollTop() != e.chky && e.stop(),
                        e.chky = c,
                        e.nc.setScrollTop(c)),
                        e.timer || (e.nc.hideCursor(),
                        e.doSnapy(l, c))
                    }),
                    1 > e.demulxy ? e.timer = setTimeout(u, a) : (e.stop(),
                    e.nc.hideCursor(),
                    e.doSnapy(l, c))
                };
                u()
            } else
                e.doSnapy(e.nc.getScrollLeft(), e.nc.getScrollTop())
        }
    }
      , f = t.fn.scrollTop;
    t.cssHooks.pageYOffset = {
        get: function(e, i, o) {
            return (i = t.data(e, "__nicescroll") || !1) && i.ishwscroll ? i.getScrollTop() : f.call(e)
        },
        set: function(e, i) {
            var o = t.data(e, "__nicescroll") || !1;
            return o && o.ishwscroll ? o.setScrollTop(parseInt(i)) : f.call(e, i),
            this
        }
    },
    t.fn.scrollTop = function(e) {
        if (void 0 === e) {
            var i = this[0] && t.data(this[0], "__nicescroll") || !1;
            return i && i.ishwscroll ? i.getScrollTop() : f.call(this)
        }
        return this.each(function() {
            var i = t.data(this, "__nicescroll") || !1;
            i && i.ishwscroll ? i.setScrollTop(parseInt(e)) : f.call(t(this), e)
        })
    }
    ;
    var g = t.fn.scrollLeft;
    t.cssHooks.pageXOffset = {
        get: function(e, i, o) {
            return (i = t.data(e, "__nicescroll") || !1) && i.ishwscroll ? i.getScrollLeft() : g.call(e)
        },
        set: function(e, i) {
            var o = t.data(e, "__nicescroll") || !1;
            return o && o.ishwscroll ? o.setScrollLeft(parseInt(i)) : g.call(e, i),
            this
        }
    },
    t.fn.scrollLeft = function(e) {
        if (void 0 === e) {
            var i = this[0] && t.data(this[0], "__nicescroll") || !1;
            return i && i.ishwscroll ? i.getScrollLeft() : g.call(this)
        }
        return this.each(function() {
            var i = t.data(this, "__nicescroll") || !1;
            i && i.ishwscroll ? i.setScrollLeft(parseInt(e)) : g.call(t(this), e)
        })
    }
    ;
    var y = function(e) {
        var i = this;
        if (this.length = 0,
        this.name = "nicescrollarray",
        this.each = function(t) {
            for (var e = 0; e < i.length; e++)
                t.call(i[e]);
            return i
        }
        ,
        this.push = function(t) {
            i[i.length] = t,
            i.length++
        }
        ,
        this.eq = function(t) {
            return i[t]
        }
        ,
        e)
            for (a = 0; a < e.length; a++) {
                var o = t.data(e[a], "__nicescroll") || !1;
                o && (this[this.length] = o,
                this.length++)
            }
        return this
    };
    !function(t, e, i) {
        for (var o = 0; o < e.length; o++)
            i(t, e[o])
    }(y.prototype, "show hide toggle onResize resize remove stop doScrollPos".split(" "), function(t, e) {
        t[e] = function() {
            var t = arguments;
            return this.each(function() {
                this[e].apply(this, t)
            })
        }
    }),
    t.fn.getNiceScroll = function(e) {
        return void 0 === e ? new y(this) : t.data(this[e], "__nicescroll") || !1
    }
    ,
    t.extend(t.expr[":"], {
        nicescroll: function(e) {
            return !!t.data(e, "__nicescroll")
        }
    }),
    t.fn.niceScroll = function(e, i) {
        void 0 === i && "object" == typeof e && !("jquery"in e) && (i = e,
        e = !1);
        var o = new y;
        void 0 === i && (i = {}),
        e && (i.doc = t(e),
        i.win = t(this));
        var r = !("doc"in i);
        return !r && !("win"in i) && (i.win = t(this)),
        this.each(function() {
            var e = t(this).data("__nicescroll") || !1;
            e || (i.doc = r ? t(this) : i.doc,
            e = new p(i,t(this)),
            t(this).data("__nicescroll", e)),
            o.push(e)
        }),
        1 == o.length ? o[0] : o
    }
    ,
    window.NiceScroll = {
        getjQuery: function() {
            return t
        }
    },
    t.nicescroll || (t.nicescroll = new y,
    t.nicescroll.options = h)
}(jQuery),
function(t, e, i) {
    "use strict";
    var o = {
        relativeInput: !1,
        clipRelativeInput: !1,
        calibrationThreshold: 100,
        calibrationDelay: 500,
        supportDelay: 500,
        calibrateX: !1,
        calibrateY: !0,
        invertX: !0,
        invertY: !0,
        limitX: !1,
        limitY: !1,
        scalarX: 10,
        scalarY: 10,
        frictionX: .1,
        frictionY: .1,
        originX: .5,
        originY: .5
    };
    function r(t, e) {
        this.element = t,
        this.layers = t.getElementsByClassName("layer");
        var i = {
            calibrateX: this.data(this.element, "calibrate-x"),
            calibrateY: this.data(this.element, "calibrate-y"),
            invertX: this.data(this.element, "invert-x"),
            invertY: this.data(this.element, "invert-y"),
            limitX: this.data(this.element, "limit-x"),
            limitY: this.data(this.element, "limit-y"),
            scalarX: this.data(this.element, "scalar-x"),
            scalarY: this.data(this.element, "scalar-y"),
            frictionX: this.data(this.element, "friction-x"),
            frictionY: this.data(this.element, "friction-y"),
            originX: this.data(this.element, "origin-x"),
            originY: this.data(this.element, "origin-y")
        };
        for (var r in i)
            null === i[r] && delete i[r];
        this.extend(this, o, e, i),
        this.calibrationTimer = null,
        this.calibrationFlag = !0,
        this.enabled = !1,
        this.depths = [],
        this.raf = null,
        this.bounds = null,
        this.ex = 0,
        this.ey = 0,
        this.ew = 0,
        this.eh = 0,
        this.ecx = 0,
        this.ecy = 0,
        this.erx = 0,
        this.ery = 0,
        this.cx = 0,
        this.cy = 0,
        this.ix = 0,
        this.iy = 0,
        this.mx = 0,
        this.my = 0,
        this.vx = 0,
        this.vy = 0,
        this.onMouseMove = this.onMouseMove.bind(this),
        this.onDeviceOrientation = this.onDeviceOrientation.bind(this),
        this.onOrientationTimer = this.onOrientationTimer.bind(this),
        this.onCalibrationTimer = this.onCalibrationTimer.bind(this),
        this.onAnimationFrame = this.onAnimationFrame.bind(this),
        this.onWindowResize = this.onWindowResize.bind(this),
        this.initialise()
    }
    r.prototype.extend = function() {
        if (arguments.length > 1)
            for (var t = arguments[0], e = 1, i = arguments.length; e < i; e++) {
                var o = arguments[e];
                for (var r in o)
                    t[r] = o[r]
            }
    }
    ,
    r.prototype.data = function(t, e) {
        return this.deserialize(t.getAttribute("data-" + e))
    }
    ,
    r.prototype.deserialize = function(t) {
        return "true" === t || "false" !== t && ("null" === t ? null : !isNaN(parseFloat(t)) && isFinite(t) ? parseFloat(t) : t)
    }
    ,
    r.prototype.camelCase = function(t) {
        return t.replace(/-+(.)?/g, function(t, e) {
            return e ? e.toUpperCase() : ""
        })
    }
    ,
    r.prototype.transformSupport = function(i) {
        for (var o = e.createElement("div"), r = !1, n = null, s = !1, a = null, l = null, c = 0, u = this.vendors.length; c < u; c++)
            if (null !== this.vendors[c] ? (a = this.vendors[c][0] + "transform",
            l = this.vendors[c][1] + "Transform") : (a = "transform",
            l = "transform"),
            void 0 !== o.style[l]) {
                r = !0;
                break
            }
        switch (i) {
        case "2D":
            s = r;
            break;
        case "3D":
            if (r) {
                var h = e.body || e.createElement("body")
                  , d = e.documentElement
                  , p = d.style.overflow;
                e.body || (d.style.overflow = "hidden",
                d.appendChild(h),
                h.style.overflow = "hidden",
                h.style.background = ""),
                h.appendChild(o),
                o.style[l] = "translate3d(1px,1px,1px)",
                s = void 0 !== (n = t.getComputedStyle(o).getPropertyValue(a)) && n.length > 0 && "none" !== n,
                d.style.overflow = p,
                h.removeChild(o)
            }
        }
        return s
    }
    ,
    r.prototype.ww = null,
    r.prototype.wh = null,
    r.prototype.wcx = null,
    r.prototype.wcy = null,
    r.prototype.wrx = null,
    r.prototype.wry = null,
    r.prototype.portrait = null,
    r.prototype.desktop = !navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|BB10|mobi|tablet|opera mini|nexus 7)/i),
    r.prototype.vendors = [null, ["-webkit-", "webkit"], ["-moz-", "Moz"], ["-o-", "O"], ["-ms-", "ms"]],
    r.prototype.motionSupport = !!t.DeviceMotionEvent,
    r.prototype.orientationSupport = !!t.DeviceOrientationEvent,
    r.prototype.orientationStatus = 0,
    r.prototype.transform2DSupport = r.prototype.transformSupport("2D"),
    r.prototype.transform3DSupport = r.prototype.transformSupport("3D"),
    r.prototype.propertyCache = {},
    r.prototype.initialise = function() {
        this.transform3DSupport && this.accelerate(this.element),
        "static" === t.getComputedStyle(this.element).getPropertyValue("position") && (this.element.style.position = "relative"),
        this.updateLayers(),
        this.updateDimensions(),
        this.enable(),
        this.queueCalibration(this.calibrationDelay)
    }
    ,
    r.prototype.updateLayers = function() {
        this.layers = this.element.getElementsByClassName("layer"),
        this.depths = [];
        for (var t = 0, e = this.layers.length; t < e; t++) {
            var i = this.layers[t];
            this.transform3DSupport && this.accelerate(i),
            i.style.position = t ? "absolute" : "relative",
            i.style.display = "block",
            i.style.left = 0,
            i.style.top = 0,
            this.depths.push(this.data(i, "depth") || 0)
        }
    }
    ,
    r.prototype.updateDimensions = function() {
        this.ww = t.innerWidth,
        this.wh = t.innerHeight,
        this.wcx = this.ww * this.originX,
        this.wcy = this.wh * this.originY,
        this.wrx = Math.max(this.wcx, this.ww - this.wcx),
        this.wry = Math.max(this.wcy, this.wh - this.wcy)
    }
    ,
    r.prototype.updateBounds = function() {
        this.bounds = this.element.getBoundingClientRect(),
        this.ex = this.bounds.left,
        this.ey = this.bounds.top,
        this.ew = this.bounds.width,
        this.eh = this.bounds.height,
        this.ecx = this.ew * this.originX,
        this.ecy = this.eh * this.originY,
        this.erx = Math.max(this.ecx, this.ew - this.ecx),
        this.ery = Math.max(this.ecy, this.eh - this.ecy)
    }
    ,
    r.prototype.queueCalibration = function(t) {
        clearTimeout(this.calibrationTimer),
        this.calibrationTimer = setTimeout(this.onCalibrationTimer, t)
    }
    ,
    r.prototype.enable = function() {
        this.enabled || (this.enabled = !0,
        this.orientationSupport ? (this.portrait = null,
        setTimeout(this.onOrientationTimer, this.supportDelay)) : (this.cx = 0,
        this.cy = 0,
        this.portrait = !1,
        t.addEventListener("mousemove", this.onMouseMove)),
        t.addEventListener("resize", this.onWindowResize),
        this.raf = requestAnimationFrame(this.onAnimationFrame))
    }
    ,
    r.prototype.disable = function() {
        this.enabled && (this.enabled = !1,
        this.orientationSupport ? t.removeEventListener("deviceorientation", this.onDeviceOrientation) : t.removeEventListener("mousemove", this.onMouseMove),
        t.removeEventListener("resize", this.onWindowResize),
        cancelAnimationFrame(this.raf))
    }
    ,
    r.prototype.calibrate = function(t, e) {
        this.calibrateX = void 0 === t ? this.calibrateX : t,
        this.calibrateY = void 0 === e ? this.calibrateY : e
    }
    ,
    r.prototype.invert = function(t, e) {
        this.invertX = void 0 === t ? this.invertX : t,
        this.invertY = void 0 === e ? this.invertY : e
    }
    ,
    r.prototype.friction = function(t, e) {
        this.frictionX = void 0 === t ? this.frictionX : t,
        this.frictionY = void 0 === e ? this.frictionY : e
    }
    ,
    r.prototype.scalar = function(t, e) {
        this.scalarX = void 0 === t ? this.scalarX : t,
        this.scalarY = void 0 === e ? this.scalarY : e
    }
    ,
    r.prototype.limit = function(t, e) {
        this.limitX = void 0 === t ? this.limitX : t,
        this.limitY = void 0 === e ? this.limitY : e
    }
    ,
    r.prototype.origin = function(t, e) {
        this.originX = void 0 === t ? this.originX : t,
        this.originY = void 0 === e ? this.originY : e
    }
    ,
    r.prototype.clamp = function(t, e, i) {
        return t = Math.max(t, e),
        t = Math.min(t, i)
    }
    ,
    r.prototype.css = function(t, e, i) {
        var o = this.propertyCache[e];
        if (!o)
            for (var r = 0, n = this.vendors.length; r < n; r++)
                if (o = null !== this.vendors[r] ? this.camelCase(this.vendors[r][1] + "-" + e) : e,
                void 0 !== t.style[o]) {
                    this.propertyCache[e] = o;
                    break
                }
        t.style[o] = i
    }
    ,
    r.prototype.accelerate = function(t) {
        this.css(t, "transform", "translate3d(0,0,0)"),
        this.css(t, "transform-style", "preserve-3d"),
        this.css(t, "backface-visibility", "hidden")
    }
    ,
    r.prototype.setPosition = function(t, e, i) {
        e += "px",
        i += "px",
        this.transform3DSupport ? this.css(t, "transform", "translate3d(" + e + "," + i + ",0)") : this.transform2DSupport ? this.css(t, "transform", "translate(" + e + "," + i + ")") : (t.style.left = e,
        t.style.top = i)
    }
    ,
    r.prototype.onOrientationTimer = function(t) {
        this.orientationSupport && 0 === this.orientationStatus && (this.disable(),
        this.orientationSupport = !1,
        this.enable())
    }
    ,
    r.prototype.onCalibrationTimer = function(t) {
        this.calibrationFlag = !0
    }
    ,
    r.prototype.onWindowResize = function(t) {
        this.updateDimensions()
    }
    ,
    r.prototype.onAnimationFrame = function() {
        this.updateBounds();
        var t = this.ix - this.cx
          , e = this.iy - this.cy;
        (Math.abs(t) > this.calibrationThreshold || Math.abs(e) > this.calibrationThreshold) && this.queueCalibration(0),
        this.portrait ? (this.mx = this.calibrateX ? e : this.iy,
        this.my = this.calibrateY ? t : this.ix) : (this.mx = this.calibrateX ? t : this.ix,
        this.my = this.calibrateY ? e : this.iy),
        this.mx *= this.ew * (this.scalarX / 100),
        this.my *= this.eh * (this.scalarY / 100),
        isNaN(parseFloat(this.limitX)) || (this.mx = this.clamp(this.mx, -this.limitX, this.limitX)),
        isNaN(parseFloat(this.limitY)) || (this.my = this.clamp(this.my, -this.limitY, this.limitY)),
        this.vx += (this.mx - this.vx) * this.frictionX,
        this.vy += (this.my - this.vy) * this.frictionY;
        for (var i = 0, o = this.layers.length; i < o; i++) {
            var r = this.layers[i]
              , n = this.depths[i]
              , s = this.vx * n * (this.invertX ? -1 : 1)
              , a = this.vy * n * (this.invertY ? -1 : 1);
            this.setPosition(r, s, a)
        }
        this.raf = requestAnimationFrame(this.onAnimationFrame)
    }
    ,
    r.prototype.onDeviceOrientation = function(t) {
        if (!this.desktop && null !== t.beta && null !== t.gamma) {
            this.orientationStatus = 1;
            var e = (t.beta || 0) / 30
              , i = (t.gamma || 0) / 30
              , o = this.wh > this.ww;
            this.portrait !== o && (this.portrait = o,
            this.calibrationFlag = !0),
            this.calibrationFlag && (this.calibrationFlag = !1,
            this.cx = e,
            this.cy = i),
            this.ix = e,
            this.iy = i
        }
    }
    ,
    r.prototype.onMouseMove = function(t) {
        var e = t.clientX
          , i = t.clientY;
        !this.orientationSupport && this.relativeInput ? (this.clipRelativeInput && (e = Math.max(e, this.ex),
        e = Math.min(e, this.ex + this.ew),
        i = Math.max(i, this.ey),
        i = Math.min(i, this.ey + this.eh)),
        this.ix = (e - this.ex - this.ecx) / this.erx,
        this.iy = (i - this.ey - this.ecy) / this.ery) : (this.ix = (e - this.wcx) / this.wrx,
        this.iy = (i - this.wcy) / this.wry)
    }
    ,
    t.Parallax = r
}(window, document),
function() {
    for (var t = 0, e = ["ms", "moz", "webkit", "o"], i = 0; i < e.length && !window.requestAnimationFrame; ++i)
        window.requestAnimationFrame = window[e[i] + "RequestAnimationFrame"],
        window.cancelAnimationFrame = window[e[i] + "CancelAnimationFrame"] || window[e[i] + "CancelRequestAnimationFrame"];
    window.requestAnimationFrame || (window.requestAnimationFrame = function(e, i) {
        var o = (new Date).getTime()
          , r = Math.max(0, 16 - (o - t))
          , n = window.setTimeout(function() {
            e(o + r)
        }, r);
        return t = o + r,
        n
    }
    ),
    window.cancelAnimationFrame || (window.cancelAnimationFrame = function(t) {
        clearTimeout(t)
    }
    )
}(),
function(t) {
    "use strict";
    function e() {
        r = t.innerWidth || document.documentElement.clientWidth,
        n = t.innerHeight || document.documentElement.clientHeight
    }
    function i(t, e, i) {
        t.addEventListener ? t.addEventListener(e, i) : t.attachEvent("on" + e, function() {
            i.call(t)
        })
    }
    function o(i) {
        t.requestAnimationFrame(function() {
            "scroll" !== i.type && e();
            for (var t = 0, o = m.length; o > t; t++)
                "scroll" !== i.type && (m[t].coverImage(),
                m[t].clipContainer()),
                m[t].onScroll()
        })
    }
    Date.now || (Date.now = function() {
        return (new Date).getTime()
    }
    ),
    t.requestAnimationFrame || function() {
        for (var e = ["webkit", "moz"], i = 0; i < e.length && !t.requestAnimationFrame; ++i) {
            var o = e[i];
            t.requestAnimationFrame = t[o + "RequestAnimationFrame"],
            t.cancelAnimationFrame = t[o + "CancelAnimationFrame"] || t[o + "CancelRequestAnimationFrame"]
        }
        if (/iP(ad|hone|od).*OS 6/.test(t.navigator.userAgent) || !t.requestAnimationFrame || !t.cancelAnimationFrame) {
            var r = 0;
            t.requestAnimationFrame = function(t) {
                var e = Date.now()
                  , i = Math.max(r + 16, e);
                return setTimeout(function() {
                    t(r = i)
                }, i - e)
            }
            ,
            t.cancelAnimationFrame = clearTimeout
        }
    }();
    var r, n, s = function() {
        if (!t.getComputedStyle)
            return !1;
        var e, i = document.createElement("p"), o = {
            webkitTransform: "-webkit-transform",
            OTransform: "-o-transform",
            msTransform: "-ms-transform",
            MozTransform: "-moz-transform",
            transform: "transform"
        };
        for (var r in (document.body || document.documentElement).insertBefore(i, null),
        o)
            void 0 !== i.style[r] && (i.style[r] = "translate3d(1px,1px,1px)",
            e = t.getComputedStyle(i).getPropertyValue(o[r]));
        return (document.body || document.documentElement).removeChild(i),
        void 0 !== e && e.length > 0 && "none" !== e
    }(), a = navigator.userAgent.toLowerCase().indexOf("android") > -1, l = /iPad|iPhone|iPod/.test(navigator.userAgent) && !t.MSStream, c = !!t.opera, u = /Edge\/\d+/.test(navigator.userAgent), h = /Trident.*rv[ :]*11\./.test(navigator.userAgent), d = !!Function("/*@cc_on return document.documentMode===10@*/")(), p = document.all && !t.atob;
    e();
    var m = []
      , f = function() {
        var t = 0;
        return function(e, i) {
            var o, r = this;
            if (r.$item = e,
            r.defaults = {
                type: "scroll",
                speed: .5,
                imgSrc: null,
                imgWidth: null,
                imgHeight: null,
                enableTransform: !0,
                elementInViewport: null,
                zIndex: -100,
                noAndroid: !1,
                noIos: !0,
                onScroll: null,
                onInit: null,
                onDestroy: null,
                onCoverImage: null
            },
            o = JSON.parse(r.$item.getAttribute("data-jarallax") || "{}"),
            r.options = r.extend({}, r.defaults, o, i),
            !(a && r.options.noAndroid || l && r.options.noIos)) {
                r.options.speed = Math.min(2, Math.max(-1, parseFloat(r.options.speed)));
                var n = r.options.elementInViewport;
                n && "object" == typeof n && void 0 !== n.length && (n = n[0]),
                !n instanceof Element && (n = null),
                r.options.elementInViewport = n,
                r.instanceID = t++,
                r.image = {
                    src: r.options.imgSrc || null,
                    $container: null,
                    $item: null,
                    width: r.options.imgWidth || null,
                    height: r.options.imgHeight || null,
                    useImgTag: l || a || c || h || d || u
                },
                r.initImg() && r.init()
            }
        }
    }();
    f.prototype.css = function(e, i) {
        if ("string" == typeof i)
            return t.getComputedStyle ? t.getComputedStyle(e).getPropertyValue(i) : e.style[i];
        for (var o in i.transform && (i.WebkitTransform = i.MozTransform = i.transform),
        i)
            e.style[o] = i[o];
        return e
    }
    ,
    f.prototype.extend = function(t) {
        t = t || {};
        for (var e = 1; e < arguments.length; e++)
            if (arguments[e])
                for (var i in arguments[e])
                    arguments[e].hasOwnProperty(i) && (t[i] = arguments[e][i]);
        return t
    }
    ,
    f.prototype.initImg = function() {
        var t = this;
        return null === t.image.src && (t.image.src = t.css(t.$item, "background-image").replace(/^url\(['"]?/g, "").replace(/['"]?\)$/g, "")),
        !(!t.image.src || "none" === t.image.src)
    }
    ,
    f.prototype.init = function() {
        function t() {
            e.coverImage(),
            e.clipContainer(),
            e.onScroll(!0),
            e.options.onInit && e.options.onInit.call(e),
            setTimeout(function() {
                e.$item && e.css(e.$item, {
                    "background-image": "none",
                    "background-attachment": "scroll",
                    "background-size": "auto"
                })
            }, 0)
        }
        var e = this
          , i = {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
            pointerEvents: "none"
        }
          , o = {
            position: "fixed"
        };
        e.$item.setAttribute("data-jarallax-original-styles", e.$item.getAttribute("style")),
        "static" === e.css(e.$item, "position") && e.css(e.$item, {
            position: "relative"
        }),
        "auto" === e.css(e.$item, "z-index") && e.css(e.$item, {
            zIndex: 0
        }),
        e.image.$container = document.createElement("div"),
        e.css(e.image.$container, i),
        e.css(e.image.$container, {
            visibility: "hidden",
            "z-index": e.options.zIndex
        }),
        e.image.$container.setAttribute("id", "jarallax-container-" + e.instanceID),
        e.$item.appendChild(e.image.$container),
        e.image.useImgTag && s && e.options.enableTransform ? (e.image.$item = document.createElement("img"),
        e.image.$item.setAttribute("src", e.image.src),
        o = e.extend({
            "max-width": "none"
        }, i, o)) : (e.image.$item = document.createElement("div"),
        o = e.extend({
            "background-position": "50% 50%",
            "background-size": "100% auto",
            "background-repeat": "no-repeat no-repeat",
            "background-image": 'url("' + e.image.src + '")'
        }, i, o)),
        p && (o.backgroundAttachment = "fixed"),
        e.parentWithTransform = 0;
        for (var r = e.$item; null !== r && r !== document && 0 === e.parentWithTransform; ) {
            var n = e.css(r, "-webkit-transform") || e.css(r, "-moz-transform") || e.css(r, "transform");
            n && "none" !== n && (e.parentWithTransform = 1,
            e.css(e.image.$container, {
                transform: "translateX(0) translateY(0)"
            })),
            r = r.parentNode
        }
        e.css(e.image.$item, o),
        e.image.$container.appendChild(e.image.$item),
        e.image.width && e.image.height ? t() : e.getImageSize(e.image.src, function(i, o) {
            e.image.width = i,
            e.image.height = o,
            t()
        }),
        m.push(e)
    }
    ,
    f.prototype.destroy = function() {
        for (var t = this, e = 0, i = m.length; i > e; e++)
            if (m[e].instanceID === t.instanceID) {
                m.splice(e, 1);
                break
            }
        var o = t.$item.getAttribute("data-jarallax-original-styles");
        for (var r in t.$item.removeAttribute("data-jarallax-original-styles"),
        "null" === o ? t.$item.removeAttribute("style") : t.$item.setAttribute("style", o),
        t.$clipStyles && t.$clipStyles.parentNode.removeChild(t.$clipStyles),
        t.image.$container.parentNode.removeChild(t.image.$container),
        t.options.onDestroy && t.options.onDestroy.call(t),
        delete t.$item.jarallax,
        t)
            delete t[r]
    }
    ,
    f.prototype.getImageSize = function(t, e) {
        if (t && e) {
            var i = new Image;
            i.onload = function() {
                e(i.width, i.height)
            }
            ,
            i.src = t
        }
    }
    ,
    f.prototype.clipContainer = function() {
        if (!p) {
            var t = this
              , e = t.image.$container.getBoundingClientRect()
              , i = e.width
              , o = e.height;
            if (!t.$clipStyles)
                t.$clipStyles = document.createElement("style"),
                t.$clipStyles.setAttribute("type", "text/css"),
                t.$clipStyles.setAttribute("id", "#jarallax-clip-" + t.instanceID),
                (document.head || document.getElementsByTagName("head")[0]).appendChild(t.$clipStyles);
            var r = ["#jarallax-container-" + t.instanceID + " {", "   clip: rect(0 " + i + "px " + o + "px 0);", "   clip: rect(0, " + i + "px, " + o + "px, 0);", "}"].join("\n");
            t.$clipStyles.styleSheet ? t.$clipStyles.styleSheet.cssText = r : t.$clipStyles.innerHTML = r
        }
    }
    ,
    f.prototype.coverImage = function() {
        var t = this;
        if (t.image.width && t.image.height) {
            var e = t.image.$container.getBoundingClientRect()
              , i = e.width
              , o = e.height
              , r = e.left
              , a = t.image.width
              , l = t.image.height
              , c = t.options.speed
              , u = "scroll" === t.options.type || "scroll-opacity" === t.options.type
              , h = 0
              , d = 0
              , p = o
              , m = 0
              , f = 0;
            u && (h = 0 > c ? c * Math.max(o, n) : c * (o + n),
            c > 1 ? p = Math.abs(h - n) : 0 > c ? p = h / c + Math.abs(h) : p += Math.abs(n - o) * (1 - c),
            h /= 2),
            i > (d = p * a / l) && (p = (d = i) * l / a),
            t.bgPosVerticalCenter = 0,
            !(u && n > p) || s && t.options.enableTransform || (t.bgPosVerticalCenter = (n - p) / 2,
            p = n),
            u ? (m = r + (i - d) / 2,
            f = (n - p) / 2) : (m = (i - d) / 2,
            f = (o - p) / 2),
            s && t.options.enableTransform && t.parentWithTransform && (m -= r),
            t.parallaxScrollDistance = h,
            t.css(t.image.$item, {
                width: d + "px",
                height: p + "px",
                marginLeft: m + "px",
                marginTop: f + "px"
            }),
            t.options.onCoverImage && t.options.onCoverImage.call(t)
        }
    }
    ,
    f.prototype.isVisible = function() {
        return this.isElementInViewport || !1
    }
    ,
    f.prototype.onScroll = function(t) {
        var e = this;
        if (e.image.width && e.image.height) {
            var i = e.$item.getBoundingClientRect()
              , o = i.top
              , a = i.height
              , l = {
                position: "absolute",
                visibility: "visible",
                backgroundPosition: "50% 50%"
            }
              , c = i;
            if (e.options.elementInViewport && (c = e.options.elementInViewport.getBoundingClientRect()),
            e.isElementInViewport = c.bottom >= 0 && c.right >= 0 && c.top <= n && c.left <= r,
            t || e.isElementInViewport) {
                var u = Math.max(0, o)
                  , h = Math.max(0, a + o)
                  , d = Math.max(0, -o)
                  , m = Math.max(0, o + a - n)
                  , f = Math.max(0, a - (o + a - n))
                  , g = Math.max(0, -o + n - a)
                  , y = 1 - 2 * (n - o) / (n + a)
                  , v = 1;
                if (n > a ? v = 1 - (d || m) / a : n >= h ? v = h / n : n >= f && (v = f / n),
                ("opacity" === e.options.type || "scale-opacity" === e.options.type || "scroll-opacity" === e.options.type) && (l.transform = "translate3d(0, 0, 0)",
                l.opacity = v),
                "scale" === e.options.type || "scale-opacity" === e.options.type) {
                    var w = 1;
                    e.options.speed < 0 ? w -= e.options.speed * v : w += e.options.speed * (1 - v),
                    l.transform = "scale(" + w + ") translate3d(0, 0, 0)"
                }
                if ("scroll" === e.options.type || "scroll-opacity" === e.options.type) {
                    var b = e.parallaxScrollDistance * y;
                    s && e.options.enableTransform ? (e.parentWithTransform && (b -= o),
                    l.transform = "translate3d(0, " + b + "px, 0)") : e.image.useImgTag ? l.top = b + "px" : (e.bgPosVerticalCenter && (b += e.bgPosVerticalCenter),
                    l.backgroundPosition = "50% " + b + "px"),
                    l.position = p ? "absolute" : "fixed"
                }
                e.css(e.image.$item, l),
                e.options.onScroll && e.options.onScroll.call(e, {
                    section: i,
                    beforeTop: u,
                    beforeTopEnd: h,
                    afterTop: d,
                    beforeBottom: m,
                    beforeBottomEnd: f,
                    afterBottom: g,
                    visiblePercent: v,
                    fromViewportCenter: y
                })
            }
        }
    }
    ,
    i(t, "scroll", o),
    i(t, "resize", o),
    i(t, "orientationchange", o),
    i(t, "load", o);
    var g = function(t) {
        ("object" == typeof HTMLElement ? t instanceof HTMLElement : t && "object" == typeof t && null !== t && 1 === t.nodeType && "string" == typeof t.nodeName) && (t = [t]);
        for (var e, i = arguments[1], o = Array.prototype.slice.call(arguments, 2), r = t.length, n = 0; r > n; n++)
            if ("object" == typeof i || void 0 === i ? t[n].jarallax || (t[n].jarallax = new f(t[n],i)) : t[n].jarallax && (e = t[n].jarallax[i].apply(t[n].jarallax, o)),
            void 0 !== e)
                return e;
        return t
    };
    g.constructor = f;
    var y = t.jarallax;
    if (t.jarallax = g,
    t.jarallax.noConflict = function() {
        return t.jarallax = y,
        this
    }
    ,
    "undefined" != typeof jQuery) {
        var v = function() {
            var e = arguments || [];
            Array.prototype.unshift.call(e, this);
            var i = g.apply(t, e);
            return "object" != typeof i ? i : this
        };
        v.constructor = f;
        var w = jQuery.fn.jarallax;
        jQuery.fn.jarallax = v,
        jQuery.fn.jarallax.noConflict = function() {
            return jQuery.fn.jarallax = w,
            this
        }
    }
    i(t, "DOMContentLoaded", function() {
        g(document.querySelectorAll("[data-jarallax], [data-jarallax-video]"))
    })
}(window),
function() {
    "use strict";
    function t(o) {
        if (!o)
            throw new Error("No options passed to Waypoint constructor");
        if (!o.element)
            throw new Error("No element option passed to Waypoint constructor");
        if (!o.handler)
            throw new Error("No handler option passed to Waypoint constructor");
        this.key = "waypoint-" + e,
        this.options = t.Adapter.extend({}, t.defaults, o),
        this.element = this.options.element,
        this.adapter = new t.Adapter(this.element),
        this.callback = o.handler,
        this.axis = this.options.horizontal ? "horizontal" : "vertical",
        this.enabled = this.options.enabled,
        this.triggerPoint = null,
        this.group = t.Group.findOrCreate({
            name: this.options.group,
            axis: this.axis
        }),
        this.context = t.Context.findOrCreateByElement(this.options.context),
        t.offsetAliases[this.options.offset] && (this.options.offset = t.offsetAliases[this.options.offset]),
        this.group.add(this),
        this.context.add(this),
        i[this.key] = this,
        e += 1
    }
    var e = 0
      , i = {};
    t.prototype.queueTrigger = function(t) {
        this.group.queueTrigger(this, t)
    }
    ,
    t.prototype.trigger = function(t) {
        this.enabled && this.callback && this.callback.apply(this, t)
    }
    ,
    t.prototype.destroy = function() {
        this.context.remove(this),
        this.group.remove(this),
        delete i[this.key]
    }
    ,
    t.prototype.disable = function() {
        return this.enabled = !1,
        this
    }
    ,
    t.prototype.enable = function() {
        return this.context.refresh(),
        this.enabled = !0,
        this
    }
    ,
    t.prototype.next = function() {
        return this.group.next(this)
    }
    ,
    t.prototype.previous = function() {
        return this.group.previous(this)
    }
    ,
    t.invokeAll = function(t) {
        var e = [];
        for (var o in i)
            e.push(i[o]);
        for (var r = 0, n = e.length; n > r; r++)
            e[r][t]()
    }
    ,
    t.destroyAll = function() {
        t.invokeAll("destroy")
    }
    ,
    t.disableAll = function() {
        t.invokeAll("disable")
    }
    ,
    t.enableAll = function() {
        for (var e in t.Context.refreshAll(),
        i)
            i[e].enabled = !0;
        return this
    }
    ,
    t.refreshAll = function() {
        t.Context.refreshAll()
    }
    ,
    t.viewportHeight = function() {
        return window.innerHeight || document.documentElement.clientHeight
    }
    ,
    t.viewportWidth = function() {
        return document.documentElement.clientWidth
    }
    ,
    t.adapters = [],
    t.defaults = {
        context: window,
        continuous: !0,
        enabled: !0,
        group: "default",
        horizontal: !1,
        offset: 0
    },
    t.offsetAliases = {
        "bottom-in-view": function() {
            return this.context.innerHeight() - this.adapter.outerHeight()
        },
        "right-in-view": function() {
            return this.context.innerWidth() - this.adapter.outerWidth()
        }
    },
    window.Waypoint = t
}(),
function() {
    "use strict";
    function t(t) {
        window.setTimeout(t, 1e3 / 60)
    }
    function e(t) {
        this.element = t,
        this.Adapter = r.Adapter,
        this.adapter = new this.Adapter(t),
        this.key = "waypoint-context-" + i,
        this.didScroll = !1,
        this.didResize = !1,
        this.oldScroll = {
            x: this.adapter.scrollLeft(),
            y: this.adapter.scrollTop()
        },
        this.waypoints = {
            vertical: {},
            horizontal: {}
        },
        t.waypointContextKey = this.key,
        o[t.waypointContextKey] = this,
        i += 1,
        r.windowContext || (r.windowContext = !0,
        r.windowContext = new e(window)),
        this.createThrottledScrollHandler(),
        this.createThrottledResizeHandler()
    }
    var i = 0
      , o = {}
      , r = window.Waypoint
      , n = window.onload;
    e.prototype.add = function(t) {
        var e = t.options.horizontal ? "horizontal" : "vertical";
        this.waypoints[e][t.key] = t,
        this.refresh()
    }
    ,
    e.prototype.checkEmpty = function() {
        var t = this.Adapter.isEmptyObject(this.waypoints.horizontal)
          , e = this.Adapter.isEmptyObject(this.waypoints.vertical)
          , i = this.element == this.element.window;
        t && e && !i && (this.adapter.off(".waypoints"),
        delete o[this.key])
    }
    ,
    e.prototype.createThrottledResizeHandler = function() {
        function t() {
            e.handleResize(),
            e.didResize = !1
        }
        var e = this;
        this.adapter.on("resize.waypoints", function() {
            e.didResize || (e.didResize = !0,
            r.requestAnimationFrame(t))
        })
    }
    ,
    e.prototype.createThrottledScrollHandler = function() {
        function t() {
            e.handleScroll(),
            e.didScroll = !1
        }
        var e = this;
        this.adapter.on("scroll.waypoints", function() {
            (!e.didScroll || r.isTouch) && (e.didScroll = !0,
            r.requestAnimationFrame(t))
        })
    }
    ,
    e.prototype.handleResize = function() {
        r.Context.refreshAll()
    }
    ,
    e.prototype.handleScroll = function() {
        var t = {}
          , e = {
            horizontal: {
                newScroll: this.adapter.scrollLeft(),
                oldScroll: this.oldScroll.x,
                forward: "right",
                backward: "left"
            },
            vertical: {
                newScroll: this.adapter.scrollTop(),
                oldScroll: this.oldScroll.y,
                forward: "down",
                backward: "up"
            }
        };
        for (var i in e) {
            var o = e[i]
              , r = o.newScroll > o.oldScroll ? o.forward : o.backward;
            for (var n in this.waypoints[i]) {
                var s = this.waypoints[i][n];
                if (null !== s.triggerPoint) {
                    var a = o.oldScroll < s.triggerPoint
                      , l = o.newScroll >= s.triggerPoint;
                    (a && l || !a && !l) && (s.queueTrigger(r),
                    t[s.group.id] = s.group)
                }
            }
        }
        for (var c in t)
            t[c].flushTriggers();
        this.oldScroll = {
            x: e.horizontal.newScroll,
            y: e.vertical.newScroll
        }
    }
    ,
    e.prototype.innerHeight = function() {
        return this.element == this.element.window ? r.viewportHeight() : this.adapter.innerHeight()
    }
    ,
    e.prototype.remove = function(t) {
        delete this.waypoints[t.axis][t.key],
        this.checkEmpty()
    }
    ,
    e.prototype.innerWidth = function() {
        return this.element == this.element.window ? r.viewportWidth() : this.adapter.innerWidth()
    }
    ,
    e.prototype.destroy = function() {
        var t = [];
        for (var e in this.waypoints)
            for (var i in this.waypoints[e])
                t.push(this.waypoints[e][i]);
        for (var o = 0, r = t.length; r > o; o++)
            t[o].destroy()
    }
    ,
    e.prototype.refresh = function() {
        var t, e = this.element == this.element.window, i = e ? void 0 : this.adapter.offset(), o = {};
        for (var n in this.handleScroll(),
        t = {
            horizontal: {
                contextOffset: e ? 0 : i.left,
                contextScroll: e ? 0 : this.oldScroll.x,
                contextDimension: this.innerWidth(),
                oldScroll: this.oldScroll.x,
                forward: "right",
                backward: "left",
                offsetProp: "left"
            },
            vertical: {
                contextOffset: e ? 0 : i.top,
                contextScroll: e ? 0 : this.oldScroll.y,
                contextDimension: this.innerHeight(),
                oldScroll: this.oldScroll.y,
                forward: "down",
                backward: "up",
                offsetProp: "top"
            }
        }) {
            var s = t[n];
            for (var a in this.waypoints[n]) {
                var l, c, u, h, d = this.waypoints[n][a], p = d.options.offset, m = d.triggerPoint, f = 0, g = null == m;
                d.element !== d.element.window && (f = d.adapter.offset()[s.offsetProp]),
                "function" == typeof p ? p = p.apply(d) : "string" == typeof p && (p = parseFloat(p),
                d.options.offset.indexOf("%") > -1 && (p = Math.ceil(s.contextDimension * p / 100))),
                l = s.contextScroll - s.contextOffset,
                d.triggerPoint = Math.floor(f + l - p),
                c = m < s.oldScroll,
                u = d.triggerPoint >= s.oldScroll,
                h = !c && !u,
                !g && (c && u) ? (d.queueTrigger(s.backward),
                o[d.group.id] = d.group) : !g && h ? (d.queueTrigger(s.forward),
                o[d.group.id] = d.group) : g && s.oldScroll >= d.triggerPoint && (d.queueTrigger(s.forward),
                o[d.group.id] = d.group)
            }
        }
        return r.requestAnimationFrame(function() {
            for (var t in o)
                o[t].flushTriggers()
        }),
        this
    }
    ,
    e.findOrCreateByElement = function(t) {
        return e.findByElement(t) || new e(t)
    }
    ,
    e.refreshAll = function() {
        for (var t in o)
            o[t].refresh()
    }
    ,
    e.findByElement = function(t) {
        return o[t.waypointContextKey]
    }
    ,
    window.onload = function() {
        n && n(),
        e.refreshAll()
    }
    ,
    r.requestAnimationFrame = function(e) {
        (window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || t).call(window, e)
    }
    ,
    r.Context = e
}(),
function() {
    "use strict";
    function t(t, e) {
        return t.triggerPoint - e.triggerPoint
    }
    function e(t, e) {
        return e.triggerPoint - t.triggerPoint
    }
    function i(t) {
        this.name = t.name,
        this.axis = t.axis,
        this.id = this.name + "-" + this.axis,
        this.waypoints = [],
        this.clearTriggerQueues(),
        o[this.axis][this.name] = this
    }
    var o = {
        vertical: {},
        horizontal: {}
    }
      , r = window.Waypoint;
    i.prototype.add = function(t) {
        this.waypoints.push(t)
    }
    ,
    i.prototype.clearTriggerQueues = function() {
        this.triggerQueues = {
            up: [],
            down: [],
            left: [],
            right: []
        }
    }
    ,
    i.prototype.flushTriggers = function() {
        for (var i in this.triggerQueues) {
            var o = this.triggerQueues[i]
              , r = "up" === i || "left" === i;
            o.sort(r ? e : t);
            for (var n = 0, s = o.length; s > n; n += 1) {
                var a = o[n];
                (a.options.continuous || n === o.length - 1) && a.trigger([i])
            }
        }
        this.clearTriggerQueues()
    }
    ,
    i.prototype.next = function(e) {
        this.waypoints.sort(t);
        var i = r.Adapter.inArray(e, this.waypoints);
        return i === this.waypoints.length - 1 ? null : this.waypoints[i + 1]
    }
    ,
    i.prototype.previous = function(e) {
        this.waypoints.sort(t);
        var i = r.Adapter.inArray(e, this.waypoints);
        return i ? this.waypoints[i - 1] : null
    }
    ,
    i.prototype.queueTrigger = function(t, e) {
        this.triggerQueues[e].push(t)
    }
    ,
    i.prototype.remove = function(t) {
        var e = r.Adapter.inArray(t, this.waypoints);
        e > -1 && this.waypoints.splice(e, 1)
    }
    ,
    i.prototype.first = function() {
        return this.waypoints[0]
    }
    ,
    i.prototype.last = function() {
        return this.waypoints[this.waypoints.length - 1]
    }
    ,
    i.findOrCreate = function(t) {
        return o[t.axis][t.name] || new i(t)
    }
    ,
    r.Group = i
}(),
function() {
    "use strict";
    function t(t) {
        this.$element = e(t)
    }
    var e = window.jQuery
      , i = window.Waypoint;
    e.each(["innerHeight", "innerWidth", "off", "offset", "on", "outerHeight", "outerWidth", "scrollLeft", "scrollTop"], function(e, i) {
        t.prototype[i] = function() {
            var t = Array.prototype.slice.call(arguments);
            return this.$element[i].apply(this.$element, t)
        }
    }),
    e.each(["extend", "inArray", "isEmptyObject"], function(i, o) {
        t[o] = e[o]
    }),
    i.adapters.push({
        name: "jquery",
        Adapter: t
    }),
    i.Adapter = t
}(),
function() {
    "use strict";
    function t(t) {
        return function() {
            var i = []
              , o = arguments[0];
            return t.isFunction(arguments[0]) && ((o = t.extend({}, arguments[1])).handler = arguments[0]),
            this.each(function() {
                var r = t.extend({}, o, {
                    element: this
                });
                "string" == typeof r.context && (r.context = t(this).closest(r.context)[0]),
                i.push(new e(r))
            }),
            i
        }
    }
    var e = window.Waypoint;
    window.jQuery && (window.jQuery.fn.waypoint = t(window.jQuery)),
    window.Zepto && (window.Zepto.fn.waypoint = t(window.Zepto))
}(),
function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? e(require("jquery")) : "function" == typeof define && define.amd ? define(["jquery"], e) : e(t.$)
}(this, function(t) {
    "use strict";
    function e(t) {
        return "%" == t[t.length - 1]
    }
    function i(t, e, i) {
        function o(t, e) {
            var i = n.createShader(t);
            if (n.shaderSource(i, e),
            n.compileShader(i),
            !n.getShaderParameter(i, n.COMPILE_STATUS))
                throw new Error("compile error: " + n.getShaderInfoLog(i));
            return i
        }
        var r = {};
        if (r.id = n.createProgram(),
        n.attachShader(r.id, o(n.VERTEX_SHADER, t)),
        n.attachShader(r.id, o(n.FRAGMENT_SHADER, e)),
        n.linkProgram(r.id),
        !n.getProgramParameter(r.id, n.LINK_STATUS))
            throw new Error("link error: " + n.getProgramInfoLog(r.id));
        r.uniforms = {},
        r.locations = {},
        n.useProgram(r.id),
        n.enableVertexAttribArray(0);
        for (var s, a, l = /uniform (\w+) (\w+)/g, c = t + e; null != (s = l.exec(c)); )
            a = s[2],
            r.locations[a] = n.getUniformLocation(r.id, a);
        return r
    }
    function o(t, e) {
        n.activeTexture(n.TEXTURE0 + (e || 0)),
        n.bindTexture(n.TEXTURE_2D, t)
    }
    function r(t) {
        var e = /url\(["']?([^"']*)["']?\)/.exec(t);
        return null == e ? null : e[1]
    }
    var n, s = (t = t && "default"in t ? t.default : t)(window), a = function() {
        function t(t, e, o) {
            var r = "OES_texture_" + t
              , n = r + "_linear"
              , s = n in i
              , a = [r];
            return s && a.push(n),
            {
                type: e,
                arrayType: o,
                linearSupport: s,
                extensions: a
            }
        }
        var e = document.createElement("canvas");
        if (!(n = e.getContext("webgl") || e.getContext("experimental-webgl")))
            return null;
        var i = {};
        if (["OES_texture_float", "OES_texture_half_float", "OES_texture_float_linear", "OES_texture_half_float_linear"].forEach(function(t) {
            var e = n.getExtension(t);
            e && (i[t] = e)
        }),
        !i.OES_texture_float)
            return null;
        var o = [];
        o.push(t("float", n.FLOAT, Float32Array)),
        i.OES_texture_half_float && o.push(t("half_float", i.OES_texture_half_float.HALF_FLOAT_OES, null));
        var r = n.createTexture()
          , s = n.createFramebuffer();
        n.bindFramebuffer(n.FRAMEBUFFER, s),
        n.bindTexture(n.TEXTURE_2D, r),
        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.NEAREST),
        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.NEAREST),
        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE),
        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE);
        for (var a = null, l = 0; l < o.length; l++)
            if (n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, 32, 32, 0, n.RGBA, o[l].type, null),
            n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, r, 0),
            n.checkFramebufferStatus(n.FRAMEBUFFER) === n.FRAMEBUFFER_COMPLETE) {
                a = o[l];
                break
            }
        return a
    }(), l = function(t, e) {
        try {
            return new ImageData(32,32)
        } catch (t) {
            return document.createElement("canvas").getContext("2d").createImageData(32, 32)
        }
    }();
    t("head").prepend("<style>.jquery-ripples { position: relative; z-index: 0; }</style>");
    var c = function(e, i) {
        var o = this;
        this.$el = t(e),
        this.interactive = i.interactive,
        this.resolution = i.resolution,
        this.textureDelta = new Float32Array([1 / this.resolution, 1 / this.resolution]),
        this.perturbance = i.perturbance,
        this.dropRadius = i.dropRadius,
        this.crossOrigin = i.crossOrigin,
        this.imageUrl = i.imageUrl;
        var r = document.createElement("canvas");
        r.width = this.$el.innerWidth(),
        r.height = this.$el.innerHeight(),
        this.canvas = r,
        this.$canvas = t(r),
        this.$canvas.css({
            position: "absolute",
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
            zIndex: -1
        }),
        this.$el.addClass("jquery-ripples").append(r),
        this.context = n = r.getContext("webgl") || r.getContext("experimental-webgl"),
        a.extensions.forEach(function(t) {
            n.getExtension(t)
        }),
        t(window).on("resize", function() {
            o.updateSize()
        }),
        this.textures = [],
        this.framebuffers = [],
        this.bufferWriteIndex = 0,
        this.bufferReadIndex = 1;
        for (var s = a.arrayType, l = s ? new s(this.resolution * this.resolution * 4) : null, c = 0; c < 2; c++) {
            var u = n.createTexture()
              , h = n.createFramebuffer();
            n.bindFramebuffer(n.FRAMEBUFFER, h),
            n.bindTexture(n.TEXTURE_2D, u),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, a.linearSupport ? n.LINEAR : n.NEAREST),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, a.linearSupport ? n.LINEAR : n.NEAREST),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, n.CLAMP_TO_EDGE),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, n.CLAMP_TO_EDGE),
            n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, this.resolution, this.resolution, 0, n.RGBA, a.type, l),
            n.framebufferTexture2D(n.FRAMEBUFFER, n.COLOR_ATTACHMENT0, n.TEXTURE_2D, u, 0),
            this.textures.push(u),
            this.framebuffers.push(h)
        }
        this.quad = n.createBuffer(),
        n.bindBuffer(n.ARRAY_BUFFER, this.quad),
        n.bufferData(n.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1]), n.STATIC_DRAW),
        this.initShaders(),
        this.initTexture(),
        this.setTransparentTexture(),
        this.loadImage(),
        n.clearColor(0, 0, 0, 0),
        n.blendFunc(n.SRC_ALPHA, n.ONE_MINUS_SRC_ALPHA),
        this.visible = !0,
        this.running = !0,
        this.inited = !0,
        this.destroyed = !1,
        this.setupPointerEvents(),
        requestAnimationFrame(function t() {
            o.destroyed || (o.step(),
            requestAnimationFrame(t))
        })
    };
    c.DEFAULTS = {
        imageUrl: null,
        resolution: 256,
        dropRadius: 20,
        perturbance: .03,
        interactive: !0,
        crossOrigin: ""
    },
    c.prototype = {
        setupPointerEvents: function() {
            function t(t, i) {
                e.visible && e.running && e.interactive && e.dropAtPointer(t, e.dropRadius * (i ? 1.5 : 1), i ? .14 : .01)
            }
            var e = this;
            this.$el.on("mousemove.ripples", function(e) {
                t(e)
            }).on("touchmove.ripples, touchstart.ripples", function(e) {
                for (var i = e.originalEvent.changedTouches, o = 0; o < i.length; o++)
                    t(i[o])
            }).on("mousedown.ripples", function(e) {
                t(e, !0)
            })
        },
        loadImage: function() {
            var t = this;
            n = this.context;
            var e = this.imageUrl || r(this.originalCssBackgroundImage) || r(this.$el.css("backgroundImage"));
            if (e != this.imageSource)
                if (this.imageSource = e,
                this.imageSource) {
                    var i = new Image;
                    i.onload = function() {
                        function e(t) {
                            return 0 == (t & t - 1)
                        }
                        n = t.context;
                        var o = e(i.width) && e(i.height) ? n.REPEAT : n.CLAMP_TO_EDGE;
                        n.bindTexture(n.TEXTURE_2D, t.backgroundTexture),
                        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, o),
                        n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, o),
                        n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, i),
                        t.backgroundWidth = i.width,
                        t.backgroundHeight = i.height,
                        t.hideCssBackground()
                    }
                    ,
                    i.onerror = function() {
                        n = t.context,
                        t.setTransparentTexture()
                    }
                    ,
                    i.crossOrigin = function(t) {
                        return t.match(/^data:/)
                    }(this.imageSource) ? null : this.crossOrigin,
                    i.src = this.imageSource
                } else
                    this.setTransparentTexture()
        },
        step: function() {
            n = this.context,
            this.visible && (this.computeTextureBoundaries(),
            this.running && this.update(),
            this.render())
        },
        drawQuad: function() {
            n.bindBuffer(n.ARRAY_BUFFER, this.quad),
            n.vertexAttribPointer(0, 2, n.FLOAT, !1, 0, 0),
            n.drawArrays(n.TRIANGLE_FAN, 0, 4)
        },
        render: function() {
            n.bindFramebuffer(n.FRAMEBUFFER, null),
            n.viewport(0, 0, this.canvas.width, this.canvas.height),
            n.enable(n.BLEND),
            n.clear(n.COLOR_BUFFER_BIT | n.DEPTH_BUFFER_BIT),
            n.useProgram(this.renderProgram.id),
            o(this.backgroundTexture, 0),
            o(this.textures[0], 1),
            n.uniform1f(this.renderProgram.locations.perturbance, this.perturbance),
            n.uniform2fv(this.renderProgram.locations.topLeft, this.renderProgram.uniforms.topLeft),
            n.uniform2fv(this.renderProgram.locations.bottomRight, this.renderProgram.uniforms.bottomRight),
            n.uniform2fv(this.renderProgram.locations.containerRatio, this.renderProgram.uniforms.containerRatio),
            n.uniform1i(this.renderProgram.locations.samplerBackground, 0),
            n.uniform1i(this.renderProgram.locations.samplerRipples, 1),
            this.drawQuad(),
            n.disable(n.BLEND)
        },
        update: function() {
            n.viewport(0, 0, this.resolution, this.resolution),
            n.bindFramebuffer(n.FRAMEBUFFER, this.framebuffers[this.bufferWriteIndex]),
            o(this.textures[this.bufferReadIndex]),
            n.useProgram(this.updateProgram.id),
            this.drawQuad(),
            this.swapBufferIndices()
        },
        swapBufferIndices: function() {
            this.bufferWriteIndex = 1 - this.bufferWriteIndex,
            this.bufferReadIndex = 1 - this.bufferReadIndex
        },
        computeTextureBoundaries: function() {
            var t, i = this.$el.css("background-size"), o = this.$el.css("background-attachment"), r = function(t) {
                var e = t.split(" ");
                if (1 !== e.length)
                    return e.map(function(e) {
                        switch (t) {
                        case "center":
                            return "50%";
                        case "top":
                        case "left":
                            return "0";
                        case "right":
                        case "bottom":
                            return "100%";
                        default:
                            return e
                        }
                    });
                switch (t) {
                case "center":
                    return ["50%", "50%"];
                case "top":
                    return ["50%", "0"];
                case "bottom":
                    return ["50%", "100%"];
                case "left":
                    return ["0", "50%"];
                case "right":
                    return ["100%", "50%"];
                default:
                    return [t, "50%"]
                }
            }(this.$el.css("background-position"));
            if ("fixed" == o ? ((t = {
                left: window.pageXOffset,
                top: window.pageYOffset
            }).width = s.width(),
            t.height = s.height()) : ((t = this.$el.offset()).width = this.$el.innerWidth(),
            t.height = this.$el.innerHeight()),
            "cover" == i)
                var n = Math.max(t.width / this.backgroundWidth, t.height / this.backgroundHeight)
                  , a = this.backgroundWidth * n
                  , l = this.backgroundHeight * n;
            else if ("contain" == i)
                n = Math.min(t.width / this.backgroundWidth, t.height / this.backgroundHeight),
                a = this.backgroundWidth * n,
                l = this.backgroundHeight * n;
            else {
                a = (i = i.split(" "))[0] || "",
                l = i[1] || a;
                e(a) ? a = t.width * parseFloat(a) / 100 : "auto" != a && (a = parseFloat(a)),
                e(l) ? l = t.height * parseFloat(l) / 100 : "auto" != l && (l = parseFloat(l)),
                "auto" == a && "auto" == l ? (a = this.backgroundWidth,
                l = this.backgroundHeight) : ("auto" == a && (a = this.backgroundWidth * (l / this.backgroundHeight)),
                "auto" == l && (l = this.backgroundHeight * (a / this.backgroundWidth)))
            }
            var c = r[0]
              , u = r[1];
            c = e(c) ? t.left + (t.width - a) * parseFloat(c) / 100 : t.left + parseFloat(c),
            u = e(u) ? t.top + (t.height - l) * parseFloat(u) / 100 : t.top + parseFloat(u);
            var h = this.$el.offset();
            this.renderProgram.uniforms.topLeft = new Float32Array([(h.left - c) / a, (h.top - u) / l]),
            this.renderProgram.uniforms.bottomRight = new Float32Array([this.renderProgram.uniforms.topLeft[0] + this.$el.innerWidth() / a, this.renderProgram.uniforms.topLeft[1] + this.$el.innerHeight() / l]);
            var d = Math.max(this.canvas.width, this.canvas.height);
            this.renderProgram.uniforms.containerRatio = new Float32Array([this.canvas.width / d, this.canvas.height / d])
        },
        initShaders: function() {
            var t = ["attribute vec2 vertex;", "varying vec2 coord;", "void main() {", "coord = vertex * 0.5 + 0.5;", "gl_Position = vec4(vertex, 0.0, 1.0);", "}"].join("\n");
            this.dropProgram = i(t, ["precision highp float;", "const float PI = 3.141592653589793;", "uniform sampler2D texture;", "uniform vec2 center;", "uniform float radius;", "uniform float strength;", "varying vec2 coord;", "void main() {", "vec4 info = texture2D(texture, coord);", "float drop = max(0.0, 1.0 - length(center * 0.5 + 0.5 - coord) / radius);", "drop = 0.5 - cos(drop * PI) * 0.5;", "info.r += drop * strength;", "gl_FragColor = info;", "}"].join("\n")),
            this.updateProgram = i(t, ["precision highp float;", "uniform sampler2D texture;", "uniform vec2 delta;", "varying vec2 coord;", "void main() {", "vec4 info = texture2D(texture, coord);", "vec2 dx = vec2(delta.x, 0.0);", "vec2 dy = vec2(0.0, delta.y);", "float average = (", "texture2D(texture, coord - dx).r +", "texture2D(texture, coord - dy).r +", "texture2D(texture, coord + dx).r +", "texture2D(texture, coord + dy).r", ") * 0.25;", "info.g += (average - info.r) * 2.0;", "info.g *= 0.995;", "info.r += info.g;", "gl_FragColor = info;", "}"].join("\n")),
            n.uniform2fv(this.updateProgram.locations.delta, this.textureDelta),
            this.renderProgram = i(["precision highp float;", "attribute vec2 vertex;", "uniform vec2 topLeft;", "uniform vec2 bottomRight;", "uniform vec2 containerRatio;", "varying vec2 ripplesCoord;", "varying vec2 backgroundCoord;", "void main() {", "backgroundCoord = mix(topLeft, bottomRight, vertex * 0.5 + 0.5);", "backgroundCoord.y = 1.0 - backgroundCoord.y;", "ripplesCoord = vec2(vertex.x, -vertex.y) * containerRatio * 0.5 + 0.5;", "gl_Position = vec4(vertex.x, -vertex.y, 0.0, 1.0);", "}"].join("\n"), ["precision highp float;", "uniform sampler2D samplerBackground;", "uniform sampler2D samplerRipples;", "uniform vec2 delta;", "uniform float perturbance;", "varying vec2 ripplesCoord;", "varying vec2 backgroundCoord;", "void main() {", "float height = texture2D(samplerRipples, ripplesCoord).r;", "float heightX = texture2D(samplerRipples, vec2(ripplesCoord.x + delta.x, ripplesCoord.y)).r;", "float heightY = texture2D(samplerRipples, vec2(ripplesCoord.x, ripplesCoord.y + delta.y)).r;", "vec3 dx = vec3(delta.x, heightX - height, 0.0);", "vec3 dy = vec3(0.0, heightY - height, delta.y);", "vec2 offset = -normalize(cross(dy, dx)).xz;", "float specular = pow(max(0.0, dot(offset, normalize(vec2(-0.6, 1.0)))), 4.0);", "gl_FragColor = texture2D(samplerBackground, backgroundCoord + offset * perturbance) + specular;", "}"].join("\n")),
            n.uniform2fv(this.renderProgram.locations.delta, this.textureDelta)
        },
        initTexture: function() {
            this.backgroundTexture = n.createTexture(),
            n.bindTexture(n.TEXTURE_2D, this.backgroundTexture),
            n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL, 1),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, n.LINEAR),
            n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, n.LINEAR)
        },
        setTransparentTexture: function() {
            n.bindTexture(n.TEXTURE_2D, this.backgroundTexture),
            n.texImage2D(n.TEXTURE_2D, 0, n.RGBA, n.RGBA, n.UNSIGNED_BYTE, l)
        },
        hideCssBackground: function() {
            var t = this.$el[0].style.backgroundImage;
            "none" != t && (this.originalInlineCss = t,
            this.originalCssBackgroundImage = this.$el.css("backgroundImage"),
            this.$el.css("backgroundImage", "none"))
        },
        restoreCssBackground: function() {
            this.$el.css("backgroundImage", this.originalInlineCss || "")
        },
        dropAtPointer: function(t, e, i) {
            var o = parseInt(this.$el.css("border-left-width")) || 0
              , r = parseInt(this.$el.css("border-top-width")) || 0;
            this.drop(t.pageX - this.$el.offset().left - o, t.pageY - this.$el.offset().top - r, e, i)
        },
        drop: function(t, e, i, r) {
            n = this.context;
            var s = this.$el.innerWidth()
              , a = this.$el.innerHeight()
              , l = Math.max(s, a);
            i /= l;
            var c = new Float32Array([(2 * t - s) / l, (a - 2 * e) / l]);
            n.viewport(0, 0, this.resolution, this.resolution),
            n.bindFramebuffer(n.FRAMEBUFFER, this.framebuffers[this.bufferWriteIndex]),
            o(this.textures[this.bufferReadIndex]),
            n.useProgram(this.dropProgram.id),
            n.uniform2fv(this.dropProgram.locations.center, c),
            n.uniform1f(this.dropProgram.locations.radius, i),
            n.uniform1f(this.dropProgram.locations.strength, r),
            this.drawQuad(),
            this.swapBufferIndices()
        },
        updateSize: function() {
            var t = this.$el.innerWidth()
              , e = this.$el.innerHeight();
            t == this.canvas.width && e == this.canvas.height || (this.canvas.width = t,
            this.canvas.height = e)
        },
        destroy: function() {
            this.$el.off(".ripples").removeClass("jquery-ripples").removeData("ripples"),
            this.$canvas.remove(),
            this.restoreCssBackground(),
            this.destroyed = !0
        },
        show: function() {
            this.visible = !0,
            this.$canvas.show(),
            this.hideCssBackground()
        },
        hide: function() {
            this.visible = !1,
            this.$canvas.hide(),
            this.restoreCssBackground()
        },
        pause: function() {
            this.running = !1
        },
        play: function() {
            this.running = !0
        },
        set: function(t, e) {
            switch (t) {
            case "dropRadius":
            case "perturbance":
            case "interactive":
            case "crossOrigin":
                this[t] = e;
                break;
            case "imageUrl":
                this.imageUrl = e,
                this.loadImage()
            }
        }
    };
    var u = t.fn.ripples;
    t.fn.ripples = function(e) {
        if (!a)
            throw new Error("Your browser does not support WebGL, the OES_texture_float extension or rendering to floating point textures.");
        var i = arguments.length > 1 ? Array.prototype.slice.call(arguments, 1) : void 0;
        return this.each(function() {
            var o = t(this)
              , r = o.data("ripples")
              , n = t.extend({}, c.DEFAULTS, o.data(), "object" == typeof e && e);
            (r || "string" != typeof e) && (r ? "string" == typeof e && c.prototype[e].apply(r, i) : o.data("ripples", r = new c(this,n)))
        })
    }
    ,
    t.fn.ripples.Constructor = c,
    t.fn.ripples.noConflict = function() {
        return t.fn.ripples = u,
        this
    }
}),
function(t, e, i, o) {
    "use strict";
    function r(e, i) {
        this.element = e,
        this.settings = t.extend({}, s, i),
        this._defaults = s,
        this._name = n,
        this.init()
    }
    var n = "mgGlitch"
      , s = {
        destroy: !1,
        glitch: !0,
        scale: !0,
        blend: !0,
        blendModeType: "hue",
        glitch1TimeMin: 600,
        glitch1TimeMax: 900,
        glitch2TimeMin: 10,
        glitch2TimeMax: 115,
        zIndexStart: 5
    };
    t.extend(r.prototype, {
        init: function() {
            this.glitch()
        },
        glitch: function() {
            function e(t, e) {
                return Math.floor(Math.random() * (e - t + 1)) + t
            }
            var i = this.element
              , o = this.settings.scale
              , r = this.settings.glitch1TimeMin
              , n = this.settings.glitch1TimeMax
              , s = this.settings.glitch2TimeMin
              , a = this.settings.glitch2TimeMax
              , l = this.settings.zIndexStart;
            if (!0 === this.settings.destroy)
                (t(i).hasClass("el-front-1") || t(i).hasClass("front-3") || t(i).hasClass("front-2")) && t(".front-1, .front-2, .front-3").remove(),
                t(".back").removeClass("back");
            else if (!1 === this.settings.destroy) {
                if (t(i).clone().insertBefore(i).addClass("back").css({
                    "z-index": l
                }),
                !0 === this.settings.blend)
                    t(i).clone().insertAfter(i).addClass("front-3").css({
                        "z-index": l + 3,
                        "mix-blend-mode": this.settings.blendModeType
                    }),
                    function r() {
                        var n = e(10, 1900)
                          , l = e(10, 1300)
                          , c = e(0, 40)
                          , u = e(0, 40)
                          , h = e(s, a);
                        if (!0 === o)
                            var d = (Math.random() * (1.1 - .9) + .9).toFixed(2);
                        else
                            !1 === o && (d = 1);
                        t(i).next().next().css({
                            clip: "rect(" + n + "px, 9999px, " + l + "px,0px)",
                            left: c,
                            right: u,
                            "-webkit-transform": "scale(" + d + ")",
                            "-ms-transform": "scale(" + d + ")",
                            transform: "scale(" + d + ")"
                        }),
                        setTimeout(r, h)
                    }();
                if (!0 === this.settings.glitch)
                    t(i).clone().insertAfter(i).addClass("front-2").css({
                        "z-index": l + 2
                    }),
                    t(".back").next().addClass("front-1").css({
                        "z-index": l + 1
                    }),
                    function o() {
                        var s = e(10, 1900)
                          , a = e(10, 1300)
                          , l = e(0, 16)
                          , c = e(0, 16)
                          , u = e(r, n);
                        t(i).css({
                            clip: "rect(" + s + "px, 9999px, " + a + "px,0px)",
                            right: c,
                            left: l
                        }),
                        setTimeout(o, u)
                    }(),
                    function r() {
                        var n = e(10, 1900)
                          , l = e(10, 1300)
                          , c = e(0, 40)
                          , u = e(0, 40)
                          , h = e(s, a);
                        if (!0 === o)
                            var d = (Math.random() * (1.1 - .9) + .9).toFixed(2);
                        else
                            !1 === o && (d = 1);
                        t(i).next().css({
                            clip: "rect(" + n + "px, 9999px, " + l + "px,0px)",
                            left: c,
                            right: u,
                            "-webkit-transform": "scale(" + d + ")",
                            "-ms-transform": "scale(" + d + ")",
                            transform: "scale(" + d + ")"
                        }),
                        setTimeout(r, h)
                    }()
            }
        }
    }),
    t.fn[n] = function(t) {
        return this.each(function() {
            new r(this,t)
        })
    }
}(jQuery, window, document),
$("#particles-js").length) {
    function hexToRgb(t) {
        t = t.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(t, e, i, o) {
            return e + e + i + i + o + o
        });
        var e = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);
        return e ? {
            r: parseInt(e[1], 16),
            g: parseInt(e[2], 16),
            b: parseInt(e[3], 16)
        } : null
    }
    function clamp(t, e, i) {
        return Math.min(Math.max(t, e), i)
    }
    function isInArray(t, e) {
        return e.indexOf(t) > -1
    }
    var pJS = function(t, e) {
        var i = document.querySelector("#" + t + " > .particles-js-canvas-el");
        this.pJS = {
            canvas: {
                el: i,
                w: i.offsetWidth,
                h: i.offsetHeight
            },
            particles: {
                number: {
                    value: 400,
                    density: {
                        enable: !0,
                        value_area: 800
                    }
                },
                color: {
                    value: "#fff"
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#ff0000"
                    },
                    polygon: {
                        nb_sides: 5
                    },
                    image: {
                        src: "",
                        width: 100,
                        height: 100
                    }
                },
                opacity: {
                    value: 1,
                    random: !1,
                    anim: {
                        enable: !1,
                        speed: 2,
                        opacity_min: 0,
                        sync: !1
                    }
                },
                size: {
                    value: 20,
                    random: !1,
                    anim: {
                        enable: !1,
                        speed: 20,
                        size_min: 0,
                        sync: !1
                    }
                },
                line_linked: {
                    enable: !0,
                    distance: 100,
                    color: "#fff",
                    opacity: 1,
                    width: 1
                },
                move: {
                    enable: !0,
                    speed: 2,
                    direction: "none",
                    random: !1,
                    straight: !1,
                    out_mode: "out",
                    bounce: !1,
                    attract: {
                        enable: !1,
                        rotateX: 3e3,
                        rotateY: 3e3
                    }
                },
                array: []
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: {
                        enable: !0,
                        mode: "grab"
                    },
                    onclick: {
                        enable: !0,
                        mode: "push"
                    },
                    resize: !0
                },
                modes: {
                    grab: {
                        distance: 100,
                        line_linked: {
                            opacity: 1
                        }
                    },
                    bubble: {
                        distance: 200,
                        size: 80,
                        duration: .4
                    },
                    repulse: {
                        distance: 200,
                        duration: .4
                    },
                    push: {
                        particles_nb: 4
                    },
                    remove: {
                        particles_nb: 2
                    }
                },
                mouse: {}
            },
            retina_detect: !1,
            fn: {
                interact: {},
                modes: {},
                vendors: {}
            },
            tmp: {}
        };
        var o = this.pJS;
        e && Object.deepExtend(o, e),
        o.tmp.obj = {
            size_value: o.particles.size.value,
            size_anim_speed: o.particles.size.anim.speed,
            move_speed: o.particles.move.speed,
            line_linked_distance: o.particles.line_linked.distance,
            line_linked_width: o.particles.line_linked.width,
            mode_grab_distance: o.interactivity.modes.grab.distance,
            mode_bubble_distance: o.interactivity.modes.bubble.distance,
            mode_bubble_size: o.interactivity.modes.bubble.size,
            mode_repulse_distance: o.interactivity.modes.repulse.distance
        },
        o.fn.retinaInit = function() {
            o.retina_detect && window.devicePixelRatio > 1 ? (o.canvas.pxratio = window.devicePixelRatio,
            o.tmp.retina = !0) : (o.canvas.pxratio = 1,
            o.tmp.retina = !1),
            o.canvas.w = o.canvas.el.offsetWidth * o.canvas.pxratio,
            o.canvas.h = o.canvas.el.offsetHeight * o.canvas.pxratio,
            o.particles.size.value = o.tmp.obj.size_value * o.canvas.pxratio,
            o.particles.size.anim.speed = o.tmp.obj.size_anim_speed * o.canvas.pxratio,
            o.particles.move.speed = o.tmp.obj.move_speed * o.canvas.pxratio,
            o.particles.line_linked.distance = o.tmp.obj.line_linked_distance * o.canvas.pxratio,
            o.interactivity.modes.grab.distance = o.tmp.obj.mode_grab_distance * o.canvas.pxratio,
            o.interactivity.modes.bubble.distance = o.tmp.obj.mode_bubble_distance * o.canvas.pxratio,
            o.particles.line_linked.width = o.tmp.obj.line_linked_width * o.canvas.pxratio,
            o.interactivity.modes.bubble.size = o.tmp.obj.mode_bubble_size * o.canvas.pxratio,
            o.interactivity.modes.repulse.distance = o.tmp.obj.mode_repulse_distance * o.canvas.pxratio
        }
        ,
        o.fn.canvasInit = function() {
            o.canvas.ctx = o.canvas.el.getContext("2d")
        }
        ,
        o.fn.canvasSize = function() {
            o.canvas.el.width = o.canvas.w,
            o.canvas.el.height = o.canvas.h,
            o && o.interactivity.events.resize && window.addEventListener("resize", function() {
                o.canvas.w = o.canvas.el.offsetWidth,
                o.canvas.h = o.canvas.el.offsetHeight,
                o.tmp.retina && (o.canvas.w *= o.canvas.pxratio,
                o.canvas.h *= o.canvas.pxratio),
                o.canvas.el.width = o.canvas.w,
                o.canvas.el.height = o.canvas.h,
                o.particles.move.enable || (o.fn.particlesEmpty(),
                o.fn.particlesCreate(),
                o.fn.particlesDraw(),
                o.fn.vendors.densityAutoParticles()),
                o.fn.vendors.densityAutoParticles()
            })
        }
        ,
        o.fn.canvasPaint = function() {
            o.canvas.ctx.fillRect(0, 0, o.canvas.w, o.canvas.h)
        }
        ,
        o.fn.canvasClear = function() {
            o.canvas.ctx.clearRect(0, 0, o.canvas.w, o.canvas.h)
        }
        ,
        o.fn.particle = function(t, e, i) {
            if (this.radius = (o.particles.size.random ? Math.random() : 1) * o.particles.size.value,
            o.particles.size.anim.enable && (this.size_status = !1,
            this.vs = o.particles.size.anim.speed / 100,
            o.particles.size.anim.sync || (this.vs = this.vs * Math.random())),
            this.x = i ? i.x : Math.random() * o.canvas.w,
            this.y = i ? i.y : Math.random() * o.canvas.h,
            this.x > o.canvas.w - 2 * this.radius ? this.x = this.x - this.radius : this.x < 2 * this.radius && (this.x = this.x + this.radius),
            this.y > o.canvas.h - 2 * this.radius ? this.y = this.y - this.radius : this.y < 2 * this.radius && (this.y = this.y + this.radius),
            o.particles.move.bounce && o.fn.vendors.checkOverlap(this, i),
            this.color = {},
            "object" == typeof t.value)
                if (t.value instanceof Array) {
                    var r = t.value[Math.floor(Math.random() * o.particles.color.value.length)];
                    this.color.rgb = hexToRgb(r)
                } else
                    null != t.value.r && null != t.value.g && null != t.value.b && (this.color.rgb = {
                        r: t.value.r,
                        g: t.value.g,
                        b: t.value.b
                    }),
                    null != t.value.h && null != t.value.s && null != t.value.l && (this.color.hsl = {
                        h: t.value.h,
                        s: t.value.s,
                        l: t.value.l
                    });
            else
                "random" == t.value ? this.color.rgb = {
                    r: Math.floor(256 * Math.random()) + 0,
                    g: Math.floor(256 * Math.random()) + 0,
                    b: Math.floor(256 * Math.random()) + 0
                } : "string" == typeof t.value && (this.color = t,
                this.color.rgb = hexToRgb(this.color.value));
            this.opacity = (o.particles.opacity.random ? Math.random() : 1) * o.particles.opacity.value,
            o.particles.opacity.anim.enable && (this.opacity_status = !1,
            this.vo = o.particles.opacity.anim.speed / 100,
            o.particles.opacity.anim.sync || (this.vo = this.vo * Math.random()));
            var n = {};
            switch (o.particles.move.direction) {
            case "top":
                n = {
                    x: 0,
                    y: -1
                };
                break;
            case "top-right":
                n = {
                    x: .5,
                    y: -.5
                };
                break;
            case "right":
                n = {
                    x: 1,
                    y: -0
                };
                break;
            case "bottom-right":
                n = {
                    x: .5,
                    y: .5
                };
                break;
            case "bottom":
                n = {
                    x: 0,
                    y: 1
                };
                break;
            case "bottom-left":
                n = {
                    x: -.5,
                    y: 1
                };
                break;
            case "left":
                n = {
                    x: -1,
                    y: 0
                };
                break;
            case "top-left":
                n = {
                    x: -.5,
                    y: -.5
                };
                break;
            default:
                n = {
                    x: 0,
                    y: 0
                }
            }
            o.particles.move.straight ? (this.vx = n.x,
            this.vy = n.y,
            o.particles.move.random && (this.vx = this.vx * Math.random(),
            this.vy = this.vy * Math.random())) : (this.vx = n.x + Math.random() - .5,
            this.vy = n.y + Math.random() - .5),
            this.vx_i = this.vx,
            this.vy_i = this.vy;
            var s = o.particles.shape.type;
            if ("object" == typeof s) {
                if (s instanceof Array) {
                    var a = s[Math.floor(Math.random() * s.length)];
                    this.shape = a
                }
            } else
                this.shape = s;
            if ("image" == this.shape) {
                var l = o.particles.shape;
                this.img = {
                    src: l.image.src,
                    ratio: l.image.width / l.image.height
                },
                this.img.ratio || (this.img.ratio = 1),
                "svg" == o.tmp.img_type && null != o.tmp.source_svg && (o.fn.vendors.createSvgImg(this),
                o.tmp.pushing && (this.img.loaded = !1))
            }
        }
        ,
        o.fn.particle.prototype.draw = function() {
            var t = this;
            if (null != t.radius_bubble)
                var e = t.radius_bubble;
            else
                e = t.radius;
            if (null != t.opacity_bubble)
                var i = t.opacity_bubble;
            else
                i = t.opacity;
            if (t.color.rgb)
                var r = "rgba(" + t.color.rgb.r + "," + t.color.rgb.g + "," + t.color.rgb.b + "," + i + ")";
            else
                r = "hsla(" + t.color.hsl.h + "," + t.color.hsl.s + "%," + t.color.hsl.l + "%," + i + ")";
            switch (o.canvas.ctx.fillStyle = r,
            o.canvas.ctx.beginPath(),
            t.shape) {
            case "circle":
                o.canvas.ctx.arc(t.x, t.y, e, 0, 2 * Math.PI, !1);
                break;
            case "edge":
                o.canvas.ctx.rect(t.x - e, t.y - e, 2 * e, 2 * e);
                break;
            case "triangle":
                o.fn.vendors.drawShape(o.canvas.ctx, t.x - e, t.y + e / 1.66, 2 * e, 3, 2);
                break;
            case "polygon":
                o.fn.vendors.drawShape(o.canvas.ctx, t.x - e / (o.particles.shape.polygon.nb_sides / 3.5), t.y - e / .76, 2.66 * e / (o.particles.shape.polygon.nb_sides / 3), o.particles.shape.polygon.nb_sides, 1);
                break;
            case "star":
                o.fn.vendors.drawShape(o.canvas.ctx, t.x - 2 * e / (o.particles.shape.polygon.nb_sides / 4), t.y - e / 1.52, 2 * e * 2.66 / (o.particles.shape.polygon.nb_sides / 3), o.particles.shape.polygon.nb_sides, 2);
                break;
            case "image":
                if ("svg" == o.tmp.img_type)
                    var n = t.img.obj;
                else
                    n = o.tmp.img_obj;
                n && o.canvas.ctx.drawImage(n, t.x - e, t.y - e, 2 * e, 2 * e / t.img.ratio)
            }
            o.canvas.ctx.closePath(),
            o.particles.shape.stroke.width > 0 && (o.canvas.ctx.strokeStyle = o.particles.shape.stroke.color,
            o.canvas.ctx.lineWidth = o.particles.shape.stroke.width,
            o.canvas.ctx.stroke()),
            o.canvas.ctx.fill()
        }
        ,
        o.fn.particlesCreate = function() {
            for (var t = 0; t < o.particles.number.value; t++)
                o.particles.array.push(new o.fn.particle(o.particles.color,o.particles.opacity.value))
        }
        ,
        o.fn.particlesUpdate = function() {
            for (var t = 0; t < o.particles.array.length; t++) {
                var e = o.particles.array[t];
                if (o.particles.move.enable) {
                    var i = o.particles.move.speed / 2;
                    e.x += e.vx * i,
                    e.y += e.vy * i
                }
                if (o.particles.opacity.anim.enable && (1 == e.opacity_status ? (e.opacity >= o.particles.opacity.value && (e.opacity_status = !1),
                e.opacity += e.vo) : (e.opacity <= o.particles.opacity.anim.opacity_min && (e.opacity_status = !0),
                e.opacity -= e.vo),
                e.opacity < 0 && (e.opacity = 0)),
                o.particles.size.anim.enable && (1 == e.size_status ? (e.radius >= o.particles.size.value && (e.size_status = !1),
                e.radius += e.vs) : (e.radius <= o.particles.size.anim.size_min && (e.size_status = !0),
                e.radius -= e.vs),
                e.radius < 0 && (e.radius = 0)),
                "bounce" == o.particles.move.out_mode)
                    var r = {
                        x_left: e.radius,
                        x_right: o.canvas.w,
                        y_top: e.radius,
                        y_bottom: o.canvas.h
                    };
                else
                    r = {
                        x_left: -e.radius,
                        x_right: o.canvas.w + e.radius,
                        y_top: -e.radius,
                        y_bottom: o.canvas.h + e.radius
                    };
                switch (e.x - e.radius > o.canvas.w ? (e.x = r.x_left,
                e.y = Math.random() * o.canvas.h) : e.x + e.radius < 0 && (e.x = r.x_right,
                e.y = Math.random() * o.canvas.h),
                e.y - e.radius > o.canvas.h ? (e.y = r.y_top,
                e.x = Math.random() * o.canvas.w) : e.y + e.radius < 0 && (e.y = r.y_bottom,
                e.x = Math.random() * o.canvas.w),
                o.particles.move.out_mode) {
                case "bounce":
                    e.x + e.radius > o.canvas.w ? e.vx = -e.vx : e.x - e.radius < 0 && (e.vx = -e.vx),
                    e.y + e.radius > o.canvas.h ? e.vy = -e.vy : e.y - e.radius < 0 && (e.vy = -e.vy)
                }
                if (isInArray("grab", o.interactivity.events.onhover.mode) && o.fn.modes.grabParticle(e),
                (isInArray("bubble", o.interactivity.events.onhover.mode) || isInArray("bubble", o.interactivity.events.onclick.mode)) && o.fn.modes.bubbleParticle(e),
                (isInArray("repulse", o.interactivity.events.onhover.mode) || isInArray("repulse", o.interactivity.events.onclick.mode)) && o.fn.modes.repulseParticle(e),
                o.particles.line_linked.enable || o.particles.move.attract.enable)
                    for (var n = t + 1; n < o.particles.array.length; n++) {
                        var s = o.particles.array[n];
                        o.particles.line_linked.enable && o.fn.interact.linkParticles(e, s),
                        o.particles.move.attract.enable && o.fn.interact.attractParticles(e, s),
                        o.particles.move.bounce && o.fn.interact.bounceParticles(e, s)
                    }
            }
        }
        ,
        o.fn.particlesDraw = function() {
            o.canvas.ctx.clearRect(0, 0, o.canvas.w, o.canvas.h),
            o.fn.particlesUpdate();
            for (var t = 0; t < o.particles.array.length; t++) {
                o.particles.array[t].draw()
            }
        }
        ,
        o.fn.particlesEmpty = function() {
            o.particles.array = []
        }
        ,
        o.fn.particlesRefresh = function() {
            cancelRequestAnimFrame(o.fn.checkAnimFrame),
            cancelRequestAnimFrame(o.fn.drawAnimFrame),
            o.tmp.source_svg = void 0,
            o.tmp.img_obj = void 0,
            o.tmp.count_svg = 0,
            o.fn.particlesEmpty(),
            o.fn.canvasClear(),
            o.fn.vendors.start()
        }
        ,
        o.fn.interact.linkParticles = function(t, e) {
            var i = t.x - e.x
              , r = t.y - e.y
              , n = Math.sqrt(i * i + r * r);
            if (n <= o.particles.line_linked.distance) {
                var s = o.particles.line_linked.opacity - n / (1 / o.particles.line_linked.opacity) / o.particles.line_linked.distance;
                if (s > 0) {
                    var a = o.particles.line_linked.color_rgb_line;
                    o.canvas.ctx.strokeStyle = "rgba(" + a.r + "," + a.g + "," + a.b + "," + s + ")",
                    o.canvas.ctx.lineWidth = o.particles.line_linked.width,
                    o.canvas.ctx.beginPath(),
                    o.canvas.ctx.moveTo(t.x, t.y),
                    o.canvas.ctx.lineTo(e.x, e.y),
                    o.canvas.ctx.stroke(),
                    o.canvas.ctx.closePath()
                }
            }
        }
        ,
        o.fn.interact.attractParticles = function(t, e) {
            var i = t.x - e.x
              , r = t.y - e.y;
            if (Math.sqrt(i * i + r * r) <= o.particles.line_linked.distance) {
                var n = i / (1e3 * o.particles.move.attract.rotateX)
                  , s = r / (1e3 * o.particles.move.attract.rotateY);
                t.vx -= n,
                t.vy -= s,
                e.vx += n,
                e.vy += s
            }
        }
        ,
        o.fn.interact.bounceParticles = function(t, e) {
            var i = t.x - e.x
              , o = t.y - e.y
              , r = Math.sqrt(i * i + o * o);
            t.radius + e.radius >= r && (t.vx = -t.vx,
            t.vy = -t.vy,
            e.vx = -e.vx,
            e.vy = -e.vy)
        }
        ,
        o.fn.modes.pushParticles = function(t, e) {
            o.tmp.pushing = !0;
            for (var i = 0; t > i; i++)
                o.particles.array.push(new o.fn.particle(o.particles.color,o.particles.opacity.value,{
                    x: e ? e.pos_x : Math.random() * o.canvas.w,
                    y: e ? e.pos_y : Math.random() * o.canvas.h
                })),
                i == t - 1 && (o.particles.move.enable || o.fn.particlesDraw(),
                o.tmp.pushing = !1)
        }
        ,
        o.fn.modes.removeParticles = function(t) {
            o.particles.array.splice(0, t),
            o.particles.move.enable || o.fn.particlesDraw()
        }
        ,
        o.fn.modes.bubbleParticle = function(t) {
            function e() {
                t.opacity_bubble = t.opacity,
                t.radius_bubble = t.radius
            }
            function i(e, i, r, n, s) {
                if (e != i)
                    if (o.tmp.bubble_duration_end) {
                        if (null != r)
                            l = e + (e - (n - h * (n - e) / o.interactivity.modes.bubble.duration)),
                            "size" == s && (t.radius_bubble = l),
                            "opacity" == s && (t.opacity_bubble = l)
                    } else if (u <= o.interactivity.modes.bubble.distance) {
                        if (null != r)
                            var a = r;
                        else
                            a = n;
                        if (a != e) {
                            var l = n - h * (n - e) / o.interactivity.modes.bubble.duration;
                            "size" == s && (t.radius_bubble = l),
                            "opacity" == s && (t.opacity_bubble = l)
                        }
                    } else
                        "size" == s && (t.radius_bubble = void 0),
                        "opacity" == s && (t.opacity_bubble = void 0)
            }
            if (o.interactivity.events.onhover.enable && isInArray("bubble", o.interactivity.events.onhover.mode)) {
                var r = t.x - o.interactivity.mouse.pos_x
                  , n = t.y - o.interactivity.mouse.pos_y
                  , s = 1 - (u = Math.sqrt(r * r + n * n)) / o.interactivity.modes.bubble.distance;
                if (u <= o.interactivity.modes.bubble.distance) {
                    if (s >= 0 && "mousemove" == o.interactivity.status) {
                        if (o.interactivity.modes.bubble.size != o.particles.size.value)
                            if (o.interactivity.modes.bubble.size > o.particles.size.value) {
                                (l = t.radius + o.interactivity.modes.bubble.size * s) >= 0 && (t.radius_bubble = l)
                            } else {
                                var a = t.radius - o.interactivity.modes.bubble.size
                                  , l = t.radius - a * s;
                                t.radius_bubble = l > 0 ? l : 0
                            }
                        if (o.interactivity.modes.bubble.opacity != o.particles.opacity.value)
                            if (o.interactivity.modes.bubble.opacity > o.particles.opacity.value) {
                                (c = o.interactivity.modes.bubble.opacity * s) > t.opacity && c <= o.interactivity.modes.bubble.opacity && (t.opacity_bubble = c)
                            } else {
                                var c;
                                (c = t.opacity - (o.particles.opacity.value - o.interactivity.modes.bubble.opacity) * s) < t.opacity && c >= o.interactivity.modes.bubble.opacity && (t.opacity_bubble = c)
                            }
                    }
                } else
                    e();
                "mouseleave" == o.interactivity.status && e()
            } else if (o.interactivity.events.onclick.enable && isInArray("bubble", o.interactivity.events.onclick.mode)) {
                if (o.tmp.bubble_clicking) {
                    r = t.x - o.interactivity.mouse.click_pos_x,
                    n = t.y - o.interactivity.mouse.click_pos_y;
                    var u = Math.sqrt(r * r + n * n)
                      , h = ((new Date).getTime() - o.interactivity.mouse.click_time) / 1e3;
                    h > o.interactivity.modes.bubble.duration && (o.tmp.bubble_duration_end = !0),
                    h > 2 * o.interactivity.modes.bubble.duration && (o.tmp.bubble_clicking = !1,
                    o.tmp.bubble_duration_end = !1)
                }
                o.tmp.bubble_clicking && (i(o.interactivity.modes.bubble.size, o.particles.size.value, t.radius_bubble, t.radius, "size"),
                i(o.interactivity.modes.bubble.opacity, o.particles.opacity.value, t.opacity_bubble, t.opacity, "opacity"))
            }
        }
        ,
        o.fn.modes.repulseParticle = function(t) {
            if (o.interactivity.events.onhover.enable && isInArray("repulse", o.interactivity.events.onhover.mode) && "mousemove" == o.interactivity.status) {
                var e = t.x - o.interactivity.mouse.pos_x
                  , i = t.y - o.interactivity.mouse.pos_y
                  , r = Math.sqrt(e * e + i * i)
                  , n = {
                    x: e / r,
                    y: i / r
                }
                  , s = clamp(1 / (l = o.interactivity.modes.repulse.distance) * (-1 * Math.pow(r / l, 2) + 1) * l * 100, 0, 50)
                  , a = {
                    x: t.x + n.x * s,
                    y: t.y + n.y * s
                };
                "bounce" == o.particles.move.out_mode ? (a.x - t.radius > 0 && a.x + t.radius < o.canvas.w && (t.x = a.x),
                a.y - t.radius > 0 && a.y + t.radius < o.canvas.h && (t.y = a.y)) : (t.x = a.x,
                t.y = a.y)
            } else if (o.interactivity.events.onclick.enable && isInArray("repulse", o.interactivity.events.onclick.mode))
                if (o.tmp.repulse_finish || (o.tmp.repulse_count++,
                o.tmp.repulse_count == o.particles.array.length && (o.tmp.repulse_finish = !0)),
                o.tmp.repulse_clicking) {
                    var l = Math.pow(o.interactivity.modes.repulse.distance / 6, 3)
                      , c = o.interactivity.mouse.click_pos_x - t.x
                      , u = o.interactivity.mouse.click_pos_y - t.y
                      , h = c * c + u * u
                      , d = -l / h * 1;
                    l >= h && function() {
                        var e = Math.atan2(u, c);
                        if (t.vx = d * Math.cos(e),
                        t.vy = d * Math.sin(e),
                        "bounce" == o.particles.move.out_mode) {
                            var i = {
                                x: t.x + t.vx,
                                y: t.y + t.vy
                            };
                            i.x + t.radius > o.canvas.w ? t.vx = -t.vx : i.x - t.radius < 0 && (t.vx = -t.vx),
                            i.y + t.radius > o.canvas.h ? t.vy = -t.vy : i.y - t.radius < 0 && (t.vy = -t.vy)
                        }
                    }()
                } else
                    0 == o.tmp.repulse_clicking && (t.vx = t.vx_i,
                    t.vy = t.vy_i)
        }
        ,
        o.fn.modes.grabParticle = function(t) {
            if (o.interactivity.events.onhover.enable && "mousemove" == o.interactivity.status) {
                var e = t.x - o.interactivity.mouse.pos_x
                  , i = t.y - o.interactivity.mouse.pos_y
                  , r = Math.sqrt(e * e + i * i);
                if (r <= o.interactivity.modes.grab.distance) {
                    var n = o.interactivity.modes.grab.line_linked.opacity - r / (1 / o.interactivity.modes.grab.line_linked.opacity) / o.interactivity.modes.grab.distance;
                    if (n > 0) {
                        var s = o.particles.line_linked.color_rgb_line;
                        o.canvas.ctx.strokeStyle = "rgba(" + s.r + "," + s.g + "," + s.b + "," + n + ")",
                        o.canvas.ctx.lineWidth = o.particles.line_linked.width,
                        o.canvas.ctx.beginPath(),
                        o.canvas.ctx.moveTo(t.x, t.y),
                        o.canvas.ctx.lineTo(o.interactivity.mouse.pos_x, o.interactivity.mouse.pos_y),
                        o.canvas.ctx.stroke(),
                        o.canvas.ctx.closePath()
                    }
                }
            }
        }
        ,
        o.fn.vendors.eventsListeners = function() {
            "window" == o.interactivity.detect_on ? o.interactivity.el = window : o.interactivity.el = o.canvas.el,
            (o.interactivity.events.onhover.enable || o.interactivity.events.onclick.enable) && (o.interactivity.el.addEventListener("mousemove", function(t) {
                if (o.interactivity.el == window)
                    var e = t.clientX
                      , i = t.clientY;
                else
                    e = t.offsetX || t.clientX,
                    i = t.offsetY || t.clientY;
                o.interactivity.mouse.pos_x = e,
                o.interactivity.mouse.pos_y = i,
                o.tmp.retina && (o.interactivity.mouse.pos_x *= o.canvas.pxratio,
                o.interactivity.mouse.pos_y *= o.canvas.pxratio),
                o.interactivity.status = "mousemove"
            }),
            o.interactivity.el.addEventListener("mouseleave", function(t) {
                o.interactivity.mouse.pos_x = null,
                o.interactivity.mouse.pos_y = null,
                o.interactivity.status = "mouseleave"
            })),
            o.interactivity.events.onclick.enable && o.interactivity.el.addEventListener("click", function() {
                if (o.interactivity.mouse.click_pos_x = o.interactivity.mouse.pos_x,
                o.interactivity.mouse.click_pos_y = o.interactivity.mouse.pos_y,
                o.interactivity.mouse.click_time = (new Date).getTime(),
                o.interactivity.events.onclick.enable)
                    switch (o.interactivity.events.onclick.mode) {
                    case "push":
                        o.particles.move.enable ? o.fn.modes.pushParticles(o.interactivity.modes.push.particles_nb, o.interactivity.mouse) : 1 == o.interactivity.modes.push.particles_nb ? o.fn.modes.pushParticles(o.interactivity.modes.push.particles_nb, o.interactivity.mouse) : o.interactivity.modes.push.particles_nb > 1 && o.fn.modes.pushParticles(o.interactivity.modes.push.particles_nb);
                        break;
                    case "remove":
                        o.fn.modes.removeParticles(o.interactivity.modes.remove.particles_nb);
                        break;
                    case "bubble":
                        o.tmp.bubble_clicking = !0;
                        break;
                    case "repulse":
                        o.tmp.repulse_clicking = !0,
                        o.tmp.repulse_count = 0,
                        o.tmp.repulse_finish = !1,
                        setTimeout(function() {
                            o.tmp.repulse_clicking = !1
                        }, 1e3 * o.interactivity.modes.repulse.duration)
                    }
            })
        }
        ,
        o.fn.vendors.densityAutoParticles = function() {
            if (o.particles.number.density.enable) {
                var t = o.canvas.el.width * o.canvas.el.height / 1e3;
                o.tmp.retina && (t /= 2 * o.canvas.pxratio);
                var e = t * o.particles.number.value / o.particles.number.density.value_area
                  , i = o.particles.array.length - e;
                0 > i ? o.fn.modes.pushParticles(Math.abs(i)) : o.fn.modes.removeParticles(i)
            }
        }
        ,
        o.fn.vendors.checkOverlap = function(t, e) {
            for (var i = 0; i < o.particles.array.length; i++) {
                var r = o.particles.array[i]
                  , n = t.x - r.x
                  , s = t.y - r.y;
                Math.sqrt(n * n + s * s) <= t.radius + r.radius && (t.x = e ? e.x : Math.random() * o.canvas.w,
                t.y = e ? e.y : Math.random() * o.canvas.h,
                o.fn.vendors.checkOverlap(t))
            }
        }
        ,
        o.fn.vendors.createSvgImg = function(t) {
            var e = o.tmp.source_svg.replace(/#([0-9A-F]{3,6})/gi, function(e, i, o, r) {
                if (t.color.rgb)
                    var n = "rgba(" + t.color.rgb.r + "," + t.color.rgb.g + "," + t.color.rgb.b + "," + t.opacity + ")";
                else
                    n = "hsla(" + t.color.hsl.h + "," + t.color.hsl.s + "%," + t.color.hsl.l + "%," + t.opacity + ")";
                return n
            })
              , i = new Blob([e],{
                type: "image/svg+xml;charset=utf-8"
            })
              , r = window.URL || window.webkitURL || window
              , n = r.createObjectURL(i)
              , s = new Image;
            s.addEventListener("load", function() {
                t.img.obj = s,
                t.img.loaded = !0,
                r.revokeObjectURL(n),
                o.tmp.count_svg++
            }),
            s.src = n
        }
        ,
        o.fn.vendors.destroypJS = function() {
            cancelAnimationFrame(o.fn.drawAnimFrame),
            i.remove(),
            pJSDom = null
        }
        ,
        o.fn.vendors.drawShape = function(t, e, i, o, r, n) {
            var s = r * n
              , a = r / n
              , l = 180 * (a - 2) / a
              , c = Math.PI - Math.PI * l / 180;
            t.save(),
            t.beginPath(),
            t.translate(e, i),
            t.moveTo(0, 0);
            for (var u = 0; s > u; u++)
                t.lineTo(o, 0),
                t.translate(o, 0),
                t.rotate(c);
            t.fill(),
            t.restore()
        }
        ,
        o.fn.vendors.exportImg = function() {
            window.open(o.canvas.el.toDataURL("image/png"), "_blank")
        }
        ,
        o.fn.vendors.loadImg = function(t) {
            if (o.tmp.img_error = void 0,
            "" != o.particles.shape.image.src)
                if ("svg" == t) {
                    var e = new XMLHttpRequest;
                    e.open("GET", o.particles.shape.image.src),
                    e.onreadystatechange = function(t) {
                        4 == e.readyState && (200 == e.status ? (o.tmp.source_svg = t.currentTarget.response,
                        o.fn.vendors.checkBeforeDraw()) : (console.log("Error pJS - Image not found"),
                        o.tmp.img_error = !0))
                    }
                    ,
                    e.send()
                } else {
                    var i = new Image;
                    i.addEventListener("load", function() {
                        o.tmp.img_obj = i,
                        o.fn.vendors.checkBeforeDraw()
                    }),
                    i.src = o.particles.shape.image.src
                }
            else
                console.log("Error pJS - No image.src"),
                o.tmp.img_error = !0
        }
        ,
        o.fn.vendors.draw = function() {
            "image" == o.particles.shape.type ? "svg" == o.tmp.img_type ? o.tmp.count_svg >= o.particles.number.value ? (o.fn.particlesDraw(),
            o.particles.move.enable ? o.fn.drawAnimFrame = requestAnimFrame(o.fn.vendors.draw) : cancelRequestAnimFrame(o.fn.drawAnimFrame)) : o.tmp.img_error || (o.fn.drawAnimFrame = requestAnimFrame(o.fn.vendors.draw)) : null != o.tmp.img_obj ? (o.fn.particlesDraw(),
            o.particles.move.enable ? o.fn.drawAnimFrame = requestAnimFrame(o.fn.vendors.draw) : cancelRequestAnimFrame(o.fn.drawAnimFrame)) : o.tmp.img_error || (o.fn.drawAnimFrame = requestAnimFrame(o.fn.vendors.draw)) : (o.fn.particlesDraw(),
            o.particles.move.enable ? o.fn.drawAnimFrame = requestAnimFrame(o.fn.vendors.draw) : cancelRequestAnimFrame(o.fn.drawAnimFrame))
        }
        ,
        o.fn.vendors.checkBeforeDraw = function() {
            "image" == o.particles.shape.type ? "svg" == o.tmp.img_type && null == o.tmp.source_svg ? o.tmp.checkAnimFrame = requestAnimFrame(check) : (cancelRequestAnimFrame(o.tmp.checkAnimFrame),
            o.tmp.img_error || (o.fn.vendors.init(),
            o.fn.vendors.draw())) : (o.fn.vendors.init(),
            o.fn.vendors.draw())
        }
        ,
        o.fn.vendors.init = function() {
            o.fn.retinaInit(),
            o.fn.canvasInit(),
            o.fn.canvasSize(),
            o.fn.canvasPaint(),
            o.fn.particlesCreate(),
            o.fn.vendors.densityAutoParticles(),
            o.particles.line_linked.color_rgb_line = hexToRgb(o.particles.line_linked.color)
        }
        ,
        o.fn.vendors.start = function() {
            isInArray("image", o.particles.shape.type) ? (o.tmp.img_type = o.particles.shape.image.src.substr(o.particles.shape.image.src.length - 3),
            o.fn.vendors.loadImg(o.tmp.img_type)) : o.fn.vendors.checkBeforeDraw()
        }
        ,
        o.fn.vendors.eventsListeners(),
        o.fn.vendors.start()
    };
    Object.deepExtend = function(t, e) {
        for (var i in e)
            e[i] && e[i].constructor && e[i].constructor === Object ? (t[i] = t[i] || {},
            arguments.callee(t[i], e[i])) : t[i] = e[i];
        return t
    }
    ,
    window.requestAnimFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(t) {
        window.setTimeout(t, 1e3 / 60)
    }
    ,
    window.cancelRequestAnimFrame = window.cancelAnimationFrame || window.webkitCancelRequestAnimationFrame || window.mozCancelRequestAnimationFrame || window.oCancelRequestAnimationFrame || window.msCancelRequestAnimationFrame || clearTimeout,
    window.pJSDom = [],
    window.particlesJS = function(t, e) {
        "string" != typeof t && (e = t,
        t = "particles-js"),
        t || (t = "particles-js");
        var i = document.getElementById(t)
          , o = "particles-js-canvas-el"
          , r = i.getElementsByClassName(o);
        if (r.length)
            for (; r.length > 0; )
                i.removeChild(r[0]);
        var n = document.createElement("canvas");
        n.className = o,
        n.style.width = "100%",
        n.style.height = "100%",
        null != document.getElementById(t).appendChild(n) && pJSDom.push(new pJS(t,e))
    }
    ,
    window.particlesJS.load = function(t, e, i) {
        var o = new XMLHttpRequest;
        o.open("GET", e),
        o.onreadystatechange = function(e) {
            if (4 == o.readyState)
                if (200 == o.status) {
                    var r = JSON.parse(e.currentTarget.response);
                    window.particlesJS(t, r),
                    i && i()
                } else
                    console.log("Error pJS - XMLHttpRequest status: " + o.status),
                    console.log("Error pJS - File config not found")
        }
        ,
        o.send()
    }
    ,
    particlesJS("particles-js", {
        particles: {
            number: {
                value: 50,
                density: {
                    enable: !0,
                    value_area: 800
                }
            },
            color: {
                value: "#888"
            },
            shape: {
                type: "circle",
                stroke: {
                    width: 0,
                    color: "#888"
                },
                polygon: {
                    nb_sides: 5
                },
                image: {
                    src: "img/github.svg",
                    width: 100,
                    height: 100
                }
            },
            opacity: {
                value: .5,
                random: !1,
                anim: {
                    enable: !1,
                    speed: 3,
                    opacity_min: .1,
                    sync: !1
                }
            },
            size: {
                value: 5,
                random: !0,
                anim: {
                    enable: !1,
                    speed: 40,
                    size_min: .1,
                    sync: !1
                }
            },
            line_linked: {
                enable: !0,
                distance: 150,
                color: "#888",
                opacity: .4,
                width: 1
            },
            move: {
                enable: !0,
                speed: 6,
                direction: "none",
                random: !1,
                straight: !1,
                out_mode: "out",
                attract: {
                    enable: !1,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: {
                    enable: !0,
                    mode: "repulse"
                },
                onclick: {
                    enable: !0,
                    mode: "push"
                },
                resize: !0
            },
            modes: {
                grab: {
                    distance: 400,
                    line_linked: {
                        opacity: 1
                    }
                },
                bubble: {
                    distance: 400,
                    size: 40,
                    duration: 2,
                    opacity: 8,
                    speed: 3
                },
                repulse: {
                    distance: 200
                },
                push: {
                    particles_nb: 4
                },
                remove: {
                    particles_nb: 2
                }
            }
        },
        retina_detect: !0,
        config_demo: {
            hide_card: !1,
            background_color: "#b61924",
            background_image: "",
            background_position: "50% 50%",
            background_repeat: "no-repeat",
            background_size: "cover"
        }
    })
}
function initMap() {
    var t = new google.maps.Map(document.getElementById("ieatmaps"),{
        center: {
            lat: 34.0937458,
            lng: -118.3614978
        },
        zoom: 12,
        styles: [{
            featureType: "all",
            elementType: "labels.text.fill",
            stylers: [{
                saturation: 36
            }, {
                color: "#000000"
            }, {
                lightness: 40
            }]
        }, {
            featureType: "all",
            elementType: "labels.text.stroke",
            stylers: [{
                visibility: "on"
            }, {
                color: "#000000"
            }, {
                lightness: 16
            }]
        }, {
            featureType: "all",
            elementType: "labels.icon",
            stylers: [{
                visibility: "off"
            }]
        }, {
            featureType: "administrative",
            elementType: "geometry.fill",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 20
            }]
        }, {
            featureType: "administrative",
            elementType: "geometry.stroke",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }, {
                weight: 1.2
            }]
        }, {
            featureType: "landscape",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 20
            }]
        }, {
            featureType: "poi",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 21
            }]
        }, {
            featureType: "road.highway",
            elementType: "geometry.fill",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }]
        }, {
            featureType: "road.highway",
            elementType: "geometry.stroke",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 29
            }, {
                weight: .2
            }]
        }, {
            featureType: "road.arterial",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 18
            }]
        }, {
            featureType: "road.local",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 16
            }]
        }, {
            featureType: "transit",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 19
            }]
        }, {
            featureType: "water",
            elementType: "geometry",
            stylers: [{
                color: "#000000"
            }, {
                lightness: 17
            }]
        }]
    });
    new google.maps.Marker({
        position: new google.maps.LatLng(34.0937458,-118.3614978),
        title: "ASL",
        map: t
    })
}
